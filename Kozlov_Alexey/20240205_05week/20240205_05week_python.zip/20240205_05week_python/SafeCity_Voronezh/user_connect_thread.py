#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ библиотека для работы с массивами данных
import numpy as np
#~ библиотека для работы с графикой opencv
import cv2
#~~~~~~~~~~~~~~~~~~~~~~~~
from PyQt6 import QtCore
from PyQt6.QtGui import QImage
# from PyQt6.QtGui import QPixmap, QIcon

# #~ tensorflow загрузка, сохраненной модели
# # #import tensorflow as tf
# # from tensorflow.keras.models import load_model

from lcaic_ftxt_worker import FTXTWorker
# # from lcaic_model2100 import Model2100Worker
# # from lcaic_model2101 import Model2101Worker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ имя директории с logo
# DIR_LOGO = 'logo'
#~ имя директории с данными для детектирования пользователей по лицу
DIR_FACEID = 'face_id'
#~ имя шаблона притивов Хаара
FXML_HAARCASCADE_FRONT = 'haarcascade_frontalface_default.xml'
#~ имя директории для модели распознавания лиц
DIR_FACEID_TRAIN = 'trainer'
#~ имя файла для модели распознавания лиц
FYML_TRAINER = 'trainer.yml'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ десктопный поток для работы нейронкой
#~~~~~~~~~~~~~~~~~~~~~~~~
class UserConnectThread(QtCore.QThread):
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~ connect сигнал подключения или не подключения
  #~ str - access|id|FullName|Status
  conn_signal = QtCore.pyqtSignal(str)
  # #~~~ сигнал отработки предикта по модели 2101
  # pred2101_signal = QtCore.pyqtSignal(str)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # #~~~ сигналы
  # frame_ready = QtCore.pyqtSignal(QImage)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, data_fpath, parent=None):
    QtCore.QThread.__init__(self, parent)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ Флаг выполнения
    self.running = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.data_fpath = data_fpath
    #~~~ создание объекта для работы с текстовыми фалами
    self.ftwrk = FTXTWorker(self.data_fpath)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке с данными face-id
    self.faceid_path = os.path.join(self.data_fpath, DIR_FACEID)
    #~ имя директории для модели распознавания лиц
    datatrain_path = os.path.join(self.faceid_path, DIR_FACEID_TRAIN)
    self.faceid_fname = os.path.join(datatrain_path, FYML_TRAINER)
    #~ путь к папке с логотипами
    # self.logo_path = os.path.join(data_path, DIR_LOGO)
    print(f'[INFO] self.data_fpath: `{self.data_fpath}`')
    print(f'[INFO] self.faceid_path: {self.faceid_path}')
    print(f'[INFO] self.faceid_fname: {self.faceid_fname}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 0 - none
    #~ 1 - вход по логину-паролю
    #~ 2 - вход по фотографии face-id
    #~ 3 - предсказание нейронки -> модель 2100
    #~ 4 - предсказание нейронки -> модель 2101
    self.client_mode = 0
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ установка значений переменных в значения по умолчанию  
    #~~~~~~~
    #~ 0     1        2      3  4        5    
    #~ login|password|access|id|FullName|Status
    #~ 0                 1     2 3 4                5    
    #~ natalia.tsarikova|pass8|0|8|Наталья Царикова|стажёр
    #~ alexey.v.kozlov|pass9|1|9|Козлов Алексей Вадимович|стажёр
    #~ data[2]+'|'+data[3]+'|'+data[4]+'|'+data[5]
    self.doctor_id = '0'
    self.doctor_name = ''
    self.doctor_status = ''
    #~~~~~~~
    self.user_login = ''
    self.user_password = ''
    self.is_load_faceid = False
    self.is_load_model2100 = False
    self.is_load_model2101 = False


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ 1 - вход по логину-паролю
  def server_connect1(self, user_login, user_password):
    self.doctor_id = '0'
    self.doctor_name = ''
    self.doctor_status = ''
    self.user_login = user_login
    self.user_password = user_password
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.client_mode = 1
    if not self.isRunning():
      self.start()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ 2 - вход по фотографии face-id
  def server_connect2(self):
    self.doctor_id = '0'
    self.doctor_name = ''
    self.doctor_status = ''
    self.user_login = ''
    self.user_password = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.client_mode = 2
    if not self.isRunning():
      self.start()


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def run(self):
    self.running = True
    print(f'[INFO] init thread run: self.running: {self.running}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if (2 == self.client_mode):
      #~ 2 - подключение к серверу по фотографии face-id
      doctor_info = ''
      self.doctor_id = '0'
      self.doctor_name = ''
      self.doctor_status = ''
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not self.is_load_faceid:
        self.is_load_faceid = True
        #~ создаём новый распознаватель лиц
        self.recognizer = cv2.face.LBPHFaceRecognizer_create()
        #~ добавляем в него модель, которую мы обучили на прошлых этапах
        self.recognizer.read(self.faceid_fname)
        #~ указываем, что мы будем искать лица по примитивам Хаара
        self.faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + FXML_HAARCASCADE_FRONT)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ t - total
      id_tnum = 0
      id8_num = 0
      id9_num = 0
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ получаем доступ к камере v-video
      #vcam = cv2.VideoCapture(0)
      #~~~~~~~
      #~ akozlov
      # video_fname = os.path.join(self.faceid_path, '2023_1012_115956_009.MOV')
      video_fname = os.path.join(self.faceid_path, '2024_0130_122215_396.MOV')
      #~~~~~~~
      # video_fname = os.path.join(self.faceid_path, 'NataliaTsarikova360.mp4')
      # video_fname = os.path.join(self.faceid_path, 'x-person360.mp4')
      # print(f'video_fname: `{video_fname}`')
      vcam = cv2.VideoCapture(video_fname)
      if not vcam.isOpened():
        print("can`t open video-camera")
        self.conn_signal.emit(doctor_info)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ путь к папке с логотипами
      # logo_fname = os.path.join(self.logo_path, "logot.png")
      # print(f'logo_fname: `{logo_fname}`')
      #~ устанавливаю иконку у окна с видео-потоком
      # cv2.setWindowTitle('faceidwin', 'face-id')
      #~ пока не нажата любая клавиша или число кадров менее 100 — выполняем цикл
      while cv2.waitKey(1) < 0:
        #~ получаем очередной кадр с камеры
        hasFrame,frame = vcam.read()
        #~ если кадра нет
        if not hasFrame:
          #~ останавливаемся и выходим из цикла
          cv2.waitKey()
          break
        #~ высота и ширина кадра
        frameHeight = frame.shape[0]
        frameWidth = frame.shape[1]
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ переводим цветной кадр в ч/б
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        #~ улучшение контраста - необязательно делать - ухудшает для детектирования
        # gray_frame = cv2.equalizeHist(gray_frame)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ определяем лица на видео
        faces = self.faceCascade.detectMultiScale(gray_frame, scaleFactor=1.2, minNeighbors=5, minSize=(100, 100), flags=cv2.CASCADE_SCALE_IMAGE)
        #~ перебираем все найденные лица
        for(x,y,w,h) in faces:
          #~ получаем id пользователя (predicted id) и минимальное расстояние до лица при детектировании
          pred_id, face_mindist = self.recognizer.predict(gray_frame[y:y+h,x:x+w])
          #~ рисуем прямоугольник вокруг лица
          x1 = x-50
          y1 = y-50
          x2 = x+w+50
          y2 = y+h+50
          if 0 < x1 and 0 < y1 and x2 < frameWidth and y2 < frameHeight:
            id_tnum = id_tnum + 1
            if (8 == pred_id):
              id8_num = id8_num + 1
            elif (9 == pred_id):
              id9_num = id9_num + 1
            cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), int(round(frameHeight/150)), 8)
        #~ отображаю детектированное лицо    
        cv2.imshow('face-id', frame)
        # cv2.imshow('face-id', gray_frame)
        if id_tnum > 99:
          break
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ when everything done, release the capture
      vcam.release()
      cv2.destroyAllWindows()
      #~~~~~~~~~~~~~~~~~~~~~~~~
      print(f'id_tnum: `{id_tnum}`')
      print(f'id8_num: `{id8_num}`')
      print(f'id9_num: `{id9_num}`')
      if id8_num > 98:
        doctor_info = self.ftwrk.check_id_credentials('8')
      elif id9_num > 98:
        doctor_info = self.ftwrk.check_id_credentials('9')
      if doctor_info:
        doctor_info_lst = doctor_info.split('|')
        self.doctor_id = int(doctor_info_lst[0])
        self.doctor_name = doctor_info_lst[2]
        self.doctor_status = doctor_info_lst[3]
        if 1 == self.doctor_id:
          doctor_info = '1|'+self.doctor_name
        else:
          doctor_info = '2|'+self.doctor_name
      self.conn_signal.emit(doctor_info)

    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.running = False
    self.client_mode = 0
    print(f'[INFO] ---> finish thread run: self.running: {self.running}')