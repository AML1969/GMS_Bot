#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
#~ запускаем на выполнение программу
# cd c:\my_campy\yolov8-utils
# cd d:\my_campy\yolov8-utils
# python train_yolov8.py
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# https://github.com/ultralytics/ultralytics
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
from ultralytics import YOLO

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ load a model
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # model_ver = 'yolov8n.'
  # model_ver = 'yolov8s.'
  model_ver = 'yolov8m.'
  # model_ver = 'yolov8l.'
  # model_ver = 'yolov8x.'
  #~~~~~~~~~~~~~~~~~~~~~~~~
  model_yaml_name = f'{model_ver}yaml'
  model_pretrained_name = f'{model_ver}pt'
  print('[INFO] model')
  print(f'[INFO]  yaml: `{model_yaml_name}`')
  print(f'[INFO]  pretrained: `{model_pretrained_name}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # model = YOLO(model_name)
  #~ build a new model from scratch
  #~ load a pretrained model (recommended for training)
  model = YOLO(model_yaml_name)  
  model = YOLO(model_pretrained_name)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('[INFO] start train...')
  #~ use the model
  #~ train the model
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # config_yaml_path = 'coco128.yaml'
  # config_yaml_path = 'd:/yolo_dataset/fire/data.yaml'
  config_yaml_path = 'c:/yolo_dataset/fire/data.yaml'
  epochs_count = 300
  print(f'[INFO]  yaml: `{config_yaml_path}`')
  print(f'[INFO]  epochs: {epochs_count}')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  model.train(data=config_yaml_path, epochs=epochs_count)
  #~ evaluate model performance on the validation set
  metrics = model.val()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ train the model
  # results = model.train(data="config.yaml", epochs=1)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ predict on an image
  # results = model("https://ultralytics.com/images/bus.jpg")
  # results = model("d:/yolo_dataset/fire/test/images/------2022-05-30-202825_png.rf.6b5e3a8db503af053ba8fa6f30b7040f.jpg")
  results = model("c:/yolo_dataset/fire/test/images/------2022-05-30-202825_png.rf.6b5e3a8db503af053ba8fa6f30b7040f.jpg")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  print('~'*70)
  print('[INFO] Train YOLOv8 Object Detection on a Custom Dataset ver.2024.01.21')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  main()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  print('='*70)
  print('[INFO] -> program completed!')
  
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
# from ultralytics import YOLO

# # Load a model
# model = YOLO("yolov8n.yaml")  # build a new model from scratch
# model = YOLO("yolov8n.pt")  # load a pretrained model (recommended for training)

# # Use the model
# model.train(data="coco128.yaml", epochs=3)  # train the model
# metrics = model.val()  # evaluate model performance on the validation set
# results = model("https://ultralytics.com/images/bus.jpg")  # predict on an image
# path = model.export(format="onnx")  # export the model to ONNX format  