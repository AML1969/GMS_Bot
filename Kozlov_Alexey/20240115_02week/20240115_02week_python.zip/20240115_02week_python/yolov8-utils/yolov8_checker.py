#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
#~ запускаем на выполнение программу
# cd c:\my_campy\yolov8-utils
# cd d:\my_campy\yolov8-utils
# python yolov8_checker.py
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import cv2
import os
from ultralytics import YOLO
import datetime

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main(cam_url, use_compression, compressed_width, compressed_height, out_fps):
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ путь к папке из которой запустили программу
  prog_path = os.getcwd()
  print(f'[INFO] prog_path: `{prog_path}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('[INFO] camera:')
  print(f'[INFO]  cam_url: `{cam_url}`')
  print(f'[INFO]  use_compression: `{use_compression}`')
  print(f'[INFO]  compressed_width: `{compressed_width}`')
  print(f'[INFO]  compressed_height: `{compressed_height}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ открываем видео-камеру
  # cap = cv2.VideoCapture(0)
  vcam = cv2.VideoCapture(cam_url)
  frame_width = 640
  frame_height = 480
  #~ сheck if camera opened successfully
  if not vcam.isOpened(): 
    print(f'[ERROR] can`t open video-camera')
    return
  ret, frame = vcam.read()
  if ret:
    frame_width = frame.shape[1]
    frame_height = frame.shape[0]
    print(f'[INFO]  original frame size: width: {frame.shape[1]}, height: {frame.shape[0]}')
  if use_compression:
    frame_width = compressed_width
    frame_height = compressed_height
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ результирующий видео-файл
  current_time = datetime.datetime.now()
  video_file_name = current_time.strftime("%Y%m%d_%H%M%S") + ".mp4"
  video_file_name2 = os.path.join(prog_path, video_file_name)
  #~ определяем кодек и FPS для сохранения видео
  fourcc = cv2.VideoWriter_fourcc(*'mp4v')
  vout = cv2.VideoWriter(video_file_name2, fourcc, out_fps, (frame_width, frame_height))
  print(f'[INFO] result video-file: `{video_file_name2}`')
  print(f'[INFO] result frame size: width: {frame_width}, height: {frame_height}')
  print(f'[INFO] result frame per second: {round(out_fps,1)}')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ yolov8
  # model_path = os.path.join('.', 'runs', 'detect', 'train', 'weights', 'last.pt')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ load a model
  model = YOLO('yolov8m.pt')
  # # load a custom model
  # # model_path = os.path.join('.', 'runs', 'detect', 'train', 'weights', 'last.pt')
  # model = YOLO(model_path)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  threshold = 0.5

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ чтение видео-кадров камеры в цикле
  while True:
    ret, frame = vcam.read()    
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if not ret:
      vcam.release()
      vcam = cv2.VideoCapture(cam_url)
      if not vcam.isOpened(): 
        break
      continue
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if use_compression:
      frame = cv2.resize(frame, (compressed_width, compressed_height))
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ предсказание модели
    results = model(frame)[0]
    for result in results.boxes.data.tolist():
      x1, y1, x2, y2, score, class_id = result
      if score > threshold:
        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
        cv2.putText(frame, results.names[int(class_id)].upper(), (int(x1), int(y1 - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ отображаем кадр
    cv2.imshow('yolov8-medium', frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем кадр в видеофайл
    vout.write(frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ если нажата клавиша 'q', выходим из цикла
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ освобождаем ресурсы
  vcam.release()
  vout.release()
  cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  print('~'*70)
  print('[INFO]  Video Camera Checker ver.2024.01.22')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ путь к видеокамере
#  #~~~~~~~~~~~~~~~~~~~~~~~~
#  #~ web
#  cam_url = 0
#  #~ FPS -> frame per second
#  out_fps = 25.0
#  use_compression = True
#  compressed_width = 1280
#  compressed_height = 720
#  #~~~~~~~~~~~~~~~~~~~~~~~~
#  #~ Воронеж  
#  # Нейросеть_68/1 к 2_ периметр 1:
#  cam_url = 'rtsp://w3.tv.kvant-telecom.ru/nejroset_681.k.2_.perimetr.1-93c29dad69?dvr=true&token=2.9omxv2sXAx0ABfmU4bRWyp08kdXSapw7uOu0wDKZ5_X9WII0'
#  #~ FPS -> frame per second
#  out_fps = 25.0
#  use_compression = True
#  compressed_width = 1280
#  compressed_height = 720
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Сокол-Кашира  
  cam_url = 'rtsp://192.168.2.240/user=channel=2_stream=0.sdp?real_stream'
  #~ FPS -> frame per second
  out_fps = 12.0
  use_compression = True
  compressed_width = 1476
  compressed_height = 985
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  main(cam_url, use_compression, compressed_width, compressed_height, out_fps)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('='*70)
  print('[INFO] -> program completed!')