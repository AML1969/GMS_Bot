#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_campy
# .\camenv8\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_campy\SafeCity-Voronezh-3
# python check_detection.py
# python check_detection.py --cam_index 2
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ YOLOv8+supervision
#~ YOLO -> You Only Look Once - cтоит только раз взглянуть
#~ COCO -> stands for Common Objects in Context  -> расшифровывается как "Обычные объекты в контексте".
#~ https://github.com/ultralytics/ultralytics
#~ https://github.com/roboflow/supervision
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import cv2
import os
#~ передача аргументов через командную строку
import argparse
from ultralytics import YOLO
import supervision as sv
import numpy as np

from config_camera import ConfigCamera

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ ROI - Region of interest
#~ координаты полигона -> относительные
ZONE_POLYGON = np.array([
    [0, 0],
    [0.5, 0],
    [0.5, 1],
    [0, 1]
])

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ выполнение программы - тестируем детектирование объектов в кадре
#~~~~~~~~~~~~~~~~~~~~~~~~
print('~'*70)
print('[INFO] Check YOLOv8+Supervision Detection ver.2024.01.15')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ путь к папке из которой запустили программу
prog_path = os.getcwd()
print('~'*70)
print(f'[INFO] prog_path: `{prog_path}`')
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ добавляем парсер аргументов
parser = argparse.ArgumentParser(description='Video camera settings.')
parser.add_argument('--cam_index', type=int, default=0,
                    help='Index of the camera to use')
args = parser.parse_args()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ настройки камеры: пути, сжатие и т.д.
cam_conf = ConfigCamera(prog_path)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_count = cam_conf.get_cam_count()
cam_inx_valid = cam_conf.check_cam_inx(args.cam_index)
print('[INFO] camera:')
print(f'[INFO]  count: {cam_count}')
print(f'[INFO]  index: {args.cam_index}')
# print(f'[INFO]    index valid: {cam_inx_valid}')
if not cam_inx_valid:
  print(f'[ERROR]  the index of camera is incorrect')
  exit(0)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_id,cam_name,cam_location,cam_url = cam_conf.get_cam_parameters(args.cam_index)
print(f'[INFO]  cam_id: {cam_id}')
print(f'[INFO]  cam_name: `{cam_name}`')
print(f'[INFO]  cam_location: `{cam_location}`')
print(f'[INFO]  cam_url: `{cam_url}`')
if -1 == cam_id:
  print(f'[ERROR]  the index of camera is incorrect')
  exit(0)
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ frame parameters
use_compression,compressed_width,compressed_height = cam_conf.get_frame_compression()
print(f'[INFO]  use_compression: {use_compression}')
print(f'[INFO]  compressed_width: {compressed_width}')
print(f'[INFO]  compressed_height: {compressed_height}')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ открываем видео-камеру
#~~~~~~~~~~~~~~~~~~~~~~~~
print('~'*70)
print('start detection...')
vcam = cv2.VideoCapture(cam_url)
#~ сheck if camera opened successfully
if not vcam.isOpened(): 
  print(f'[ERROR]  can`t open video-camera: `{cam_name}`')
  exit(0)
frame_width = 640
frame_height = 480
ret, frame = vcam.read()
if ret:
  frame_width = frame.shape[1]
  frame_height = frame.shape[0]
if use_compression:
  frame_width = compressed_width
  frame_height = compressed_height
vcam_resolution = [frame_width, frame_height]
print(f'[INFO] frame_width: {frame_width}, frame_height: {frame_height}')
print(f'[INFO] vcam_resolution: {vcam_resolution}')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ загружаем модель
# model = YOLO("yolov8s.pt")
# model = YOLO("yolov8m.pt")
model = YOLO("yolov8l.pt")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
model_classes = model.names
# print(f'model_classes: len: `{len(model_classes)}`, `{model_classes}`')
#~ model_classes: len: `80`, `{0: 'person', 1: 'bicycle', 2: 'car', 3: 'motorcycle', 4: 'airplane', 5: 'bus', 6: 'train', 7: 'truck',


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
box_annotator = sv.BoxAnnotator(
    thickness=2,
    text_thickness=2,
    text_scale=1
)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ координаты полигона -> относительные
zone_polygon = (ZONE_POLYGON * np.array(vcam_resolution)).astype(int)
zone = sv.PolygonZone(polygon=zone_polygon, frame_resolution_wh=tuple(vcam_resolution))
zone_annotator = sv.PolygonZoneAnnotator(
    zone=zone, 
    color=sv.Color.red(),
    thickness=2,
    text_thickness=4,
    text_scale=2
)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ чтение видео-кадров камеры в цикле и детектирование объектов
#~~~~~~~~~~~~~~~~~~~~~~~~
#~детектируем в прямоугольнике толко объекты с обозначенным id
# 0: 'person', 1: 'bicycle', 2: 'car'
class_id_det = 2
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
while True:
  ret, frame = vcam.read()    
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  if not ret:
    vcam.release()
    vcam = cv2.VideoCapture(cam_url)
    if not vcam.isOpened(): 
      break
    continue
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ в зависимости от значения use_compression изменяем размер кадра
  #~ или оставляем его без изменений
  if use_compression:
    frame = cv2.resize(frame, (frame_width, frame_height))

  # #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # result = model(frame)[0]
  # detections = sv.Detections.from_ultralytics(result)
  # # print(f'[INFO]  len: `{len(detections)}`')
  # frame = box_annotator.annotate(scene=frame, detections=detections)
  # zone.trigger(detections=detections)
  # frame = zone_annotator.annotate(scene=frame)    

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  result = model(frame, agnostic_nms=True)[0]
  detections = sv.Detections.from_ultralytics(result)
  detections = detections[detections.class_id == class_id_det]

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  labels = [
    f"{model_classes[class_id]} {confidence:0.2f}"
    for _, _, confidence, class_id, _ in detections
  ]

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # frame = box_annotator.annotate(scene=frame, detections=detections)
  frame = box_annotator.annotate(
    scene=frame, 
    detections=detections, 
    labels=labels
  )

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  zone.trigger(detections=detections)
  frame = zone_annotator.annotate(scene=frame)    

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  cv2.imshow(cam_name, frame)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  if cv2.waitKey(1) & 0xFF == ord('q'):
    break
  # if (cv2.waitKey(30) == 27): -> это вносит задержку на реальной камере на 30мсек
  #     break

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ закрываем видео-камеру и освобождаем ресурсы с ней связанные
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ when everything done, release the video capture object
vcam.release()
#~ closes all the frames
cv2.destroyAllWindows()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
print('='*70)
print('[INFO] -> program completed!')