import torch
import cv2
import random

from detection_reporter import DetectionReporter

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class YOLOv5Detector:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, prog_path, cam_names, detection_threshold = 0.5, model_type='yolov5s', custom_model=False, custom_model_path=None):
    #~~~~~~~~~~~~~~~~~~~~~~~~
    available_device = 'cpu'
    if torch.cuda.is_available():
      #~ выбираем первое доступное устройство GPU
      available_device = 'cuda:0'
    self.device = torch.device(available_device)
    print(f'[INFO.YOLOv5Detector] available_device `{self.device}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if custom_model:
      #~ assert custom_model_path is not None, "Please provide the path to the custom model"
      #~ self.model = torch.hub.load('ultralytics/yolov5', 'custom', path=custom_model_path, source='local', force_reload=True)
      if custom_model_path:
        # model = torch.hub.load('ultralytics/yolov5', 'custom', path='d:/my_dcampy/yolov5/runs/train/snowbank-results3/weights/best.pt', force_reload=True)
        self.model = torch.hub.load('ultralytics/yolov5', 'custom', path=custom_model_path, force_reload=True)
        print(f'[INFO.YOLOv5Detector] success init custom model: `{custom_model_path}`')
      else:
        self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
        print('[WARNING.YOLOv5Detector] custom model is not define, init standard ьщвуд `yolov5s`')
    else:
      # self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
      self.model = torch.hub.load('ultralytics/yolov5', model_type, pretrained=True)
      print(f'[INFO.YOLOv5Detector] success init standard model: `{model_type}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ Команда self.model.to(self.device) переносит модель self.model на указанное устройство self.device.
    #~ В данном случае, если доступно устройство CUDA (GPU), модель будет перенесена на GPU,
    #~ иначе она будет перенесена на CPU.
    #~ Это позволяет выполнять вычисления на выбранном устройстве для оптимизации производительности.
    #~ Перенос модели на GPU может ускорить процесс обработки изображений, особенно если у вас есть мощный GPU.
    #~ В то же время, если у вас нет доступа к GPU, модель будет автоматически перенесена на CPU для выполнения вычислений.
    #~
    self.model.to(self.device)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ устанавливаем минимальный порог обнаружения, который предварительно считали из файла settings.ini
    self.detection_threshold = detection_threshold
    print(f'[INFO.YOLOv5Detector] detection_threshold: `{self.detection_threshold}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ стандартная модель ms_coco_classnames -> 80 объектов 
    #~ COCO Classes: https://gist.github.com/AruniRC/7b3dadd004da04c80198557db5da4bda
    #~ 0: 'person',
    #~ 1: 'bicycle',
    #~ 2: 'car',
    #~ 3: 'motorcycle',
    #~ 4: 'airplane',
    #~ 5: 'bus',
    #~ 6: 'train',
    #~ 7: 'truck',
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ создаем массив цветов для отображения объектов
    #~ person - красный
    #~ car - синий
    self.obj_colors = {'person': (0, 0, 255), 'car': (255, 0, 0), 'bus': (255, 0, 255), 'truck': (255, 0, 255)}
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ объект для создания отчетов
    self.det_rep = DetectionReporter(prog_path, cam_names)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def detect_objects(self, frame, cam_inx):
    results = self.model(frame)
    for det in results.xyxy[0]:
      #~ если детектирование с низким порогом, то не рассматриваю эти объекты
      if det[4] > self.detection_threshold:
        x1, y1, x2, y2 = map(int, det[:4])
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # obj_label = self.model.names[int(det[5])]
        obj_id = int(det[5])
        # print(f'obj_id: `{obj_id}`')
        obj_label = self.model.names[obj_id]
        obj_color = self.obj_colors.get(obj_label, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
        #~~~~~~~~~~~~~~~~~~~~~~~~
        frame = cv2.rectangle(frame, (x1, y1), (x2, y2), obj_color, 2)
        frame = cv2.putText(frame, f'{obj_label} {det[4]:.2f}', (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, obj_color, 2)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ сохраняем в отчет время детектирования person
        #~ 0: 'person' 
        #~ 2: 'car',
        if 0 == obj_id:
          self.det_rep.add_person_detection(cam_inx, frame)

    #~~~~~~~~~~~~~~~~~~~~~~~~
    # return frame