#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_campy
# .\camenv8\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_campy\SafeCity-Voronezh-3
# python separate_images.py
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import os
import shutil
import random

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def split_dataset(source_folder, dest_folder, test_percent, valid_percent):
  print(f'[INFO] source_folder: `{source_folder}`')
  print(f'[INFO] dest_folder: `{dest_folder}`')
  print(f'[INFO] test_percent: {test_percent}')
  print(f'[INFO] valid_percent: {valid_percent}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ удаляем и создаем результирующую директорию
  #~~~~~~~~~~~~~~~~~~~~~~~~
  if os.path.exists(dest_folder):
    shutil.rmtree(dest_folder)
  if not os.path.exists(dest_folder):
    os.makedirs(dest_folder)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  images_folder = os.path.join(source_folder, "images")
  labels_folder = os.path.join(source_folder, "labels")
  classes_file_path = os.path.join(labels_folder, "classes.txt")
  print('[INFO] source')
  print(f'[INFO]   images_folder: `{images_folder}`')
  print(f'[INFO]   labels_folder: `{labels_folder}`')
  print(f'[INFO]   labels_folder: `{labels_folder}`')
  print(f'[INFO]   classes_file: `{classes_file_path}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ получаем список файлов
  files = os.listdir(images_folder)
  random.shuffle(files)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ рассчитываем количество файлов для test и valid
  total_files = len(files)
  test_count = int(total_files * (test_percent / 100))
  valid_count = int(total_files * (valid_percent / 100))
  print(f'[INFO]   total_files: {total_files}')
  print(f'[INFO]   test_count: {test_count}')
  print(f'[INFO]   valid_count: {valid_count}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ cоздаем папки
  os.makedirs(os.path.join(dest_folder, "train", "images"), exist_ok=True)
  os.makedirs(os.path.join(dest_folder, "train", "labels"), exist_ok=True)
  os.makedirs(os.path.join(dest_folder, "test", "images"), exist_ok=True)
  os.makedirs(os.path.join(dest_folder, "test", "labels"), exist_ok=True)
  os.makedirs(os.path.join(dest_folder, "valid", "images"), exist_ok=True)
  os.makedirs(os.path.join(dest_folder, "valid", "labels"), exist_ok=True)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ формируем список уникальных имен классов
  unique_names = []
  with open(classes_file_path, 'r', encoding='utf-8') as classes_file:
    for line in classes_file:
      #~ удаляем пробельные символы  слева и справа и добавляем непустые строки в список
      cleaned_line = line.strip()
      if cleaned_line:
        unique_names.append(cleaned_line)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # print(f'unique_names: len: {len(unique_names)}, {unique_names}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ копируем файлы в папки
  for i, file in enumerate(files):
    if i < test_count:
      shutil.copy(os.path.join(images_folder, file), os.path.join(dest_folder, "test", "images", file))
      shutil.copy(os.path.join(labels_folder, file.replace(".jpg", ".txt")), os.path.join(dest_folder, "test", "labels", file.replace(".jpg", ".txt")))
    elif i < test_count + valid_count:
      shutil.copy(os.path.join(images_folder, file), os.path.join(dest_folder, "valid", "images", file))
      shutil.copy(os.path.join(labels_folder, file.replace(".jpg", ".txt")), os.path.join(dest_folder, "valid", "labels", file.replace(".jpg", ".txt")))
    else:
      shutil.copy(os.path.join(images_folder, file), os.path.join(dest_folder, "train", "images", file))
      shutil.copy(os.path.join(labels_folder, file.replace(".jpg", ".txt")), os.path.join(dest_folder,  "train", "labels", file.replace(".jpg", ".txt")))
    #~~~~~~~~~~~~~~~~~~~~~~~~
    name = file.split(".")[0]
    if name not in unique_names:
      unique_names.append(name)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  print(f'[INFO] unique_names: len: {len(unique_names)}')
  print(f'[INFO] {unique_names}')
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ создаем и сохраняем файл data.yaml
  with open(os.path.join(dest_folder, "data.yaml"), 'w', encoding='UTF-8') as file_yaml:
    #~ train
    str_line = os.path.join(dest_folder, "train", "images").replace("/", "\\")
    file_yaml.write(f'train: {str_line}\n')
    #~ val
    str_line = os.path.join(dest_folder, "valid", "images").replace("/", "\\")
    file_yaml.write(f'val: {str_line}\n')
    #~ test
    str_line = os.path.join(dest_folder, "test", "images").replace("/", "\\")
    file_yaml.write(f'test: {str_line}\n\n')
    #~ number of classes
    file_yaml.write(f'nc: {len(unique_names)}\n')
    #~ class names
    file_yaml.write(f'names: {unique_names}')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
source_folder = 'd:/yolov5_dataset/snowbank'
#~ tvt - train, valid, test
dest_folder = 'd:/yolov5_dataset/snowbank_tvt'
test_percent = 5
valid_percent = 10

split_dataset(source_folder, dest_folder, test_percent, valid_percent)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
print('='*70)
print('[INFO] -> program completed!')