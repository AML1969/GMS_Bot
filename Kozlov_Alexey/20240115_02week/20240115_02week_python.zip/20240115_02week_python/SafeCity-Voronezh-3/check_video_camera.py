#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_campy
# .\camenv8\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_campy\SafeCity-Voronezh-3
# python check_video_camera.py
# python check_video_camera.py --cam_index 2
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import numpy as np
import cv2
import os
#~ передача аргументов через командную строку
import argparse

from config_camera import ConfigCamera

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ выполнение программы - тестируем детектирование объектов в кадре
#~~~~~~~~~~~~~~~~~~~~~~~~
print('~'*70)
print('[INFO]  Check Video Camera ver.2024.01.15')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ путь к папке из которой запустили программу
prog_path = os.getcwd()
print('~'*70)
print(f'[INFO]  prog_path: `{prog_path}`')
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ добавляем парсер аргументов
parser = argparse.ArgumentParser(description='Video camera settings.')
parser.add_argument('--cam_index', type=int, default=0,
                    help='Index of the camera to use')
args = parser.parse_args()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ настройки камеры: пути, сжатие и т.д.
cam_conf = ConfigCamera(prog_path)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_count = cam_conf.get_cam_count()
cam_inx_valid = cam_conf.check_cam_inx(args.cam_index)
print('[INFO]  camera:')
print(f'[INFO]    count: {cam_count}')
print(f'[INFO]    index: {args.cam_index}')
# print(f'[INFO]    index valid: {cam_inx_valid}')
if not cam_inx_valid:
  print(f'[ERROR]  the index of camera is incorrect')
  exit(0)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_id,cam_name,cam_location,cam_url = cam_conf.get_cam_parameters(args.cam_index)
print(f'[INFO]    cam_id: {cam_id}')
print(f'[INFO]    cam_name: `{cam_name}`')
print(f'[INFO]    cam_location: `{cam_location}`')
print(f'[INFO]    cam_url: `{cam_url}`')
if -1 == cam_id:
  print(f'[ERROR]  the index of camera is incorrect')
  exit(0)
#~~~~~~~~~~~~~~~~~~~~~~~~
use_compression,compressed_width,compressed_height = cam_conf.get_frame_compression()
print(f'[INFO]    use_compression: {use_compression}')
print(f'[INFO]    compressed_width: {compressed_width}')
print(f'[INFO]    compressed_height: {compressed_height}')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ открываем видео-камеру
vcam = cv2.VideoCapture(cam_url)
#~ сheck if camera opened successfully
print('~'*70)
#~ check if camera opened successfully
if not vcam.isOpened(): 
  print(f'[ERROR]  can`t open video-camera: `{cam_name}`')
  exit(0)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ попытка установить уменьшенные размеры кадра на самом потоке rtsp
#~ 2024.01.21 - не работает это измение размеров кадра
#~~~~~~~~~~~~~~~~~~~~~~~~
# frame_width = 768
# frame_height = 432
# print(f'[INFO] frame_width: {frame_width}')
# print(f'[INFO] frame_height: {frame_height}')
# vcam.set(cv2.CAP_PROP_FRAME_WIDTH, frame_width)
# vcam.set(cv2.CAP_PROP_FRAME_HEIGHT, frame_height)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ чтение видео-кадров камеры в цикле и детектирование объектов
#~~~~~~~~~~~~~~~~~~~~~~~~
# while (vcam.isOpened()):
while True:
  ret, frame = vcam.read()    
  #~~~~~~~~~~~~~~~~~~~~~~~~
  if not ret:
    vcam.release()
    vcam = cv2.VideoCapture(cam_url)
    if not vcam.isOpened(): 
      break
    continue
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ в зависимости от значения use_compression изменяем размер кадра
  #~ или оставляем его без изменений
  if use_compression:
    frame = cv2.resize(frame, (compressed_width, compressed_height))
  # frame = cv2.resize(frame, (frame_width, frame_height))
  # # frame = cv2.resize(frame, (frame_height, frame_width))

  #~~~~~~~~~~~~~~~~~~~~~~~~
  cv2.imshow(cam_name, frame)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  if cv2.waitKey(1) & 0xFF == ord('q'):
    break

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ закрываем видео-камеру и освобождаем ресурсы с ней связанные
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ when everything done, release the video capture object
vcam.release()
#~ closes all the frames
cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
print('='*70)
print('[INFO] -> program completed!')