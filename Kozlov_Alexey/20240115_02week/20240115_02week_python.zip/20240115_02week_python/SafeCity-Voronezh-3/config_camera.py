import configparser
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class ConfigCamera:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, prog_path):
    # print(f' >ConfigCamera: prog_path: `{prog_path}`')
    config_filename = os.path.join(prog_path, 'settings.ini')
    # print(f' >ConfigCamera: config_filename: `{config_filename}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.config = configparser.ConfigParser()
    self.config.read(config_filename)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_count(self) -> int:
    retVal = self.config.getint('CAMERAS', 'total_cameras')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_cam_inx(self, cam_inx: int) -> bool:
    retVal = False
    cam_count = self.get_cam_count()
    # print(f'[INFO.ConfigCamera]  cam_inx: {cam_inx}, cam_count: {cam_count}')
    if -1 < cam_inx and cam_inx < cam_count:
      retVal = True
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_parameters(self, cam_inx: int):
    cam_id = -1
    cam_name = ''
    cam_location = ''
    cam_url = ''
    cam_inx_valid = self.check_cam_inx(cam_inx)
    if cam_inx_valid:
      cam_id = self.config.getint('CAMERAS', f'camera{cam_inx}_id')
      cam_name = self.config.get('CAMERAS', f'camera{cam_inx}_name')
      cam_location = self.config.get('CAMERAS', f'camera{cam_inx}_location')
      cam_url = self.config.get('CAMERAS', f'camera{cam_inx}_url')
    return cam_id,cam_name,cam_location,cam_url

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_frame_compression(self):
    #~ оригинальные размеры кадра: frame4 shape: (1296, 2304, 3)
    #~ 16/9 = 1.7778, 2304/1296 = 1.7778
    #~ уменьшаем в 1.8 раза: width=2304/1.8=1280, height=1296/1.8=720
    #~ уменьшаем в 2 раза: width=2304/2=1152, height=1296/2=648
    #~ уменьшаем в 3 раза: width=2304/3=768, height=1296/3=432
    #~ уменьшаем в 4 раза: width=2304/4=576, height=1296/4=324
    use_compression = self.config.getboolean('FrameSettings', 'use_compression')
    compressed_width = self.config.getint('FrameSettings', 'compressed_width')
    compressed_height = self.config.getint('FrameSettings', 'compressed_height')
    return use_compression,compressed_width,compressed_height

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_detection_threshold(self) -> float:
    retVal = self.config.getfloat('YOLOv5Detector', 'detection_threshold')
    return retVal