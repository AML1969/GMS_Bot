import os
import shutil
from datetime import datetime
import json

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class JSONWworker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, working_dir: str):
    self.working_dir = working_dir
    # print(f'[INFO] self.working_dir: `{self.working_dir}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if not os.path.exists(self.working_dir):
      os.makedirs(self.working_dir)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_json_polygon(self, image_width: int, image_height: int, polygon_nodes):
    nodes_len = len(polygon_nodes)
    # print(f'[INFO] ---->polygon_nodes: {polygon_nodes}')
    # print(f'[INFO] image_width: {image_width}, image_height: {image_height}, nodes_len: {nodes_len}') 
    if nodes_len < 3:
      print(f'[ERROR] the number of nodes in the polygon is not enough')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    current_time_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    # print(f'[INFO] current_time_str: `{current_time_str}`')
    json_name = os.path.join(self.working_dir, f'{current_time_str}.json')
    # print(f'[INFO] save json file: `{json_name}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ преобразуем пиксельные координаты узлов в относительные координаты
    relative_points = []
    for x, y in polygon_nodes:
      relative_x = x / image_width
      relative_y = y / image_height
      relative_points.append([relative_x, relative_y])
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ создадим словарь с относительными координатами и сохраним его в JSON файл
    polygon_data = {
      "zone_polygon": relative_points
    }
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ и сохраняем файл на диск формате в JSON файл
    #~ json.dump(polygon_data, json_file, ensure_ascii=False) - эта часть кода использует функцию json.dump()
    #~ для записи данных из переменной polygon_data в файл json_file.
    #~ Параметр ensure_ascii=False указывает, что символы Unicode будут записаны в файл как есть,
    #~ без преобразования в ASCII.
    with open(json_name, 'w', encoding='utf-8') as json_file:
      json.dump(polygon_data, json_file, ensure_ascii=False)