import os
import shutil
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
import numpy as np
from datetime import datetime

from alarm_utilities.json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ создание ROI (Region Of Interest) по стоп-кадру
class ROIMaker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_name: str, prog_path: str, data_dir: str, stop_frame_dir: str, roi_image_name: str, roi_dir: str):
    self.cam_name = cam_name
    self.canvas_dir = os.path.join(prog_path, data_dir, cam_name, stop_frame_dir)
    self.roi_image_name = roi_image_name
    self.result_dir = os.path.join(prog_path, data_dir, cam_name, roi_dir)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] self.cam_name: `{self.cam_name}`')
    # print(f'[INFO] prog_path: `{prog_path}`')
    # print(f'[INFO] data_dir: `{data_dir}`')
    # print(f'[INFO] stop_frame_dir: `{stop_frame_dir}`')
    # print(f'[INFO] self.roi_image_name: `{self.roi_image_name}`')
    # print(f'[INFO] roi_dir: `{roi_dir}`')
    # print(f'[INFO] self.canvas_dir: `{self.canvas_dir}`')
    # print(f'[INFO] self.result_dir: `{self.result_dir}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if not os.path.exists(self.result_dir):
      os.makedirs(self.result_dir)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.img_name = ''
    self.image_width1 = 1
    self.image_height1 = 1
    self.image_ratio1 = 1.0
    self.image_width2 = 1
    self.image_height2 = 1
    self.image_ratio2 = 1.0
    self.gui_image_zip = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.points = []
    self.dragging = False
    self.selected_point_index = -1

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def find_first_jpg(self, start_path):
    for root, dirs, files in os.walk(start_path):
      for file in files:
        if file.endswith(".jpg"):
          return os.path.join(root, file)
    return ''

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def find_file(self, start_path, file_name):
    for root, dirs, files in os.walk(start_path):
      if file_name in files:
        return os.path.join(root, file_name)
    return ''


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def open_image(self):
    #~ пытаюсь найти изображение, по которому буду создавать контуры
    self.img_name = ''
    if self.roi_image_name:
      self.img_name = self.find_file(self.canvas_dir, self.roi_image_name)
      print(f'[INFO] self.img_name: `{self.img_name}`')
    if not self.img_name:
      self.img_name = self.find_first_jpg(self.canvas_dir)
      print(f'[INFO] img_name-1jpg: `{self.img_name}`')
    if not self.img_name:
      print(f'[ERROR] can`t find stop-frame image in directory: {self.canvas_dir}')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываю изображение
    self.image = cv2.imread(self.img_name)
    self.image_width1 = self.image.shape[1]
    self.image_height1 = self.image.shape[0]
    self.image_ratio1 = self.image_width1/self.image_height1
    self.image_width2 = self.image_width1
    self.image_height2 = self.image_height1
    self.image_ratio2 = self.image_ratio1
    # print(f'[INFO] original image size: width1: {self.image_width1}, height1: {self.image_height1}, ratio1: {round(self.image_ratio1,4)}')
    # print(f'[INFO] original image size: width2: {self.image_width2}, height2: {self.image_height2}, ratio2: {round(self.image_ratio2,4)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ получаем размеры экрана, для того чтобы оно полностью помещалось на экране монитора
    screen_width, screen_height = pyautogui.size()
    screen_ratio = screen_width/screen_height
    # print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_ratio,4)}')
    #~ изменяю размер для учета task-bar -> windows
    screen_height -= 65
    width_zip = screen_height*screen_ratio
    screen_width = int(width_zip)
    # print(f'[INFO] taskbar modified: screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_ratio,4)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.gui_image_zip = False
    if self.image_width1 > screen_width or self.image_height1 > screen_height:
      self.gui_image_zip = True
      width_zip = self.image_width1/screen_width
      height_zip = self.image_height1/screen_height
      frame_zip = width_zip
      if height_zip > width_zip:
        frame_zip = height_zip
      # print(f'[INFO] width_zip: {round(width_zip,4)}, height_zip: {round(height_zip,4)}, frame_zip: {round(frame_zip,4)}')
      width_zip = self.image_width1/frame_zip
      height_zip = self.image_height1/frame_zip
      self.image_width2 = int(width_zip)
      self.image_height2 = int(height_zip)
      self.image_ratio2 = self.image_width2/self.image_height2
      # print(f'[INFO] screen modified: width: {self.image_width2}, height: {self.image_height2}, ratio: {round(self.image_ratio2,4)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print(f'[INFO] original image size: width1: {self.image_width1}, height1: {self.image_height1}, ratio1: {round(self.image_ratio1,4)}')
    print(f'[INFO] patch image size: width2: {self.image_width2}, height2: {self.image_height2}, ratio2: {round(self.image_ratio2,4)}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def mouse_callback(self, event, x, y, flags, param):
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ дистанция-радиус в пикселях - реакция на нажатие мышью рядом с узлом 
    dist_pix = 15
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if event == cv2.EVENT_LBUTTONDOWN:
      #~ добавление узла или инициализация режима перемещения узла
      for i, point in enumerate(self.points):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          self.dragging = True
          self.selected_point_index = i
          break
      if not self.dragging:
        self.points.append((x, y))
    elif event == cv2.EVENT_LBUTTONUP:
      #~ завершение режима перемещения узла
      self.dragging = False
      self.selected_point_index = -1
    elif event == cv2.EVENT_MOUSEMOVE:
      #~ перемещения узла
      if self.dragging and 0 <= self.selected_point_index < len(self.points):
        self.points[self.selected_point_index] = (x, y)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
      #~ удаление узла двойным кликом
      for i, point in enumerate(self.points):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          del self.points[i]
          break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.update_image()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update_image(self):
    self.image = cv2.imread(self.img_name)
    if self.gui_image_zip:
      self.image = cv2.resize(self.image, (self.image_width2, self.image_height2))
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ первым делом отрисовываю ребра
    if len(self.points) > 1:
      for i in range(len(self.points)):
        cv2.line(self.image, self.points[i-1], self.points[i], (255, 0, 0), 2)
    #~ затем поверх них узлы
    for i in range(len(self.points)):
      cv2.circle(self.image, self.points[i], 5, (0, 0, 255), -1)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    cv2.imshow(self.cam_name, self.image)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_person_region(self, person_dir: str):
    self.gui_image_zip = False
    self.open_image()
    if not self.img_name:
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    cv2.namedWindow(self.cam_name)
    cv2.setMouseCallback(self.cam_name, self.mouse_callback)
    while True:
      self.update_image()
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    cv2.destroyAllWindows()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняю текущий регион
    result_dir = os.path.join(self.result_dir, person_dir)
    # print(f'[INFO] self.result_dir: `{self.result_dir}`')
    # print(f'[INFO] person_dir: `{person_dir}`, result_dir: `{result_dir}`')
    json_worker_obj = JSONWworker(result_dir)
    json_worker_obj.save_json_polygon(self.image_width2, self.image_height2, self.points)