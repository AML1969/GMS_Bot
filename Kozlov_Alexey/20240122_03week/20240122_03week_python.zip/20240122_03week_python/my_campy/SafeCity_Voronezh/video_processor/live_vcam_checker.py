#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class LiveVCamChecker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_name: str, cam_url: str, frame_width: int, frame_height: int):
    self.cam_name = cam_name
    self.cam_url = cam_url
    #~ m - modified width, height
    self.frame_mwidth = frame_width
    self.frame_mheight = frame_height
    if 0 == self.frame_mwidth or 0 == self.frame_mheight:
      self.frame_mwidth = 0
      self.frame_mheight = 0
    # print(f'[INFO] self.cam_name: `{self.cam_name}`')
    # print(f'[INFO] self.cam_url: `{self.cam_url}`')
    # print(f'[INFO] self.frame_width: user modified: width: {self.frame_mwidth}, height: {self.frame_mheight}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_vstream(self):
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ получаем размеры экрана
    screen_width, screen_height = pyautogui.size()
    screen_ratio = screen_width/screen_height
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_ratio,4)}')
    #~ изменяю размер для учета task-bar -> windows
    screen_height -= 65
    width_zip = screen_height*screen_ratio
    screen_width = int(width_zip)
    print(f'[INFO] taskbar modified: screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_ratio,4)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сheck if camera opened successfully
    if not vcam.isOpened(): 
      print(f'[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ calculate and patch frame width, height
    gui_frame_zip = False
    frame_width = 640
    frame_height = 480
    frame_ratio = frame_width/frame_height
    print(f'[INFO] default: width: {frame_width}, height: {frame_height}, ratio: {round(frame_ratio,4)}')
    if self.frame_mwidth > 0 and self.frame_mheight > 0:
      gui_frame_zip = True
      frame_width = self.frame_mwidth
      frame_height = self.frame_mheight
      frame_ratio = frame_width/frame_height
      print(f'[INFO] user modified: width: {frame_width}, height: {frame_height}, ratio: {round(frame_ratio,4)}')
    else:
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          frame_width = frame.shape[1]
          frame_height = frame.shape[0]
          frame_ratio = frame_width/frame_height
          print(f'[INFO] original frame size: width: {frame_width}, height: {frame_height}, ratio: {round(frame_ratio,4)}')
          break
    if frame_width > screen_width or frame_height > screen_height:
      gui_frame_zip = True
      width_zip = frame_width/screen_width
      height_zip = frame_height/screen_height
      frame_zip = width_zip
      if height_zip > width_zip:
        frame_zip = height_zip
      print(f'[INFO] width_zip: {round(width_zip,4)}, height_zip: {round(height_zip,4)}, frame_zip: {round(frame_zip,4)}')
      width_zip = frame_width/frame_zip
      height_zip = frame_height/frame_zip
      frame_width = int(width_zip)
      frame_height = int(height_zip)
      frame_ratio = frame_width/frame_height
      print(f'[INFO] screen modified: width: {frame_width}, height: {frame_height}, ratio: {round(frame_ratio,4)}')
    print(f'[INFO] patch frame size: {gui_frame_zip}, width: {frame_width}, height: {frame_height}, ratio: {round(frame_ratio,4)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened(): 
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      if gui_frame_zip:
        frame = cv2.resize(frame, (frame_width, frame_height))
      cv2.imshow(self.cam_name, frame)
      #~ если нажата клавиша 'q', выходим из цикла
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    vcam.release()
    cv2.destroyAllWindows()