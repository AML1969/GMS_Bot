import os
import shutil
import cv2
from datetime import datetime

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class StopFrameMaker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_name: str, prog_path: str, data_dir: str, stop_frame_dir: str):
    self.cam_name = cam_name
    current_date_str = datetime.now().strftime("%Y_%m_%d")
    self.working_dir = os.path.join(prog_path, data_dir, cam_name, stop_frame_dir, current_date_str)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] self.cam_name: `{self.cam_name}`')
    # print(f'[INFO] prog_path: `{prog_path}`')
    # print(f'[INFO] data_dir: `{data_dir}`')
    # print(f'[INFO] stop_frame_dir: `{stop_frame_dir}`')
    # print(f'[INFO] current_date_str: `{current_date_str}`')
    print(f'[INFO] self.working_dir: `{self.working_dir}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if not os.path.exists(self.working_dir):
      os.makedirs(self.working_dir)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_frame(self, frame):
    #~ удаляем последние три символа (микросекунды) с помощью [:-3], чтобы получить только миллисекунды
    # current_date_str = datetime.now().strftime("%Y_%m_%d")
    # current_time_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    # current_time_str = datetime.now().strftime('%Y%m%d_%H%M%S%f')
    current_time_str = datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]
    frame_name = os.path.join(self.working_dir, f'{self.cam_name}_{current_time_str}.jpg')
    print(f'[INFO] save stop frame: `{frame_name}`')
    #~ сохраняем стоп-кадр в файл jpg
    cv2.imwrite(frame_name, frame)


