import configparser
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class TotalConfigurator:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, prog_path: str):
    config_filename = os.path.join(prog_path, 'general_settings', 'settings.ini')
    # print(f'[INFO] prog_path: `{prog_path}`')
    # print(f'[INFO] config_filename: `{config_filename}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.config = configparser.ConfigParser()
    self.config.read(config_filename)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_count(self) -> int:
    retVal = self.config.getint('CAMERAS', 'total_cameras')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_cam_inx(self, cam_inx: int) -> bool:
    retVal = False
    cam_count = self.get_cam_count()
    if -1 < cam_inx and cam_inx < cam_count:
      retVal = True
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_name(self, cam_inx: int) -> str:
    retVal = ''
    if self.check_cam_inx(cam_inx):
      retVal = self.config.get('CAMERAS', f'camera{cam_inx}_name')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_description(self, cam_inx: int) -> str:
    retVal = ''
    if self.check_cam_inx(cam_inx):
      retVal = self.config.get('CAMERAS', f'camera{cam_inx}_description')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_location(self, cam_inx: int) -> str:
    retVal = ''
    if self.check_cam_inx(cam_inx):
      retVal = self.config.get('CAMERAS', f'camera{cam_inx}_location')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_url(self, cam_inx: int) -> str:
    retVal = ''
    if self.check_cam_inx(cam_inx):
      retVal = self.config.get('CAMERAS', f'camera{cam_inx}_url')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_base_data_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'data_dir')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_stop_frame_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'stop_frame_dir')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ ROI (Region Of Interest) 
  def get_roi_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'roi_dir')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_detection_threshold(self) -> float:
    retVal = self.config.getfloat('YOLODetector', 'detection_threshold')
    return retVal