#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh\dataset_utilities
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ model index
#~ 0: YOLOv8n -> nano
#~ 1: YOLOv8s -> small
#~ 2: YOLOv8m -> medium
#~ 3: YOLOv8l -> large
#~ 4: YOLOv8x -> extra large
#~~~~~~~~~~~~~~~~~~~~~~~~
# python train_yolov8.py --yaml_file c:/perimeter_dataset/data.yaml --model_inx 2 --epochs 1
# python train_yolov8.py --yaml_file c:/perimeter_dataset/data.yaml --model_inx 2 --epochs 500
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ https://github.com/ultralytics/ultralytics
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
from ultralytics import YOLO
#~ передача аргументов через командную строку
import argparse
import time

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
  print('~'*70)
  print('[INFO] Train YOLOv8 Object Detection on a Custom Dataset ver.2024.01.29')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ парсер аргументов командной строки
  parser = argparse.ArgumentParser(description='Train YOLOv8 Object Detection on a Custom Dataset.')
  parser.add_argument('--yaml_file', type=str, default='', help='Path to data.yaml file')
  parser.add_argument('--model_inx', type=int, default=0, help='Ultralytics pretrained model')
  parser.add_argument('--epochs', type=int, default=1, help='Number of epochs')
  
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  print(f'[INFO] yaml_file: `{args.yaml_file}`')
  print(f'[INFO] model_inx: {args.model_inx}')
  print(f'[INFO] epochs: {args.epochs}')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ load a model
  model_mode = 'm'
  if 0 == args.model_inx:
    #~ 0: YOLOv8n -> nano
    model_mode = 'n'
  elif 1 == args.model_inx:
    #~ 1: YOLOv8s -> small
    model_mode = 's'
  elif 2 == args.model_inx:
    #~ 2: YOLOv8m -> medium
    model_mode = 'm'
  elif 3 == args.model_inx:
    #~ 3: YOLOv8l -> large
    model_mode = 'l'
  elif 4 == args.model_inx:
    #~ 4: YOLOv8x -> extra large
    model_mode = 'x'
  model_yaml_name = f'yolov8{model_mode}.yaml'
  model_pretrained_name = f'yolov8{model_mode}.pt'
  print('[INFO] model')
  print(f'[INFO]  yaml: `{model_yaml_name}`')
  print(f'[INFO]  pretrained: `{model_pretrained_name}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # model = YOLO(model_name)
  #~ build a new model from scratch
  #~ load a pretrained model (recommended for training)
  model = YOLO(model_yaml_name)  
  model = YOLO(model_pretrained_name)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('[INFO] start train...')
  #~ use the model
  #~ train the model
  #~~~~~~~~~~~~~~~~~~~~~~~~
  model.train(data=args.yaml_file, epochs=args.epochs)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  #~ засекаем время начала выполнения
  start_time = time.time()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  main()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ засекаем время окончания выполнения
  end_time = time.time()
  #~ вычисляем время выполнения
  execution_time = end_time - start_time
  print('='*70)
  print(f'[INFO] Program execution time: {execution_time:.1f} sec')
  print('='*70)
 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
# from ultralytics import YOLO

# # Load a model
# model = YOLO("yolov8n.yaml")  # build a new model from scratch
# model = YOLO("yolov8n.pt")  # load a pretrained model (recommended for training)

# # Use the model
# model.train(data="coco128.yaml", epochs=3)  # train the model
# metrics = model.val()  # evaluate model performance on the validation set
# results = model("https://ultralytics.com/images/bus.jpg")  # predict on an image
# path = model.export(format="onnx")  # export the model to ONNX format  
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# #~ evaluate model performance on the validation set
# metrics = model.val()
# #~ train the model
# # results = model.train(data="config.yaml", epochs=1)
# #~~~~~~~~~~~~~~~~~~~~~~~~
# #~ predict on an image
# # results = model("https://ultralytics.com/images/bus.jpg")
# # results = model("d:/yolo_dataset/fire/test/images/------2022-05-30-202825_png.rf.6b5e3a8db503af053ba8fa6f30b7040f.jpg")
# results = model("c:/yolo_dataset/fire/test/images/------2022-05-30-202825_png.rf.6b5e3a8db503af053ba8fa6f30b7040f.jpg")