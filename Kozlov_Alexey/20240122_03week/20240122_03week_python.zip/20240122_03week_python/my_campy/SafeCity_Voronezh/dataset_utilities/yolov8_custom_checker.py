#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh\dataset_utilities
# python yolov8_custom_checker.py
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
import cv2
import os
from ultralytics import YOLO
import datetime
import json
#~ библиотека для работы с массивами данных
import numpy as np

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ загрузка данных о зоне из файла JSON
#~ relative coordinates -> absolute coordinates
#~ преобразование относительных координат в относительные
def convert_relative_to_absolute(json_file, width, height):
  with open(json_file, 'r', encoding='utf-8') as file:
    data = json.load(file)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  zone_polygon = data['zone_polygon']
  #~~~~~~~~~~~~~~~~~~~~~~~~
  absolute_coordinates = []
  for point in zone_polygon:
    absolute_x = int(point[0] * width)
    absolute_y = int(point[1] * height)
    absolute_coordinates.append([absolute_x, absolute_y])
  #~~~~~~~~~~~~~~~~~~~~~~~~  
  return absolute_coordinates

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def is_centroid_in_polygon(centroid_coordinates, polygon_coordinates):
def is_centroid_in_polygon(x1, y1, x2, y2, polygon_coordinates):
  x_cen = (x1+x2)/2
  y_cen = (y1+y2)/2
  print(f'[INFO] x1: {x1}, x2: {x2}, x_cen: {x_cen}, y1: {y1}, y2: {y2}, y_cen: {y_cen}')
  #~ координаты центроида объекта
  centroid_coordinates = [x_cen, y_cen]
  point = np.array(centroid_coordinates)
  polygon = np.array(polygon_coordinates)
  #~ используем функцию pointPolygonTest из OpenCV
  is_inside = cv2.pointPolygonTest(polygon, point, False)
  return is_inside > 0

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main(cam_url, use_compression, compressed_width, compressed_height, out_fps):
  #~ путь к папке из которой запустили программу
  prog_path = os.getcwd()
  print(f'[INFO] prog_path: `{prog_path}`')
  print('[INFO] camera:')
  print(f'[INFO]  cam_url: `{cam_url}`')
  print(f'[INFO]  use_compression: `{use_compression}`')
  print(f'[INFO]  compressed_width: `{compressed_width}`')
  print(f'[INFO]  compressed_height: `{compressed_height}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ открываем видео-камеру
  # cap = cv2.VideoCapture(0)
  vcam = cv2.VideoCapture(cam_url)
  frame_width = 640
  frame_height = 480
  #~ сheck if camera opened successfully
  if not vcam.isOpened(): 
    print(f'[ERROR] can`t open video-camera')
    return
  ret, frame = vcam.read()
  if ret:
    frame_width = frame.shape[1]
    frame_height = frame.shape[0]
    print(f'[INFO]  original frame size: width: {frame.shape[1]}, height: {frame.shape[0]}')
  if use_compression:
    frame_width = compressed_width
    frame_height = compressed_height
  #~
  #~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ relative coordinates
  #~ absolute coordinates
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter7/ROI/garbage/20240126_152916.json'
  # # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter7/ROI/garbage/20240126_152650.json'
  #~
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240126_161942.json'
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240126_160017.json'
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240126_155633.json'
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240125_194306.json'
  json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240125_153748.json'
  # json_file = 'c:/my_campy/SafeCity_Voronezh/data/Perimeter17/ROI/person/20240125_153156.json'
  #~
  roi_zone = convert_relative_to_absolute(json_file, frame_width, frame_height)
  print(f'[INFO] frame: width: {frame_width}, height: {frame_height}')
  print(f'[INFO] roi_zone: len: {len(roi_zone)}, {roi_zone}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~
  #~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # #~ результирующий видео-файл
  # current_time = datetime.datetime.now()
  # video_file_name = current_time.strftime("%Y%m%d_%H%M%S") + ".mp4"
  # video_file_name2 = os.path.join(prog_path, video_file_name)
  # #~ определяем кодек и FPS для сохранения видео
  # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
  # vout = cv2.VideoWriter(video_file_name2, fourcc, out_fps, (frame_width, frame_height))
  # print(f'[INFO] result video-file: `{video_file_name2}`')
  # print(f'[INFO] result frame size: width: {frame_width}, height: {frame_height}')
  # print(f'[INFO] result frame per second: {round(out_fps,1)}')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ yolov8
  #~ load a model
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  model_path = 'yolov8m.pt'
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # model_path = os.path.join('.', 'runs', 'detect', 'train', 'weights', 'last.pt')
  # model_path = 'c:/my_campy/yolov8-utils/runs/detect/train5/weights/best.pt'
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ 2024.01.30 fire, garbage
  #~ Optimizer stripped from runs\detect\train3\weights\last.pt, 52.1MB
  #~ Optimizer stripped from runs\detect\train3\weights\best.pt, 52.1MB
  # model_path = 'c:/my_campy/SafeCity_Voronezh/dataset_utilities/runs/detect/train3/weights/best.pt'
  # model_path = 'c:/my_campy/SafeCity_Voronezh/dataset_utilities/runs/detect/train3/weights/last.pt'
  #~~~~~~~~~~~~~~~~~~~~~~~~
  print(f'[INFO] model path: `{model_path}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  model = YOLO(model_path)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  threshold = 0.5
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ perimeter8_class_names.txt
  #~ 0|person|человек|0: person
  #~ 1|bicycle|велосипед|1: bicycle
  #~ 2|car|машина|2: car
  #~ 3|motorcycle|мотоцикл|3: motorcycle
  #~ 4|bus|автобус|5: bus
  #~ 5|truck|грузовик|7: truck
  #~ 6|dog|собака|16: dog
  #~ 7|bottle|бутылка|39: bottle
  #~ #
  #~ 8|fire|огонь|
  #~ 9|garbage|мусор|
  #~
  special_class_id = 0

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ cчетчик стабильного детектирования stable detection counter
  counter1 = 0
  #~ порог стабильного детектирования -> СОБЫТИЕ ТРЕВОГИ -> ALARM -> stable detection threshold
  #~ 30 - кадров детектирования события
  threshold1 = 1 #30, 1
  flag1 = False
  #~ cчетчик отсутствия стабильного детектирования
  counter0 = 0
  threshold0 = 150
  #~ сигнал тревоги, если у нас происходит 30 событий детектирования 
  alarm_flag = False
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ garbage
  threshold = 0.1 #0.5, 0.1
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # # #~ pixels
  # # MARGIN = 10
  # #~ pixels
  # ROW_SIZE = 10
  # FONT_SIZE = 1
  # FONT_THICKNESS = 1
  # #~ red
  # # TEXT_COLOR = (255, 0, 0)
  # TEXT_COLOR = (0, 0, 255)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ чтение видео-кадров камеры в цикле
  # while (vcam.isOpened()):
  while True:
    ret, frame = vcam.read()    
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # if not ret:
    #   vcam.release()
    #   vcam = cv2.VideoCapture(cam_url)
    #   if not vcam.isOpened(): 
    #     break
    #   continue
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ break the loop
    #~ если просматриваем записанный видещ-файл
    if not ret:
      break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if use_compression:
      frame = cv2.resize(frame, (compressed_width, compressed_height))
    #~~~~~~~~~~~~~~~~~~~~~~~~

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ предсказание модели
    results = model(frame)[0]
    flag1 = False
    for result in results.boxes.data.tolist():
      x1, y1, x2, y2, score, class_id = result
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ проверка по id-класса
      class_id_int = int(class_id)
      # print(f'[INFO] special_class_id: {special_class_id}, class_id: {class_id}, class_id_int: {class_id_int}, score: {score}')
      if not special_class_id == class_id_int:
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ проверка по порогу
      if score < threshold:
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ patch by person foot
      person_h = int((y2 - y1)/4)
      y1 = y2 - person_h 
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # print(f'[INFO] x1: {x1}, y1: {y1}, x2: {x2}, y2: {y2}')
      is_roi_zone = is_centroid_in_polygon(x1, y1, x2, y2, roi_zone)
      if not is_roi_zone:
        continue
      #~ рамка вокруг детектированного объекта
      cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
      cv2.putText(frame, results.names[int(class_id)].upper(), (int(x1), int(y1 - 10)),
                  cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ одного детектирования достаточно
      #~ для инициализации флага детектирования указанного класса
      flag1 = True
      break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ проверяем детектирование на устойчивость
    print(f'[INFO] flag1: {flag1}')
    if flag1:
      #~ увеличение счетчика стабильного детектирования
      counter1 += 1
      print(f'[INFO] counter1: {counter1}, threshold1: {threshold1}')
      if counter1 >= threshold1:
        # print(f'[INFO] Stable detection: Person detected in the danger zone!')
        #~ здесь можно добавить код для сигнализации о стабильном нахождении человека в опасной зоне
        # print(f'[INFO] Stable detection: FIRE!')
        # print(f'[INFO] Stable detection: GARBAGE!')
        alarm_flag = True
        # counter1 = 0
        # counter0 = 0
    else:
      #~ сброс счетчика, если нет события alarm
      if alarm_flag:
        counter0 += 1
        if counter0 >= threshold0:
          alarm_flag = False
          counter1 = 0
          counter0 = 0
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ рисование полигона на кадре
    #~~~~~~~~~~~~~~~~~~~~~~~~
    cv2.polylines(frame, [np.array(roi_zone)], isClosed=True, color=(255, 0, 0), thickness=2)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] alarm_flag: `{alarm_flag}`')
    if alarm_flag:
      # text_location = (100, 100)
      # cv2.putText(frame, '--- FIRE ---', text_location, cv2.FONT_HERSHEY_PLAIN,
      #             FONT_SIZE, TEXT_COLOR, FONT_THICKNESS)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(img, (120, 20), (470, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(img, "PEOPLE DETECTED!!!", (130, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(frame, (120, 20), (470, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(frame, "PEOPLE DETECTED!!!", (130, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(frame, (120, 20), (580, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(frame, "--- FIRE DETECTED!!!---", (130, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(frame, (720, 20), (1260, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(frame, "--- GARBAGE DETECTED!!!---", (730, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(frame, (720, 20), (1305, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(frame, "--- PERSON UNDER ICICLES!!!---", (730, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.rectangle(frame, (720, 20), (1305, 80), (0, 0, 255), cv2.FILLED)
      # cv2.putText(frame, "--- PERSON UNDER ICICLES!!!---", (730, 60),
      #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      cv2.rectangle(frame, (720, 20), (1370, 80), (0, 0, 255), cv2.FILLED)
      cv2.putText(frame, "--- NOT PEDESTRIAN CROSSING!!!---", (730, 60),
                  cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # #~ сохраняем кадр в видеофайл
    # vout.write(frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ отображаем кадр
    cv2.imshow('yolov8-detector', frame)
    #~ если нажата клавиша 'q', выходим из цикла
    # if cv2.waitKey(25) & 0xFF == ord('q'):
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ освобождаем ресурсы
  vcam.release()
  # vout.release()
  cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  print('~'*70)
  print('[INFO]  Video Checker ver.2024.01.30')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Воронеж  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  out_fps = 25.0
  use_compression = True #~ True False
  compressed_width = 1804 #~ 1804, 1280
  compressed_height = 1014 #~ 1014, 720
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Perimeter17
  #~ Нейросеть_68/1 к 2_ периметр 17
  # cam_url = 'rtsp://w3.tv.kvant-telecom.ru/pyaterochka.test-132ba24f9a?dvr=true&token=2.9omxv2sXAx0ABfmU4bRWyoZBRA9FP2-s8JiufI9e3WRjgWAQ'
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Perimeter7
  #~ Нейросеть_МКД Спортивная 26/3 кам.7
  # cam_url = 'rtsp://w2.tv.kvant-telecom.ru/nejroset_mkd.sportivnaya.263.kam.7-0117f59297?dvr=true&token=2.hblfS1SFAx0ABgZT5ieesstBFAIyIIVX2QvV57kZUuXMt8Oe'
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ загружаю видео-файлы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter7_20240130_103955_dog.mp4'
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111114_falling_icicles.mp4'
  #~
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_youtube/fire1.mp4'
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_youtube/fire2.mp4'
  #~
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter7_20240126_123003_garbage.mp4'
  #~
  # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111114_falling_icicles.mp4'
  #~
  cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111245_not_pedestrian_crossing.mp4'

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  main(cam_url, use_compression, compressed_width, compressed_height, out_fps)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('='*70)
  print('[INFO] -> program completed!')