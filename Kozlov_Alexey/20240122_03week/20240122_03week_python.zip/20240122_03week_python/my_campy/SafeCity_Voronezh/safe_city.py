#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~~~~~~~~~~~~~~~~~~~~~~~~
# --scmode -> safecity mode -> тип режима
#    0: основной режим программы
#    1: проверка работы видеокамеры
#    2: сохранение cтоп-кадров с заданным интервалом
#    3: создание ROI (Region Of Interest) по стоп-кадру
#    4: yolov8+supervision детектирование указанных объектов в ROI (Region Of Interest)
# --cam_inx -> camera index -> индекс камеры
#    0..3: по ТЗ указаны 4-е камеры
# --frame_width, frame_height -> ширина и высота кадра в пикселях,  
#    если не указываем изменные размеры кадра, то работаем с оригинальными
# --stop_frame_ms -> интервал сохранения стоп кадров в миллисекундах
# --roi_image_name -> имя сохраненного стоп-кадра для создания зоны интереса
# --obj_inx 0 -> индексы объектов для детектирования
# --roi_json -> имя файла Region Of Interest в формате json
#~~~~~~~~~~~~~~~~~~~~~~~~
# python safe_city.py 
# python safe_city.py --scmode 1 --cam_inx 0
# python safe_city.py --scmode 1 --cam_inx 3
# python safe_city.py --scmode 1 --cam_inx 3 --frame_width 1280 --frame_height 720
# python safe_city.py --scmode 2 --cam_inx 3 --stop_frame_ms 5000
# python safe_city.py --scmode 2 --cam_inx 4 --stop_frame_ms 5000
# python safe_city.py --scmode 3 --cam_inx 3
# python safe_city.py --scmode 3 --cam_inx 4
# python safe_city.py --scmode 3 --cam_inx 3 --roi_image_name Perimetr17_20240125_091549_868.jpg
# python safe_city.py --scmode 3 --cam_inx 3 --roi_image_name Perimetr17_20240126_155129_430.jpg
# python safe_city.py --scmode 4 --cam_inx 3 --obj_inx 0 --roi_json 20240125_194306.json
#~~~~~~~~~~~~~~~~~~~~~~~~


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с массивами данных
import numpy as np
#~ библиотека для работы с графикой opencv
import cv2

from general_settings.settings_reader import TotalConfigurator
from video_processor.live_vcam_checker import LiveVCamChecker
from video_processor.live_vcam_stop_frame import LiveVCamStopFrame
from video_processor.roi_maker import ROIMaker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_live_vcam(cam_name: str, cam_url: str, frame_width: int, frame_height: int):
  vcam_checker = LiveVCamChecker(cam_name, cam_url, frame_width, frame_height)
  vcam_checker.watch_vstream()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def save_stop_frame(cam_name: str, cam_url: str, frame_width: int, frame_height: int,
                    prog_path: str, data_dir: str, stop_frame_dir: str, stop_frame_ms: int):
  sframe_maker = LiveVCamStopFrame(cam_name, cam_url, frame_width, frame_height,
                                   prog_path, data_dir, stop_frame_dir, stop_frame_ms)
  sframe_maker.save_infinitely_many()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_roi(cam_name: str, prog_path: str, data_dir: str, stop_frame_dir: str, roi_image_name: str, roi_dir: str):
  roi_maker_obj = ROIMaker(cam_name, prog_path, data_dir, stop_frame_dir, roi_image_name, roi_dir)
  person_dir = 'person'
  roi_maker_obj.save_person_region(person_dir)
 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
  print('~'*70)
  print('[INFO] Safe City Voronezh ver.2024.01.23')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ путь к папке из которой запустили программу
  prog_path = os.getcwd()
  print(f'[INFO] prog_path: `{prog_path}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ парсер аргументов командной строки
  parser = argparse.ArgumentParser(description='Safe City settings.')
  # parser.add_argument('--mode', choices=['observation', 'recording'], default='observation', help='Mode of the program (observation or recording)')
  parser.add_argument('--scmode', type=int, default=0, help='Mode of the program')
  parser.add_argument('--cam_inx', type=int, default=0, help='Index of the camera to use')
  parser.add_argument('--frame_width', type=int, default=0, help='Width of the frame in pixels, if zero then use original size')
  parser.add_argument('--frame_height', type=int, default=0, help='Height of the frame in pixels, if zero then use original size')
  parser.add_argument('--stop_frame_ms', type=int, default=1000, help='Interval in milliseconds for saving frames')
  parser.add_argument('--roi_image_name', type=str, default='', help='Name of the saved stop-frame image to create ROI')

  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ настройки из файла settings.ini
  totl_conf = TotalConfigurator(prog_path)
  cam_count = totl_conf.get_cam_count()
  cam_inx_isvalid = totl_conf.check_cam_inx(args.cam_inx)
  print('[INFO] camera:')
  print(f'[INFO]  count: {cam_count}')
  print(f'[INFO]  index: {args.cam_inx}')
  if not cam_inx_isvalid:
    print(f'[ERROR]  the index of camera is incorrect: {cam_inx_isvalid}')
    exit()
  cam_name = totl_conf.get_camera_name(args.cam_inx)
  cam_description = totl_conf.get_camera_description(args.cam_inx)
  cam_location = totl_conf.get_camera_location(args.cam_inx)
  cam_url = totl_conf.get_camera_url(args.cam_inx)
  print(f'[INFO]  name: `{cam_name}`')
  print(f'[INFO]  description: `{cam_description}`')
  print(f'[INFO]  location: `{cam_location}`')
  print(f'[INFO]  url: `{cam_url}`')
  if not (cam_name and cam_description and cam_location and cam_url):
    print('[ERROR]  The camera parameters are specified incorrectly')
    exit()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  data_dir = totl_conf.get_base_data_directory()
  stop_frame_dir = totl_conf.get_stop_frame_directory()
  roi_dir = totl_conf.get_roi_directory()
  print('[INFO] data directories:')
  print(f'[INFO]  base: `{data_dir}`')
  print(f'[INFO]  stop frame: `{stop_frame_dir}`')
  print(f'[INFO]  ROI: `{roi_dir}`')
  # #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ в зависимости от режима, аргумента командной строки, уходим на соответствующую ветку программы
  if 0 == args.scmode:
    pass
  elif 1 == args.scmode:
    check_live_vcam(cam_name, cam_url, args.frame_width, args.frame_height)
  elif 2 == args.scmode:
    save_stop_frame(cam_name, cam_url, args.frame_width, args.frame_height,
                    prog_path, data_dir, stop_frame_dir, args.stop_frame_ms)
  elif 3 == args.scmode:
    make_roi(cam_name, prog_path, data_dir, stop_frame_dir, args.roi_image_name, roi_dir)
  else:
    pass

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  main()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  print('='*70)
  print('[INFO] -> program completed!')