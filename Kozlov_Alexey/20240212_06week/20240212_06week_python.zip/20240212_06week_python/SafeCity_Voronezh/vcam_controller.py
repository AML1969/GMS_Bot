#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
# --cam_inx -> camera index -> индекс камеры
#    0..7: Заказчик предоставил 8 камер,
#    если параметр не указан, то cam_inx=0
#~~~~~~~~~~~~~~~~~~~~~~~~
# python vcam_controller.py
# python vcam_controller.py --cam_inx 1

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui

from utility_modules.settings_reader import SettingsReader

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Video Camera Controller
class VCamController:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self):
    print('~'*70)
    print('[INFO] Video Camera Controller ver.2024.02.02')
    print('~'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ парсер аргументов командной строки
    #~~~~~~~~~~~~~~~~~~~~~~~~
    parser = argparse.ArgumentParser(description='Video camera controller.')
    parser.add_argument('--cam_inx', type=int, default=0, help='Index of the camera to use')
    args = parser.parse_args()
    self.cam_inx = args.cam_inx
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    cam_count = ini_reader.get_cam_count()
    print('[INFO] camera:')
    print(f'[INFO]  count: {cam_count}')
    print(f'[INFO]  index: {self.cam_inx}')
    cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
    if not cam_inx_isvalid:
      print('[ERROR] the index of camera is incorrect')
      self.cam_inx = 0
      cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
      if not cam_inx_isvalid:
        self.cam_inx = -1
        exit()
      print(f'[INFO]  patch camera index: {self.cam_inx}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_name = ini_reader.get_camera_name(self.cam_inx)
    # cam_description = ini_reader.get_camera_description(self.cam_inx)
    # cam_location = ini_reader.get_camera_location(self.cam_inx)
    self.cam_url = ini_reader.get_camera_url(self.cam_inx)
    print(f'[INFO]  name: `{self.cam_name}`')
    # print(f'[INFO]  description: `{cam_description}`')
    # print(f'[INFO]  location: `{cam_location}`')
    print(f'[INFO]  url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]  original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      cv2.imshow(self.cam_name, frame)
      #~ если нажата клавиша 'q', выходим из цикла
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  vcam_obj = VCamController()
  vcam_obj.watch_video()
  print('='*70)
  print('[INFO] -> program completed!')