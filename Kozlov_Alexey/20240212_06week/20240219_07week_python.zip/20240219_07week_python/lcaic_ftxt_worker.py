#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ имя директории с доспупом пользователей
DIR_CREDENTIALS = 'credentials'
#~ доступ пользователей - логины, пароли и т.д.
FTXT_CREDENTIALS = 'ucredentials.txt'
#~ имя директории с описаниями моделей
DIR_MODELS = 'models'
#~ имя директории с данными для модели model2101
DIR_MODEL2101 = 'model2101'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ объект для работы с текстовыми
#~~~~~~~~~~~~~~~~~~~~~~~~
class FTXTWorker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, data_path):
    # self.data_path = data_path
    self.ind_list = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке с описаниями моделей
    self.models_path = os.path.join(data_path, DIR_MODELS)
    #~ путь к папке с данными для модели 3114
    self.model2101_path = os.path.join(data_path, DIR_MODEL2101)
    #~ путь к папке с доспупом пользователей
    self.credentials_path = os.path.join(data_path, DIR_CREDENTIALS)
    # print(f'FTXTWorker> data_path: {data_path}')
    # print(f'FTXTWorker> self.models_path: {self.models_path}')
    # print(f'FTXTWorker> self.model2101_path: {self.model2101_path}')
    # print(f'FTXTWorker> self.credentials_path: {self.credentials_path}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_credentials(self, user_login: str, user_password: str) -> str:
    """
    Проверяет наличие соответствующих логина и пароля в указанном файле.
    :param user_login: Логин пользователя.
    :param user_password: Пароль пользователя.
    :return: Кортеж (int - флаг, информация о клиенте).
             0 - пользователя нет в базе
             1 - пользователь есть и доступ разрешен
             2 - пользователь есть, но доступ запрещен
    """
    #~ 0     1        2      3  4        5    
    #~ login|password|access|id|FullName|Status
    #~ 0                 1     2 3 4                5    
    #~ natalia.tsarikova|pass8|0|8|Наталья Царикова|стажёр
    #~ alexey.v.kozlov|pass9|1|9|Козлов Алексей Вадимович|стажёр
    txt_fpath = os.path.join(self.credentials_path, FTXT_CREDENTIALS)
    # print(f'user_login: `{user_login}`')
    # print(f'user_password: `{user_password}`')
    # print(f'FTXT_CREDENTIALS: `{FTXT_CREDENTIALS}`')
    # print(f'txt_fpath: `{txt_fpath}`')
    with open(txt_fpath, 'r', encoding='UTF-8') as f:
      for line in f:
        data = line.strip().split('|')
        if 6 == len(data):
          if data[0] == user_login and data[1] == user_password:
            return data[2]+'|'+data[3]+'|'+data[4]+'|'+data[5]
    return ''

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_id_credentials(self, user_id: str) -> tuple:
    """
    Проверяет наличие соответствующего id пользователя в указанном файле.
    :param user_id: id-пользователя.
    :return: Кортеж (int - флаг, информация о клиенте).
             0 - пользователя нет в базе
             1 - пользователь есть и доступ разрешен
             2 - пользователь есть, но доступ запрещен
    """
    #~ 0     1        2      3  4        5    
    #~ login|password|access|id|FullName|Status
    txt_fpath = os.path.join(self.credentials_path, FTXT_CREDENTIALS)
    with open(txt_fpath, 'r', encoding='UTF-8') as f:
      for line in f:
        data = line.strip().split('|')
        if 6 == len(data):
          if data[3] == user_id:
            return data[2]+'|'+data[3]+'|'+data[4]+'|'+data[5]
    return ''

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def read_ind_list(self, txt_fpath):
    retVal = False
    self.ind_list.clear()
    with open(txt_fpath, 'r', encoding='UTF-8') as f:
      for line in f:
        data = line.strip().split('|')
        if 2 == len(data):
          list_len = len(self.ind_list)
          list_len_str = str(list_len)
          #print(f'list_len: `{list_len}`, list_len_str: `{list_len_str}`')
          if data[0] == list_len_str:
            self.ind_list.append(data[1])
          else:
            self.ind_list.clear()
            break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if len(self.ind_list) > 0:
      retVal = True
    #print(f'self.ind_list: len: `{len(self.ind_list)}`: {self.ind_list}')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def read_models_ind_list(self, txt_file_name):
    txt_fpath = os.path.join(self.models_path, txt_file_name)
    return self.read_ind_list(txt_fpath)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def read_model210_ind_list(self, txt_file_name):
    txt_fpath = os.path.join(self.model2101_path, txt_file_name)
    return self.read_ind_list(txt_fpath)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_ind_list(self):
    return self.ind_list