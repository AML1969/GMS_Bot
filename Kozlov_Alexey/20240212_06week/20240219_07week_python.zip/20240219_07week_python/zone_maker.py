#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
# --cam_inx -> camera index -> индекс камеры
#    0..7: Заказчик предоставил 8 камер,
#    если параметр не указан, то cam_inx=0
#~~~~~~~~~~~~~~~~~~~~~~~~
# python zone_maker.py
# python zone_maker.py --cam_inx 1

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string

from utility_modules.settings_reader import SettingsReader
from utility_modules.json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Zone Maker
class ZoneMaker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self):
    print('~'*70)
    print('[INFO] Zone Maker ver.2024.02.02')
    print('~'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    self.zones_path = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.points = []
    self.dragging = False
    self.selected_point_index = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ парсер аргументов командной строки
    #~~~~~~~~~~~~~~~~~~~~~~~~
    parser = argparse.ArgumentParser(description='Zone Maker.')
    parser.add_argument('--cam_inx', type=int, default=0, help='Index of the camera to use')
    args = parser.parse_args()
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_inx = args.cam_inx
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    cam_count = ini_reader.get_cam_count()
    print('[INFO] camera:')
    print(f'[INFO]  count: {cam_count}')
    print(f'[INFO]  index: {self.cam_inx}')
    cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
    if not cam_inx_isvalid:
      print('[ERROR] the index of camera is incorrect')
      self.cam_inx = 0
      cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
      if not cam_inx_isvalid:
        self.cam_inx = -1
        exit()
      print(f'[INFO]  patch camera index: {self.cam_inx}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_name = ini_reader.get_camera_name(self.cam_inx)
    # cam_description = ini_reader.get_camera_description(self.cam_inx)
    # cam_location = ini_reader.get_camera_location(self.cam_inx)
    self.cam_url = ini_reader.get_camera_url(self.cam_inx)
    print(f'[INFO]  name: `{self.cam_name}`')
    # print(f'[INFO]  description: `{cam_description}`')
    # print(f'[INFO]  location: `{cam_location}`')
    print(f'[INFO]  url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]  original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь для сохранения зон
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.zones_path = ini_reader.get_zones_directory()
    print(f'[INFO] zones path: `{self.zones_path}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def mouse_callback(self, event, x, y, flags, param):
    # print('[INFO] mouse_callback...')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ дистанция-радиус в пикселях - реакция на нажатие мышью рядом с узлом 
    dist_pix = 15
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if event == cv2.EVENT_LBUTTONDOWN:
      #~ добавление узла или инициализация режима перемещения узла
      for i, point in enumerate(self.points):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          self.dragging = True
          self.selected_point_index = i
          break
      if not self.dragging:
        self.points.append((x, y))
    elif event == cv2.EVENT_LBUTTONUP:
      #~ завершение режима перемещения узла
      self.dragging = False
      self.selected_point_index = -1
    elif event == cv2.EVENT_MOUSEMOVE:
      #~ перемещения узла
      if self.dragging and 0 <= self.selected_point_index < len(self.points):
        self.points[self.selected_point_index] = (x, y)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
      #~ удаление узла двойным кликом
      for i, point in enumerate(self.points):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          del self.points[i]
          break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] self.points: len: {len(self.points)}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ инициализация Callback по кликам мыши 
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print('[INFO] mouse callback is init ---1')
    cv2.namedWindow(self.cam_name)
    cv2.setMouseCallback(self.cam_name, self.mouse_callback)
    # print('[INFO] mouse callback is init ---2')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываю ребра и узлы
      if 1 == len(self.points):
        cv2.circle(frame, self.points[0], 5, (0, 0, 255), -1)
      elif len(self.points) > 1:
        for i in range(len(self.points)):
          cv2.line(frame, self.points[i-1], self.points[i], (255, 0, 0), 2)
        for i in range(len(self.points)):
          cv2.circle(frame, self.points[i], 5, (0, 0, 255), -1)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      cv2.imshow(self.cam_name, frame)
      #~ если нажата клавиша 'q', выходим из цикла
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_zone(self):
    if -1 == self.cam_inx:
      print('[WARNING] camera is not define')
      return
    if len(self.points) < 3:
      print('[WARNING] empty zone-points list')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    fname1 = input("Введите название зоны: ")
    #~ разрешенные символы для имени файла
    valid_chars = string.ascii_letters + string.digits + "._-" + "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    #~ приводим все буквы к нижнему регистру
    fname1 = fname1.lower()
    fname2 = ''.join(c if c in valid_chars else '' for c in fname1)
    #~ проверка на наличие недопустимых символов
    if os.path.sep in fname2:
      #~ удаляем слэши
      fname2 = fname2.replace(os.path.sep, '')
    # print(f'[INFO] fname2: `{fname2}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    json_obj = JSONWworker(self.zones_path, self.cam_name)
    json_obj.save_json_polygon(fname2, self.frame_width, self.frame_height, self.points)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  vcam_obj = ZoneMaker()
  vcam_obj.watch_video()
  vcam_obj.save_zone()
  print('='*70)
  print('[INFO] -> program completed!')