import os
import shutil
#~ работа с датой
from datetime import datetime
import json
#~ библиотека для работы с массивами данных
import numpy as np


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class JSONWworker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, working_dir: str, cam_name: str):
    self.cam_name = cam_name
    self.working_dir = os.path.join(working_dir, cam_name)
    # print(f'[INFO] cam_name: `{cam_name}`')
    # print(f'[INFO] self.working_dir: `{self.working_dir}`')
    if not os.path.exists(self.working_dir):
      os.makedirs(self.working_dir)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_json_polygon(self, fname: str, image_width: int, image_height: int, zone_lst):
    zones_len = len(zone_lst)
    # print(f'[INFO] fname: `{fname}`')
    # print(f'[INFO] image_width: {image_width}')
    # print(f'[INFO] image_height: {image_height}')
    # print(f'[INFO] nodes_len: {nodes_len}')
    if zones_len < 1:
      print(f'[ERROR] the number of nodes in the polygon is not enough')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    current_time_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    # print(f'[INFO] current_time_str: `{current_time_str}`')
    json_name = os.path.join(self.working_dir, f'{fname}_{self.cam_name}_{current_time_str}.json')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ преобразуем пиксельные координаты узлов в относительные координаты
    relative_zones = []
    for i in range(zones_len):
      nodes_len = len(zone_lst[i])
      if nodes_len < 3:
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      nodes_lst = []
      for j in range(nodes_len):
        x1,y1 = zone_lst[i][j]
        x2 = x1/image_width
        y2 = y1/image_height
        nodes_lst.append([x2, y2])
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if len(nodes_lst) > 2:
        relative_zones.append(nodes_lst)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем относительные координаты в файл json
    #~ json.dump - это функция из модуля json, которая используется для записи данных в формате JSON в файл.
    #~ Она принимает два аргумента: данные, которые нужно записать, и объект файла, в который нужно записать данные.
    #~ Что касается кодировки UTF-8, то обычно при работе с текстовыми данными в Python рекомендуется использовать
    #~ эту кодировку для сохранения файлов. Однако, при использовании json.dump, по умолчанию он будет записывать 
    #~ данные в формате UTF-8, поэтому не обязательно указывать это явно. Если вам нужно использовать другую кодировку, 
    #~ вы можете указать ее с помощью параметра encoding при открытии файла. Например, open(file_path, 'w', encoding='latin1').
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ и сохраняем файл на диск формате в JSON файл
    #~ json.dump(polygon_data, json_file, ensure_ascii=False) - эта часть кода использует функцию json.dump()
    #~ для записи данных из переменной polygon_data в файл json_file.
    #~ Параметр ensure_ascii=False указывает, что символы Unicode будут записаны в файл как есть,
    #~ без преобразования в ASCII.
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if len(relative_zones) > 0:
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if os.path.exists(json_name):
        os.remove(json_name)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      with open(json_name, 'w', encoding='utf-8') as file:
        json.dump(relative_zones, file)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # print(f'[INFO] json file is saved: `{json_name}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ загрузка полигонов из файла JSON, координаты относительные -> relative coordinates
  #~ json_name -> dog_corner_Perimeter4_20240302_181818.json
  def read_json_relative_polygon(self, json_name: str):
    relative_zones = []
    json_fname = os.path.join(self.working_dir, json_name)
    print(f'[INFO] json_fname: `{json_fname}`')
    if not os.path.exists(json_fname):
      print(f'[ERROR] file does not exist: `{json_fname}`')
      return relative_zones
    #~~~~~~~~~~~~~~~~~~~~~~~~
    with open(json_fname, 'r', encoding='utf-8') as file:
      relative_zones = json.load(file)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if len(relative_zones) < 1:
      return relative_zones
    #~~~~~~~~~~~~~~~~~~~~~~~~
    relative_zones2 = []
    for i in range(len(relative_zones)):
      if len(relative_zones[i]) > 2:
        relative_zones2.append(relative_zones[i])
    #~~~~~~~~~~~~~~~~~~~~~~~~
    return relative_zones2

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ загрузка полигонов из файла JSON, координаты абсолютные -> absolute coordinates
  #~ преобразование относительных координат в абсолютные
  #~ json_name -> dog_corner_Perimeter4_20240302_181818.json
  def read_json_absolute_polygon(self, json_name: str, image_width: int, image_height: int):
    absolute_zones = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    relative_zones = self.read_json_relative_polygon(json_name)
    if len(relative_zones) < 1:
      print(f'[ERROR] empty json file: `{json_name}`')
      return absolute_zones
    # print(f'[INFO] >relative_zones: len: {len(relative_zones)}: `{relative_zones}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    for i in range(len(relative_zones)):
      anodes = []
      for point in relative_zones[i]:
        absolute_x = int(point[0] * image_width)
        absolute_y = int(point[1] * image_height)
        anodes.append([absolute_x, absolute_y])
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if len(anodes) > 2:
        absolute_zones.append(anodes)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] >absolute_zones: len: {len(absolute_zones)}: `{absolute_zones}`')
    return absolute_zones
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ загрузка нулевого полигона из файла JSON
  def get_npzone(self, json_name: str, image_width: int, image_height: int):
    absolute_zones = self.read_json_absolute_polygon(json_name, image_width, image_height)
    np_zones = np.array(absolute_zones, np.int32)
    if len(absolute_zones) > 0:
      return np_zones[0]
    else:
      return np_zones