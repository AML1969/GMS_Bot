#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~   --cam_id -> id -> уникальный номер камеры
#~     0,  1,2,4,7,9,12,14,17: Заказчик предоставил 8 камер,
#~     если параметр не указан, то cam_id=1,
#~     0 индекс зарезервирован для камеры VideoPlayer -> отработка событий, типа 'пожар' и т.д.
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ клавиша 'esc' - выход из программы
#~~~~~~~~~~~~~~~~~~~~~~~~
# python crowd_detector1.py --cam_id 0


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
import shutil
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string
#~ работа со временем
import time
import math
#~ работа с датой
# from datetime import datetime
import datetime

from ultralytics import YOLO
import supervision as sv

from settings_reader import SettingsReader
from detection_reporter import DetectionReporter

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Crowd Detector - детектор толпы
class CrowdDetector:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_id: int):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.prog_path = os.getcwd()
    print(f'[INFO] program path: `{self.prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    self.frame_resize = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив зон
    self.zone_lst = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_id = args.cam_id
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(self.prog_path)
    id_lst = ini_reader.get_cam_lst()
    print(f'[INFO] camera id list: len: {len(id_lst)}: {id_lst}')
    self.cam_inx = ini_reader.get_cam_inx(self.cam_id, id_lst)
    print(f'[INFO] camera index: {self.cam_inx}')
    if -1 == self.cam_inx:
      print(f'[ERROR] camera id is incorrect: {self.cam_id}')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] Camera:')
    self.cam_name = ini_reader.get_camera_name(self.cam_id)
    self.cam_description = ini_reader.get_camera_description(self.cam_id)
    self.cam_url = ini_reader.get_camera_url(self.cam_id)
    print(f'[INFO]   id: {self.cam_id}')
    print(f'[INFO]   name: `{self.cam_name}`')
    print(f'[INFO]   description: `{self.cam_description}`')
    print(f'[INFO]   url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    alarm_directory = ini_reader.get_alarm_directory()
    self.det_rep = DetectionReporter(alarm_directory)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем камеру
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]   original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      self.frame_resize = True
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_resize = False
      print('[INFO] frame is not resize')
    print('-'*70)
    print(f'[INFO] final frame working sizes: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    print('-'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив числа детектирований людей в последних пяти кадрах
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ detections
    # self.person_dets = np.zeros(5, dtype='int16')
    self.person_dets = np.zeros(30, dtype='int16')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def delete_directory(self, path: str):
    if os.path.exists(path):
      try:
        shutil.rmtree(path)
        # print(f'[INFO] Directory was successfully deleted: `{path}`')
      except OSError as e:
        print(f'[ERROR] Error deleting a directory: `{path}`: {e.strerror}')
        return

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def make_directory(self, path: str):
    if not os.path.exists(path):
      os.makedirs(path)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def delete_make_directory(self, path: str):
    self.delete_directory(path)
    self.make_directory(path)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def format_counter(self, counter: int, digits: int):
    counter_str = str(counter)
    formatted_counter = counter_str.zfill(digits)
    return formatted_counter

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def calc_person_average(self, person_count: int):
    self.person_dets = np.roll(self.person_dets, -1)
    self.person_dets[-1] = person_count
    person_mean = np.mean(self.person_dets)
    #~ round округляет по 'банковским' правилам, т.е. к ближайшему чётному,
    #~ а не по правилам математического округления
    # person_average = int(person_mean + 0.5) if person_mean >= 0 else int(person_mean - 0.5)
    person_average = int(math.ceil(person_mean))
    return person_average

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ удаляема папку с сохраненнными кадрами  
    #~~~~~~~~~~~~~~~~~~~~~~~~
    test_dir = os.path.join(self.prog_path, 'test')
    # print(f'[INFO] test_dir: `{test_dir}`')
    self.delete_make_directory(test_dir)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем видео-картинку в видео-файл
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # current_time = datetime.datetime.now()
    # video_fname = current_time.strftime("%Y%m%d_%H%M%S") + ".mp4"
    # video_fname2 = os.path.join(self.prog_path, 'test', video_fname)
    # print(f'[INFO] video_fname2: `{video_fname2}`')
    #~ определяем кодек и FPS для сохранения видео
    # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # out_fps = 25.0
    # vout = cv2.VideoWriter(video_fname2, fourcc, out_fps, (self.frame_width, self.frame_height))
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру, сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ модель YOLO для детектирования людей, то есть толпы
    #~ model mode
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ n: YOLOv8n -> nano
    #~ s: YOLOv8s -> small
    #~ m: YOLOv8m -> medium
    #~ l: YOLOv8l -> large
    #~ x: YOLOv8x -> extra large
    #~
    model = YOLO("yolov8m.pt")
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ счетчики и необходимые переменный
    #~~~~~~~~~~~~~~~~~~~~~~~~
    frame_total_count = 0
    #~ порог сигнала тревоги -> если число людей person_average
    #~ превышает alarm_threshold, то создаем сигнеал тревоги 
    alarm_threshold = 7 #10 8 7
    #~ время последнего события тревоги
    alarm_time = time.time() # 0.0 time.time()
    # print(f'[INFO] alarm_time: {alarm_time}')
    #~ время в секундах между алармами, если разница по времени между текущим алармом и предыдущим
    #~ меньше чем adelta_time, то не фиксируем это событие аларм
    adelta_time = 15 #30 15
    #~ индикатор того, что детектор алармов ждет следующего окна возможности работы
    alarm_busy = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ m - message
    malarm_time1 = ''
    malarm_time2 = ''
    malarm_cam = ''
    malarm_type = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # cap.set(cv2.CAP_PROP_FRAME_WIDTH, frame_width)
      # cap.set(cv2.CAP_PROP_FRAME_HEIGHT, frame_height)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем ожидание нажатия кнопки выхода - `esc`
      if 27 == cv2.waitKey(1):
        print('[INFO] press key `esc` -> exit')
        break
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ читаем очередной кадр
      ret, frame = vcam.read()    
      if not ret:
        # vcam.release()
        # vcam = cv2.VideoCapture(self.cam_url)
        # if not vcam.isOpened():
        #   print('[ERROR] can`t open video-camera')
        #   break
        # continue
        break
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if self.frame_resize:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ yolo detect
      # yolo_dets = model(frame, verbose=False)[0]
      # yolo_dets = model(frame, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=640, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=320, nms=True, agnostic_nms=True,  verbose=False)[0]
      yolo_dets = model(frame, imgsz=960, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=1280, nms=True, agnostic_nms=True,  verbose=False)[0]
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ supervision count
      sv_dets = sv.Detections.from_ultralytics(yolo_dets)
      # sv_dets = sv_dets[(sv_dets.class_id == 0) & (sv_dets.confidence > 0.5) & mask]
      # sv_dets = sv_dets[sv_dets.class_id == 0]
      sv_dets = sv_dets[(sv_dets.class_id == 0) & (sv_dets.confidence > 0.6)]
      #~~~~~~~~~~~~~~~~~~~~~~~~
      sv_dets_len = len(sv_dets)
      #~ рассчитываем среднее число людей в кадре, по последним пяти кадрам
      person_average = self.calc_person_average(sv_dets_len)
      # if sv_dets_len < 1:
      #   cv2.imshow(self.cam_name, frame)
      #   continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ временное окно детектирования алармов закрыто
      if alarm_busy :
        cv2.rectangle(frame, (self.frame_width-460, 10), (self.frame_width-10, 150), (255, 255, 255), -1)
        cv2.putText(frame, malarm_time1, (self.frame_width-450, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, malarm_cam, (self.frame_width-450, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, malarm_type, (self.frame_width-450, 130), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.imshow(self.cam_name, frame)
        delta_time = time.time() - alarm_time
        if delta_time > adelta_time:
          alarm_busy = False
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем детектированные объекты
      #~ 2024.03.10 после debug перенести в секцию фиксации аларма
      for xyxy, _, confidence, _, _ in sv_dets:
        x_min = int(xyxy[0])
        y_min = int(xyxy[1])
        x_max = int(xyxy[2])
        y_max = int(xyxy[3])
        x_cen = (x_min + x_max) // 2
        y_cen = (y_min + y_max) // 2
        obj_label = str(round(confidence, 2))
        #~ красная линия от левого верхнего кадра до центра детектируемого объекта
        cv2.line(frame, (0, 0), (x_cen, y_cen), (0, 0, 255), 2)
        #~ рамка вокруг детектируемого объекта
        cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 0, 0), 2)
        cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (255, 255, 255), 1)
        cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (0, 0, 0), 2)
        cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (255, 255, 255), 1)
        #~ и рисование красной точки в центре person
        cv2.circle(frame, (x_cen, y_cen), 7, (0, 0, 255), -1)
        cv2.circle(frame, (x_cen, y_cen), 4, (255, 255, 255), -1)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем отображаем счетчик объектов person
      cv2.rectangle(frame, (10, 10), (245, 100), (255, 255, 255), -1)
      frame_message = f'person: {sv_dets_len}'
      cv2.putText(frame, frame_message, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
      message_str = f'average: {person_average}'
      cv2.putText(frame, frame_message, (20, 85), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем пороги
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if person_average > alarm_threshold:
          #~ произошло событие тревоги
          alarm_busy = True
          alarm_time = time.time()
          #~
          alarm_datetime = datetime.datetime.now()
          malarm_time1 = f'time: {alarm_datetime.strftime("%Y.%m.%d %H:%M:%S")}'
          malarm_cam = f'camera: {self.cam_name}'
          malarm_type = 'alarm: Crowd'
          malarm_time3 = alarm_datetime.strftime("%Y.%m.%d %H:%M:%S")
          malarm_time2 = alarm_datetime.strftime("%Y%m%d_%H%M%S")
          cv2.rectangle(frame, (self.frame_width-460, 10), (self.frame_width-10, 150), (255, 255, 255), -1)
          cv2.putText(frame, malarm_time1, (self.frame_width-450, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
          cv2.putText(frame, malarm_cam, (self.frame_width-450, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
          cv2.putText(frame, malarm_type, (self.frame_width-450, 130), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
          #~ фиксируем-сохраняем это событие событие
          self.det_rep.add_alarm(self.cam_inx, self.cam_name, malarm_time3, malarm_time2, 0, frame)



      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ сохраняем кадр для отладки
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # fname = f'f{self.format_counter(frame_total_count, 7)}.jpg'
      # fname2 = os.path.join(test_dir, fname)
      # print(f'[INFO] fname2: `{fname2}`')
      # cv2.imwrite(fname2, frame)
      # frame_total_count += 1
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ сохраняем кадр в видеофайл
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # vout.write(frame)

      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      #~~~~~~~~~~~~~~~~~~~~~~~~
      cv2.imshow(self.cam_name, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_execution_time(execution_time):
  if execution_time < 1:
    return f"{execution_time:.3f} sec"
  
  hours = int(execution_time // 3600)
  minutes = int((execution_time % 3600) // 60)
  seconds = int(execution_time % 60)

  if execution_time < 60:
    return f"{seconds}.{int((execution_time % 1) * 1000):03d} sec"
  elif execution_time < 3600:
    return f"{minutes} min {seconds:02d} sec"
  else:
    return f"{hours} h {minutes:02d} min {seconds:02d} sec"

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  start_time = time.time()
  print('~'*70)
  print('[INFO] Crowd Detector ver.2024.03.10')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ определяем параметры вызова камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  parser = argparse.ArgumentParser(description='Crowd Detector.')
  parser.add_argument('--cam_id', type=int, default=1, help='ID -> unique camera number')
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj = CrowdDetector(args.cam_id)
  #~ клавиша 'q' - выход из режима просмотра видео и зон
  vcam_obj.watch_video()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ вычисляем время работы программы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  execution_time = time.time() - start_time
  execution_time_str = format_execution_time(execution_time)
  print('='*70)
  print(f'[INFO] program execution time: {execution_time_str}')
  print('='*70)