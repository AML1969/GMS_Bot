#~ USAGE
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
# cd d:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
# python kvant_registration.py

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ https://kvant-telecom.ru
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
import flet as ft
import sqlite3
import os

from settings_reader import SettingsReader

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main(page: ft.Page):
  #~ https://kvant-telecom.ru
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ путь к папке из которой запустили программу
  #~~~~~~~~~~~~~~~~~~~~~~~~
  prog_path = os.getcwd()
  print(f'[INFO] prog_path: `{prog_path}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ настройки из файла settings.ini
  #~ путь к папке c базой данных
  #~~~~~~~~~~~~~~~~~~~~~~~~
  ini_reader = SettingsReader(prog_path)
  database_dir = ini_reader.get_database_directory()
  database_file = ini_reader.get_database_registration()
  if not os.path.exists(database_dir):
    os.makedirs(database_dir)
  database_path = os.path.join(database_dir, database_file)
  print(f'[INFO] database_dir: `{database_dir}`')
  print(f'[INFO] database_file: `{database_file}`')
  print(f'[INFO] database_path: `{database_path}`')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ логотип для виджета
  #~ путь к логотипу
  #~~~~~~~~~~~~~~~~~~~~~~~~
  logo_path = os.path.join(prog_path, 'logo.png')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ настройки основного виджета
  #~~~~~~~~~~~~~~~~~~~~~~~~
  page.title = 'KVANT registration ver.2024.03.02'
  page.theme_mode = 'dark' # light dark
  page.vertical_alignment = ft.MainAxisAlignment.CENTER
  page.window_width = 450      
  page.window_height = 500     
  page.window_resizable = False

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def validate(e):
    if all([user_login.value, user_pass.value, user_fio.value]):
      btn_reg.disabled = False
    else:
      btn_reg.disabled = True
      btn_reg.text = 'Добавить'
    page.update()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_user_login():
    retVal = True
    if not os.path.exists(database_path):
      return retVal 
    db = sqlite3.connect(database_path)
    cur = db.cursor()
    cur.execute("SELECT * FROM users")
    res = cur.fetchall()
    if res != None:
      for user in res:
        # print(f'[INFO] user: `{user}`')
        if user_login.value == user[1]:
          retVal = False
          break
    db.commit()
    db.close()
    # print(f'[INFO] retVal: `{retVal}`')
    return retVal 

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ добавление пользователя, если таблицы нет то она создается
  def register(e):
    if not check_user_login():
      user_login.value = 'Пользователь существует'
      user_pass.value = ''
      user_fio.value = ''
      btn_reg.text = 'Добавить'
      page.update()
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    db = sqlite3.connect(database_path)
    cur = db.cursor()
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ создаю таблицу, если ее нет
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      login TEXT,
      pass TEXT,
      fio TEXT
    )""")
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ добавляю пользователя в таблицу базы
    cur.execute(f"INSERT INTO users VALUES(NULL, '{user_login.value}', '{user_pass.value}', '{user_fio.value}')")
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняю изменения в базе
    db.commit()
    db.close()
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяю виджеты
    user_login.value = ''
    user_pass.value = ''
    user_fio.value = ''
    btn_reg.text = 'Добавлено'
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ обновляю страницу
    page.update()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  img_logo = ft.Image(src=logo_path)
  #~ виджет-ввода `логин`
  user_login = ft.TextField(label='Логин', width=300, on_change=validate)
  #~ виджет-ввода: `пароль`
  user_pass = ft.TextField(label='Пароль', password=True, width=300, on_change=validate)
  #~ виджет-ввода: `фамилия, имя, отчество`
  user_fio = ft.TextField(label='Ф.И.О.', width=300, on_change=validate)
  #~ виджет-кнопка `регистрация-добавление пользователя`
  btn_reg = ft.OutlinedButton(text='Добавить', width=300, on_click=register, disabled=True)
  # btn_auth = ft.OutlinedButton(text='Авторизовать', width=200, on_click=auth_user, disabled=True)
  #~ виджет-отображения списка пользователей
  users_list = ft.ListView(spacing=10, padding=20)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ панель c логотипом
  panel_logo = ft.Row(
    [
      ft.Column(
        [
          img_logo
        ]
      )
    ],
    alignment=ft.MainAxisAlignment.CENTER
  )

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ панель регистрации
  panel_register = ft.Row(
    [
      ft.Column(
        [
          ft.Text('Регистрация'),
          user_login,
          user_pass,
          user_fio,
          btn_reg
        ]
      )
    ],
    alignment=ft.MainAxisAlignment.CENTER
  )

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ панель список пользователей
  panel_ulist = ft.Row(
    [
      ft.Column(
        [
          ft.Text('Список пользователей'),
          users_list
        ]
      )
    ],
    alignment=ft.MainAxisAlignment.CENTER
  )

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ смена панелей, в зависимости от выбранного режима на навигационной панели
  def navigate(e):
    inx = page.navigation_bar.selected_index
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if inx < 2:
      page.clean()
      page.add(panel_logo)
      if 0 == inx:
        page.add(panel_register)
      elif 1 == inx:
        users_list.controls.clear()
        if os.path.exists(database_path):
          db = sqlite3.connect(database_path)
          cur = db.cursor()
          cur.execute("SELECT * FROM users")
          res = cur.fetchall()
          if res != None:
            for user in res:
              # print(f'[INFO] user: `{user}`')
              users_list.controls.append(ft.Row([
              ft.Icon(ft.icons.VERIFIED_USER_ROUNDED),
              ft.Text(f'login: `{user[1]}`, Ф.И.О.: `{user[3]}`')
            ]))
          db.commit()
          db.close()
        else:
          users_list.controls.append(
            ft.Row(
              [
                ft.Icon(ft.icons.ERROR_OUTLINE),
                ft.Text(f'нет данных')
              ]
          ))
        page.add(panel_ulist)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      user_login.value = ''
      user_pass.value = ''
      user_fio.value = ''
      btn_reg.text = 'Добавить'
    elif 2 == inx:
      page.theme_mode = 'light' if page.theme_mode == 'dark' else 'dark'
    #~~~~~~~~~~~~~~~~~~~~~~~~
    page.update()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ навигационная панель внизу страницы, кнопки - вызовы режимов-панелей
  page.navigation_bar = ft.NavigationBar(
    destinations=[
      ft.NavigationDestination(icon=ft.icons.VERIFIED_USER_OUTLINED, label="Регистрация"),
      ft.NavigationDestination(icon=ft.icons.VERIFIED_USER, label="Список пользователей"),
      ft.NavigationDestination(icon=ft.icons.SUNNY, label="Выбор темы"),
    ], on_change=navigate
  )

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ последовательно добавляем панели на страницу
  page.add(panel_logo)
  page.add(panel_register)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ запуск приложения в desktop-ом режиме
ft.app(target=main)
#~ запуск приложения в режиме web
# ft.app(target=main, view=ft.AppView.WEB_BROWSER)