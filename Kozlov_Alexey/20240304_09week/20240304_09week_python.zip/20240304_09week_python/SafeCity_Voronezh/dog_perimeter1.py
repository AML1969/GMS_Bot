#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~   --cam_inx -> индекс камеры
#~     0 индекс зарезервирован для камеры VideoPlayer -> отработка событий, типа 'пожар' и т.д.
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ клавиша 'esc' - выход из программы
#~~~~~~~~~~~~~~~~~~~~~~~~
# python dog_perimeter1.py --cam_inx 3 --zone_fname car_corner_Perimeter4_20240312_132946.json
# python dog_perimeter1.py --cam_inx 3 --zone_fname dog_corner_Perimeter4_20240312_134241.json


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
import shutil
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string
#~ работа со временем
import time
import math
#~ работа с датой
# from datetime import datetime
import datetime

from ultralytics import YOLO

from settings_reader import SettingsReader
from detection_reporter import DetectionReporter
from json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Crowd Detector - детектор толпы
class CrowdDetector:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_inx: int, zone_fname: str):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.prog_path = os.getcwd()
    print(f'[INFO] program path: `{self.prog_path}`')
    self.cam_inx = cam_inx
    self.cam_name = ''
    self.cam_url = ''
    self.frame_resize = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив зон
    self.zone_lst = []
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(self.prog_path)
    if not ini_reader.camera_is_valid(self.cam_inx):
      print(f'[ERROR] camera index is incorrect: {self.cam_inx}')
      self.cam_inx = -1
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем параметры камеры
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] Camera:')
    self.cam_name = ini_reader.get_camera_name(self.cam_inx)
    self.cam_description = ini_reader.get_camera_description(self.cam_inx)
    self.cam_url = ini_reader.get_camera_url(self.cam_inx)
    print(f'[INFO]   inx: {self.cam_inx}')
    print(f'[INFO]   name: `{self.cam_name}`')
    print(f'[INFO]   description: `{self.cam_description}`')
    print(f'[INFO]   url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    alarm_directory = ini_reader.get_alarm_directory()
    self.det_rep = DetectionReporter(alarm_directory)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем камеру
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]   original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    print('-'*70)
    print(f'[INFO] frame sizes: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    print('-'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив числа детектирований людей в последних пяти кадрах
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ detections
    # self.feature_dets = np.zeros(5, dtype='int16')
    # self.feature_dets = np.zeros(30, dtype='int16')
    self.feature_dets = np.zeros(1, dtype='int16')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ загружаем зону
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.zone_dir = ini_reader.get_zones_directory()
    json_obj = JSONWworker(self.zone_dir, self.cam_name)
    self.npzone = json_obj.get_npzone(zone_fname, self.frame_width, self.frame_height)
    print(f'[INFO] self.npzone: len: {len(self.npzone)}: `{self.npzone}`')
    #~ координаты центроида объекта
    self.feature_cen = [0.0, 0.0]

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def calc_feature_average(self, feature_count: int):
    self.feature_dets = np.roll(self.feature_dets, -1)
    self.feature_dets[-1] = feature_count
    feature_mean = np.mean(self.feature_dets)
    #~ round округляет по 'банковским' правилам, т.е. к ближайшему чётному,
    #~ а не по правилам математического округления
    # feature_average = int(feature_mean + 0.5) if feature_mean >= 0 else int(feature_mean - 0.5)
    feature_average = int(math.ceil(feature_mean))
    return feature_average

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру, сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ модель YOLO для детектирования людей, то есть толпы
    #~ model mode
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ n: YOLOv8n -> nano
    #~ s: YOLOv8s -> small
    #~ m: YOLOv8m -> medium
    #~ l: YOLOv8l -> large
    #~ x: YOLOv8x -> extra large
    #~
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ https://docs.ultralytics.com/ru/datasets/detect/coco/#dataset-yaml
    #~  0: person
    #~  1: bicycle
    #~  2: car
    #~  3: motorcycle
    #~  4: airplane
    #~  5: bus
    #~  6: train
    #~  7: truck
    #~  8: boat
    #~  9: traffic light
    #~  10: fire hydrant
    #~  11: stop sign
    #~  12: parking meter
    #~  13: bench
    #~  14: bird
    #~  15: cat
    #~  16: dog
    #~~~~~~~~~~~~~~~~~~~~~~~~
    model = YOLO("yolov8m.pt")
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # model = YOLO('c:/my_campy/SafeCity_Voronezh/data_in/weights/best.pt')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ счетчики и необходимые переменный
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ порог сигнала тревоги -> если feature_average
    #~ превышает alarm_threshold, то создаем сигнеал тревоги 
    alarm_threshold = 1 #10 8 7
    #~ время последнего события тревоги
    alarm_time = time.time() # 0.0 time.time()
    # print(f'[INFO] alarm_time: {alarm_time}')
    #~ время в секундах между алармами, если разница по времени между текущим алармом и предыдущим
    #~ меньше чем adelta_time, то не фиксируем это событие аларм
    adelta_time = 15 #30 15
    #~ индикатор того, что детектор алармов ждет следующего окна возможности работы
    alarm_busy = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~  2: car
    #~  16: dog
    aclass_id = 16
    athreshold = 0.2
    
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ m - message
    malarm_time1 = ''
    malarm_time2 = ''
    malarm_cam = ''
    malarm_type = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки кадра и т.д.
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ размер кадра без изменений
    #~ [INFO] frame sizes: width: 2304, height: 1296, ratio: 1.77778
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ устанавливаю размеры кадра
    #~ 2024.03.12. Вроронеж rtsp камера Perimetr4
    #~ vcam.set(cv2.CAP_PROP_FRAME_WIDTH, 1804)
    #~ vcam.set(cv2.CAP_PROP_FRAME_HEIGHT, 1015)
    #~ [INFO] frame sizes: width: 2304, height: 1296, ratio: 1.77778
    #~ то есть не работают эти настройки для этой камеры
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ аналогичным образом пытаюсь настроить частоту кадров  
    # desired_fps = 1 #10 1
    # vcam.set(cv2.CAP_PROP_FPS, desired_fps)
    #~ и это также не работает на Воронежских камерах
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    fps = vcam.get(cv2.CAP_PROP_FPS)
    if fps < 1:
      fps = 1
    print(f'[INFO] frames per second: {fps}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    frame_num = 0
    frame_threshold = int(fps)
    print(f'[INFO] frame_threshold: {frame_threshold}')
    while True:
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем ожидание нажатия кнопки выхода - `esc`
      #~~~~~~~~~~~~~~~~~~~~~~~~
      key_press = cv2.waitKey(1) & 0xFF
      if 27 == key_press:
        print('[INFO] press key `esc` -> exit')
        break
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ читаем очередной кадр
      #~~~~~~~~~~~~~~~~~~~~~~~~
      ret, frame = vcam.read()    
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
        #~
        # break
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем псевдо fps - frames per second
      #~ то есть кадры из камеры вычитываем все, но в обработку идет каждый N-ый
      #~~~~~~~~~~~~~~~~~~~~~~~~
      frame_num += 1
      if frame_num < frame_threshold:
        continue
      frame_num = 0
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ текущие размеры кадра
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # print()
      # print('-'*70)
      # print(f'[INFO] frame sizes: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ yolo detect
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ предсказание модели
      # results = model(frame)[0]
      #~
      # yolo_dets = model(frame, verbose=False)[0]
      # yolo_dets = model(frame, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=640, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=320, nms=True, agnostic_nms=True,  verbose=False)[0]
      yolo_dets = model(frame, imgsz=960, nms=True, agnostic_nms=True,  verbose=False)[0]
      # yolo_dets = model(frame, imgsz=1280, nms=True, agnostic_nms=True,  verbose=False)[0]
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем зоны-полигоны
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # if len(len(self.zone0)) > 1:
      for i in range(len(self.npzone)):
        cv2.line(frame, self.npzone[i-1], self.npzone[i], (255, 0, 0), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ обрабатываем детектированные сущности
      #~~~~~~~~~~~~~~~~~~~~~~~~
      # print(f'[INFO] yolo_dets: len: {len(yolo_dets)}, `{yolo_dets}`')
      alarm_feature = False
      for yores in yolo_dets.boxes.data.tolist():
        yox1, yoy1, yox2, yoy2, yoscore, yoclass_id = yores
        class_id = int(yoclass_id)
        # print(f'[INFO] yox1: {yox1}, yoy1: {yoy1}, yox2: {yox2}, yoy2: {yoy2}')
        # print(f'[INFO] yoscore: {yoscore}, yoclass_id: {yoclass_id}, class_id: {class_id}')
        if not aclass_id == class_id:
          continue
        if yoscore < athreshold:
          continue
        #~~~~~~~~~~~~~~~~~~~~~~~~
        x1 = int(yox1)
        y1 = int(yoy1)
        x2 = int(yox2)
        y2 = int(yoy2)
        y1 = y2 - int((y2-y1)/8)
        x3 = (x1 + x2) // 2
        y3 = (y1 + y2) // 2
        self.feature_cen[0] = x3
        self.feature_cen[1] = y3
        #~ используем функцию pointPolygonTest из OpenCV
        is_inside = cv2.pointPolygonTest(self.npzone, self.feature_cen, False)
        if is_inside > 0:
          alarm_feature = True
          feature_lbl = str(round(yoscore, 2))
          #~ красная линия от левого верхнего кадра до центра детектируемого объекта
          cv2.line(frame, (0, 0), (x3, y3), (0, 0, 255), 2)
          #~ рамка вокруг детектируемого объекта
          cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 0), 2)
          cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 255), 1)
          cv2.putText(frame, feature_lbl, (x1+3, y1-7), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (0, 0, 0), 2)
          cv2.putText(frame, feature_lbl, (x1+3, y1-7), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (255, 255, 255), 1)
          #~ и рисование красной точки в центре person
          cv2.circle(frame, (x3, y3), 7, (0, 0, 255), -1)
          cv2.circle(frame, (x3, y3), 4, (255, 255, 255), -1)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ фиксируем alarm
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if alarm_feature: 
        alarm_datetime = datetime.datetime.now()
        malarm_time1 = f'time: {alarm_datetime.strftime("%Y.%m.%d %H:%M:%S")}'
        malarm_cam = f'camera: {self.cam_name}'
        # malarm_type = 'alarm: Crowd'
        malarm_type = 'alarm: Dog'
        malarm_time3 = alarm_datetime.strftime("%Y.%m.%d %H:%M:%S")
        malarm_time2 = alarm_datetime.strftime("%Y%m%d_%H%M%S")
        cv2.rectangle(frame, (self.frame_width-460, 10), (self.frame_width-10, 150), (255, 255, 255), -1)
        cv2.putText(frame, malarm_time1, (self.frame_width-450, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, malarm_cam, (self.frame_width-450, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, malarm_type, (self.frame_width-450, 130), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        #~ фиксируем-сохраняем это событие событие
        # self.det_rep.add_alarm(self.cam_inx, self.cam_name, malarm_time3, malarm_time2, 0, frame)
        self.det_rep.add_alarm(self.cam_inx, self.cam_name, malarm_time3, malarm_time2, 2, frame)

      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      #~~~~~~~~~~~~~~~~~~~~~~~~
      cv2.imshow(self.cam_name, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_execution_time(execution_time):
  if execution_time < 1:
    return f"{execution_time:.3f} sec"
  
  hours = int(execution_time // 3600)
  minutes = int((execution_time % 3600) // 60)
  seconds = int(execution_time % 60)

  if execution_time < 60:
    return f"{seconds}.{int((execution_time % 1) * 1000):03d} sec"
  elif execution_time < 3600:
    return f"{minutes} min {seconds:02d} sec"
  else:
    return f"{hours} h {minutes:02d} min {seconds:02d} sec"

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  start_time = time.time()
  print('~'*70)
  print('[INFO] Crowd Detector ver.2024.03.12')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ определяем параметры вызова камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  parser = argparse.ArgumentParser(description='Crowd Detector.')
  parser.add_argument('--cam_inx', type=int, default=1, help='camera index')
  parser.add_argument('--zone_fname', type=str, default='', help='Path to the zone json file')
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj = CrowdDetector(args.cam_inx, args.zone_fname)
  #~ клавиша 'q' - выход из режима просмотра видео и зон
  vcam_obj.watch_video()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ вычисляем время работы программы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  execution_time = time.time() - start_time
  execution_time_str = format_execution_time(execution_time)
  print('='*70)
  print(f'[INFO] program execution time: {execution_time_str}')
  print('='*70)