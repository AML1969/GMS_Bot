#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
# python kvant_server.py
#~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ сервер
#~~~~~~~~~~~~~~~~~~~~~~~~
#~~~ после установки FastAPI и uvicorn, можно запустить сервер с помощью команды:
# uvicorn main:app --host 0.0.0.0 --port 8000
# uvicorn kvant_server:app --host 127.0.0.1 --port 8000
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# uvicorn kvant_server:app --host 192.168.2.245 --port 8000
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ клиент
#~ http://127.0.0.1:8000/exit
#~~~~~~~~~~~~~~~~~~~~~~~~
# http://127.0.0.1:8000
# http://127.0.0.1:8000/camcount
# http://127.0.0.1:8000/camnamelst
# http://127.0.0.1:8000/camurl?cam_inx=3

#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
from fastapi import FastAPI
import uvicorn
from threading import Thread
# from rtsp_stream import RTSPStream
# from yolo_detector import YOLODetector
# import subprocess

#~ библиотека для вызова системных функций
import os

from settings_reader import SettingsReader


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class FastAPIServer:
  def __init__(self):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('~'*70)
    print('[INFO] KVANT Server ver.2024.03.13')
    print('~'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.prog_path = os.getcwd()
    print(f'[INFO] program path: `{self.prog_path}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # self.config = configparser.ConfigParser()
    # self.config.read('settings.ini')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ читаем настройки из ini-фала
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(self.prog_path)
    self.serv_host = ini_reader.get_server_host()
    self.serv_port = ini_reader.get_server_port()
    print('[INFO] FastAPI server:')
    print(f'[INFO]   host: `{self.serv_host}`, port: {self.serv_port}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ создаем FastAPI-Сервер
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.app = FastAPI()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def start(self):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @self.app.get("/")
    async def read_root():
      print('[INFO] FastAPIServer.read_root')
      # return {"message": "Hello, World!"}
      return {"message": "Server is running."}

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @self.app.get("/camcount")
    async def get_camcount():
      print('[INFO] FastAPIServer.get_camcount')
      ini_reader = SettingsReader(self.prog_path)
      cam_count = ini_reader.get_cam_total_number()
      camcount_str = str(cam_count)
      print(f'[INFO]  camera count: {camcount_str}')
      return {"camcount": camcount_str}

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @self.app.get("/camnamelst")
    async def get_camnamelst():
      print('[INFO] FastAPIServer.get_camnamelst')
      ini_reader = SettingsReader(self.prog_path)
      cam_count = ini_reader.get_cam_total_number()
      camnamelst_str = ''
      for i in range(cam_count):
        camnamelst_str += ini_reader.get_camera_name(i)
        if i < (cam_count - 1):
          camnamelst_str += '|'
      print(f'[INFO]  camera name list: {camnamelst_str}')
      return {"camnamelst": camnamelst_str}

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @self.app.get("/camurl")
    async def get_camurl(cam_inx: int = 0):
      print(f'[INFO] FastAPIServer.get_camurl: cam_inx: {cam_inx}')
      ini_reader = SettingsReader(self.prog_path)
      cam_count = ini_reader.get_cam_total_number()
      cam_url = ''
      if 0 <= cam_inx < cam_count:
        cam_url = ini_reader.get_camera_url(cam_inx)
      print(f'[INFO]  camera url: {cam_url}')
      return {"cam_url": cam_url}


    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # import uvicorn
    uvicorn.run(self.app, host=self.serv_host, port=self.serv_port)
    # uvicorn.run(self.app, host=self.config['server']['host'], port=int(self.config['server']['port'])


# @app.get("/")
# async def read_root():
#   print('[INFO] FastAPI: read_root...')
#   return {"message": "Server is running."}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# app = FastAPI()

# class VideoStream:
#     def __init__(self):
#         self.rtsp_stream = RTSPStream()
#         self.yolo_detector = YOLODetector()

# def start_video_stream(video_stream):
#     video_stream.rtsp_stream.start()
#     video_stream.yolo_detector.start()

# video_stream1 = VideoStream()
# video_stream2 = VideoStream()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @app.on_event("startup")
# async def startup_event():
#     thread1 = Thread(target=start_video_stream, args=(video_stream1,))
#     thread2 = Thread(target=start_video_stream, args=(video_stream2,))
#     thread1.start()
#     thread2.start()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @app.get("/")
# async def read_root():
#   print('[INFO] FastAPI: read_root...')
#   return {"message": "Server is running."}

# #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @app.get("/exit")
# # def shutdown_server():
# async def shutdown_server():
#   print('[INFO] FastAPI: shutdown_server...')
#   print("Выполняется команда выхода. Сервер будет остановлен.")
#   #~ Завершаем процесс uvicorn
#   subprocess.call(["pkill", "uvicorn"])
#   return {"message": "Сервер остановлен"}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  server = FastAPIServer()
  server.start()