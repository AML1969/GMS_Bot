#~~~~~~~~~~~~~~~~~~~~~~~~
#~ c:/
#~ d:/
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import configparser
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class SettingsReader:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, data_path: str):
    config_filename = os.path.join(data_path, 'settings.ini')
    self.config = configparser.ConfigParser()
    self.config.read(config_filename)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_server_host(self) -> str:
    retVal = self.config.get('SERVER', 'host')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_server_port(self) -> int:
    retVal = self.config.getint('SERVER', 'port')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_total_number(self) -> int:
    retVal = self.config.getint('CAMERAS', 'total_number')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def camera_is_valid(self, cam_inx: int) -> bool:
    retVal = False
    cam_total_number = self.get_cam_total_number()
    # print(f'[INFO] cam_inx: {cam_inx}, cam_total_number: {cam_total_number}')
    if -1 < cam_inx and cam_inx < cam_total_number: 
      retVal = True
    # print(f'[INFO] retVal: {retVal}')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_name(self, cam_inx: int) -> str:
    retVal = 'none'
    if not self.camera_is_valid(cam_inx):
      return retVal
    id_cam = self.config.get(f'CAMERA{cam_inx}', 'id')
    retVal = f'Perimeter{id_cam}' 
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_description(self, cam_inx: int) -> str:
    retVal = 'none'
    if not self.camera_is_valid(cam_inx):
      return retVal
    retVal = self.config.get(f'CAMERA{cam_inx}', 'description')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_url(self, cam_inx: int) -> str:
    retVal = 'none'
    if not self.camera_is_valid(cam_inx):
      return retVal
    retVal = self.config.get(f'CAMERA{cam_inx}', 'url')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_database_directory(self) -> str:
    return self.config.get('DATA_BASE', 'directory')

  def get_database_registration(self) -> str:
    return self.config.get('DATA_BASE', 'registration')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Zones (ROI - Region Of Interest)
  def get_zones_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'zones')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_alarm_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'alarm')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_detection_threshold(self) -> float:
    retVal = self.config.getfloat('YOLODetector', 'detection_threshold')
    return retVal