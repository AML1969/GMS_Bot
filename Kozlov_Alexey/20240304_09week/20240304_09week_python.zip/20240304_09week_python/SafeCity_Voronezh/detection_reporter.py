import os
import shutil
import cv2
from datetime import datetime

import threading
import requests


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ типы алармов
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ 0: Crowd: толпа (скопление людей)
#~ 1: Perimeter: пересечение периметра

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class DetectionReporter:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, alarm_directory: str):
    #~ путь к папкам с отчетами
    self.alarm_dir = alarm_directory
    print(f'[INFO] alarm directory: `{self.alarm_dir}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.make_directory(os.path.join(self.alarm_dir, 'crowd'))
    self.make_directory(os.path.join(self.alarm_dir, 'perimeter'))
    self.make_directory(os.path.join(self.alarm_dir, 'dog'))
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.alarm_img_fname = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~



    # self.detreport_path = os.path.join(prog_path, DIR_DET_REPORT)
    # self.cam_names = cam_names
    # #~~~~~~~~~~~~~~~~~~~~~~~~
    # # print(f'->DetectionReporter: detreport_path `{self.detreport_path}`')
    # # print(f'->DetectionReporter: cam_names: len: `{len(cam_names)}`, `{self.cam_names}`')
    # self.cam_dirs = []
    # self.report_names = []
    # for i in range(len(self.cam_names)):
    #   # print(f'{i}->{len(self.cam_names)}')
    #   idir_path = os.path.join(self.detreport_path, self.cam_names[i])
    #   self.cam_dirs.append(idir_path)
    #   # print(f'  cam_dirs: len: `{len(self.cam_dirs)}`, `{self.cam_dirs}`')
    #   str_line = f'person_{self.cam_names[i]}.txt'
    #   report_name = os.path.join(idir_path, str_line)
    #   # print(f'  str_line: `{str_line}`')
    #   # print(f'  report_name: `{report_name}`')
    #   self.report_names.append(report_name)
    #   if not os.path.exists(idir_path):
    #     os.makedirs(idir_path)
    #     with open(report_name, 'w', encoding='UTF-8') as file_report:
    #       file_report.write(f'Person: {self.cam_names[i]}\n')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def delete_directory(self, path: str):
    if os.path.exists(path):
      try:
        shutil.rmtree(path)
        # print(f'[INFO] Directory was successfully deleted: `{path}`')
      except OSError as e:
        print(f'[ERROR] Error deleting a directory: `{path}`: {e.strerror}')
        return

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def make_directory(self, path: str):
    if not os.path.exists(path):
      os.makedirs(path)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def delete_make_directory(self, path: str):
    self.delete_directory(path)
    self.make_directory(path)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def check_file_existence(self, file_path: str) -> bool:
    return os.path.exists(file_path)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ send to my telegram-bot
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # def sendTelegram(self, img_fname: str, alarm_type: str):
  def sendTelegram(self):
    # path = 'C://Users/ASUS/PycharmProjects/ArduMeka_CCTV/img/'  # Replace your path directory
    # url = 'https://api.telegram.org/bot'
    # token = "REPLACE_YOUR_TOKEN_HERE"  # Replace Your Token Bot
    # chat_id = "1234567890"  # Replace Your Chat ID
    # caption = "People Detected!!! "
    # cv2.imwrite(os.path.join(path, img_name), img)
    # files = {'photo': open(path + img_name, 'rb')}
    # resp = requests.post(url + token + '/sendPhoto?chat_id=' + chat_id + '&caption=' + caption, files=files)
    # print(f'Response Code: {resp.status_code}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] send-send to telebot...')
    # print(f'   11-> tele_ffname: `{tele_ffname}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    url = 'https://api.telegram.org/bot'
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ @falconvision_bot
    token = "6980627455:AAHzUGNw0cSCpk0uy7kkWyHbSuubqs8bbPI"
    chat_id = "6980627455"
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ из этого бота получил id: https://t.me/getmyid_bot
    #~ @Alexey_V_Kozlov
    #~ Your user ID: 1124106232
    #~ Current chat ID: 1124106232
    # Id: 1124106232
    # First: Alexey.V.Kozlov
    # Lang: ru
    chat_id = "1124106232"
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # caption = 'alarm: Crowd'
    caption = 'alarm: Perimeter'
    files = {'photo': open(self.alarm_img_fname, 'rb')}
    resp = requests.post(url + token + '/sendPhoto?chat_id=' + chat_id + '&caption=' + caption, files=files)
    print(f'[INFO] telebot response code: {resp.status_code}')
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_crowd(self, cam_inx: int, cam_name: str, alarm_time1: str, alarm_time2: str, frame):
    # crowd_dir = os.path.join(self.alarm_dir, 'crowd')
    img_name = f'{alarm_time2}.jpg'
    fname = os.path.join(self.alarm_dir, 'crowd', 'alarm_crowd_report.txt')
    # print(f'[INFO] fname: `{fname}`')
    alarm_line = f'{alarm_time1}\t{cam_name}\tCrowd\t{img_name}\n'
    if self.check_file_existence(fname):
      #~ используем 'a' для добавления в конец файла
      with open(fname, 'a', encoding='utf-8') as alarm_file:
        alarm_file.write(alarm_line)
      pass
    else:
      with open(fname, 'w', encoding='utf-8') as alarm_file:
        alarm_file.write('#time\tcamera\talarm\timage\n')
        alarm_file.write(alarm_line)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем видео-кадр как изображение jpg
    crowd_dir = os.path.join(self.alarm_dir, 'crowd', 'frames')
    self.make_directory(crowd_dir)
    fname = os.path.join(crowd_dir, img_name)
    # print(f'[INFO] fname: `{fname}`')
    cv2.imwrite(fname, frame)
    # #~~~~~~~~~~~~~~~~~~~~~~~~
    # #~ отправка в телеграм-бота
    # self.alarm_img_fname = fname
    # teleThread = threading.Thread(target=self.sendTelegram, args=())
    # teleThread.start()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_perimeter(self, cam_inx: int, cam_name: str, alarm_time1: str, alarm_time2: str, frame):
    # crowd_dir = os.path.join(self.alarm_dir, 'crowd')
    img_name = f'{alarm_time2}.jpg'
    fname = os.path.join(self.alarm_dir, 'perimeter', 'alarm_perimeter_report.txt')
    # print(f'[INFO] fname: `{fname}`')
    alarm_line = f'{alarm_time1}\t{cam_name}\tPerimeter\t{img_name}\n'
    if self.check_file_existence(fname):
      #~ используем 'a' для добавления в конец файла
      with open(fname, 'a', encoding='utf-8') as alarm_file:
        alarm_file.write(alarm_line)
      pass
    else:
      with open(fname, 'w', encoding='utf-8') as alarm_file:
        alarm_file.write('#time\tcamera\talarm\timage\n')
        alarm_file.write(alarm_line)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем видео-кадр как изображение jpg
    perimeter_dir = os.path.join(self.alarm_dir, 'perimeter', 'frames')
    self.make_directory(perimeter_dir)
    fname = os.path.join(perimeter_dir, img_name)
    # print(f'[INFO] fname: `{fname}`')
    cv2.imwrite(fname, frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # #~ отправка в телеграм-бота
    # self.alarm_img_fname = fname
    # teleThread = threading.Thread(target=self.sendTelegram, args=())
    # teleThread.start()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_dog(self, cam_inx: int, cam_name: str, alarm_time1: str, alarm_time2: str, frame):
    # crowd_dir = os.path.join(self.alarm_dir, 'crowd')
    img_name = f'{alarm_time2}.jpg'
    fname = os.path.join(self.alarm_dir, 'dog', 'alarm_dog_report.txt')
    # print(f'[INFO] fname: `{fname}`')
    alarm_line = f'{alarm_time1}\t{cam_name}\tdog\t{img_name}\n'
    if self.check_file_existence(fname):
      with open(fname, 'a', encoding='utf-8') as alarm_file:
        alarm_file.write(alarm_line)
      pass
    else:
      with open(fname, 'w', encoding='utf-8') as alarm_file:
        alarm_file.write('#time\tcamera\talarm\timage\n')
        alarm_file.write(alarm_line)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сохраняем видео-кадр как изображение jpg
    perimeter_dir = os.path.join(self.alarm_dir, 'dog', 'frames')
    self.make_directory(perimeter_dir)
    fname = os.path.join(perimeter_dir, img_name)
    # print(f'[INFO] fname: `{fname}`')
    cv2.imwrite(fname, frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # #~ отправка в телеграм-бота
    # self.alarm_img_fname = fname
    # teleThread = threading.Thread(target=self.sendTelegram, args=())
    # teleThread.start()

  # #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # def add_alarm(self, cam_inx: int, cam_name: str, alarm_time1: str, alarm_time2: str, alarm_type: int, frame):
  #   if 0 == alarm_type:
  #     self.add_crowd(cam_inx, cam_name, alarm_time1, alarm_time2, frame)
  #   elif 1 == alarm_type:
  #     self.add_perimeter(cam_inx, cam_name, alarm_time1, alarm_time2, frame)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_alarm(self, cam_inx: int, cam_name: str, alarm_time1: str, alarm_time2: str, alarm_type: int, frame):
    if 0 == alarm_type:
      self.add_crowd(cam_inx, cam_name, alarm_time1, alarm_time2, frame)
    elif 1 == alarm_type:
      self.add_perimeter(cam_inx, cam_name, alarm_time1, alarm_time2, frame)
    elif 2 == alarm_type:
      self.add_dog(cam_inx, cam_name, alarm_time1, alarm_time2, frame)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  # #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # def add_person_detection(self, cam_inx, frame):
  #   if -1 < cam_inx and cam_inx < len(self.cam_names):
  #     #~~~~~~~~~~~~~~~~~~~~~~~~
  #     report_name = self.report_names[cam_inx]
  #     current_time = datetime.now().strftime('%Y.%m.%d %H:%M:%S')
  #     #~ используем 'a' для добавления в конец файла
  #     with open(report_name, 'a', encoding='UTF-8') as file_report:
  #       file_report.write(f'{current_time} - Person detected in {self.cam_names[cam_inx]}\n')
  #     #~~~~~~~~~~~~~~~~~~~~~~~~
  #     #~ создаем current_time2 из current_time
  #     current_time2 = current_time.replace('.', '').replace(':', '').replace(' ', '')
  #     frame_name = os.path.join(self.cam_dirs[cam_inx], f'person_{self.cam_names[cam_inx]}_{current_time2}.jpg')
  #     # print(f'frame_name: `{frame_name}`')
  #     #~ сохраняем текущий видео-кадр как изображение jpg
  #     cv2.imwrite(frame_name, frame)
  #   else:
  #      print(f'->DetectionReporter: Error: Camera index {cam_inx} is out of range')