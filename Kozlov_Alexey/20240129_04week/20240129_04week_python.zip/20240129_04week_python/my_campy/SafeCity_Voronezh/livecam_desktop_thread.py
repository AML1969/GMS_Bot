#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ библиотека для работы с массивами данных
import numpy as np
#~ библиотека для работы с графикой opencv
import cv2
#~~~~~~~~~~~~~~~~~~~~~~~~
from PyQt6 import QtCore
from PyQt6.QtGui import QImage
# from PyQt6.QtGui import QPixmap, QIcon

# #~ tensorflow загрузка, сохраненной модели
# # #import tensorflow as tf
# # from tensorflow.keras.models import load_model

# # from lcaic_ftxt_worker import FTXTWorker
# # from lcaic_model2100 import Model2100Worker
# # from lcaic_model2101 import Model2101Worker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ имя директории с logo
# DIR_LOGO = 'logo'
#~ имя директории с данными для детектирования пользователей по лицу
DIR_FACEID = 'face_id'
#~ имя шаблона притивов Хаара
FXML_HAARCASCADE_FRONT = 'haarcascade_frontalface_default.xml'
#~ имя директории для модели распознавания лиц
DIR_FACEID_TRAIN = 'trainer'
#~ имя файла для модели распознавания лиц
FYML_TRAINER = 'trainer.yml'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ десктопный поток для работы нейронкой
#~~~~~~~~~~~~~~~~~~~~~~~~
class LiveCamDesktopThread(QtCore.QThread):
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~ connect сигнал подключения или не подключения
  #~ str - access|id|FullName|Status
  # conn_signal = QtCore.pyqtSignal(str)
  # #~~~ сигнал отработки предикта по модели 2101
  # pred2101_signal = QtCore.pyqtSignal(str)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~~~ сигналы
  frame_ready = QtCore.pyqtSignal(QImage)


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, data_fpath, parent=None):
    QtCore.QThread.__init__(self, parent)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ Флаг выполнения
    self.running = False
    self.is_watching = False
    self.cam_name = ''
    self.cam_url = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watchVideo(self, cam_name: str, cam_url: str):
    print('[INFO] watchVideo...')
    self.cam_name = cam_name
    self.cam_url = cam_url
    print(f'[INFO] self.cam_name: `{self.cam_name}`, self.cam_url: `{self.cam_url}`')
    if not self.is_watching:
      self.is_watching = True
      self.start()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def stopVideo(self):
    self.is_watching = False
    print('[INFO] stopVideo.')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ 1 - вход по логину-паролю
  def server_connect1(self, user_login, user_password):
    self.doctor_id = '0'
    self.doctor_name = ''
    self.doctor_status = ''
    self.user_login = user_login
    self.user_password = user_password
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.client_mode = 1
    if not self.isRunning():
      self.start()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ 2 - вход по фотографии face-id
  def server_connect2(self):
    self.doctor_id = '0'
    self.doctor_name = ''
    self.doctor_status = ''
    self.user_login = ''
    self.user_password = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.client_mode = 2
    if not self.isRunning():
      self.start()


  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def run(self):
    self.running = True
    print(f'[INFO] init thread run: self.running: {self.running}')
    print(f'[INFO] self.cam_url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сheck if camera opened successfully
    if not vcam.isOpened():
      print(f'[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    frame_width = 1280 #1600,1422,1280
    frame_height = 720 #900,800,720
    gui_frame_zip = True
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    while self.is_watching:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened(): 
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      if gui_frame_zip:
        frame = cv2.resize(frame, (frame_width, frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # image = QImage(frame.data, frame.shape[1], frame.shape[0], QImage.Format_RGB888)
      # image = QImage(frame.data, frame.shape[1], frame.shape[0], QImage.Format.Format_RGB888)

      image = QImage(frame.data, frame_width, frame_height, QImage.Format.Format_BGR888)

      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # img_rows = frame.shape[0]
      # img_cols = frame.shape[1]
      # print(f'[INFO] img_cols: {img_cols}, img_rows: {img_rows}')


    # frame_width = 1280 #1600,1422,1280
    # frame_height = 720 #900,800,720

      
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отправка сигнала с изображением
      self.frame_ready.emit(image)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # cv2.imshow(self.cam_name, frame)
      #~ если нажата клавиша 'q', выходим из цикла
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    vcam.release()
    # cv2.destroyAllWindows()

    # #~~~~~~~~~~~~~~~~~~~~~~~~
    # if (1 == self.client_mode):
    #   #~ 1 - вход по логину-паролю
    #   # print(f'self.user_login: `{self.user_login}`')
    #   # print(f'self.user_password: `{self.user_password}`')
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   doctor_info = self.ftwrk.check_credentials(self.user_login, self.user_password)
    #   if doctor_info:
    #     doctor_info_lst = doctor_info.split('|')
    #     #~ alexey.v.kozlov|pass9|1|9|Козлов Алексей Вадимович|стажёр
    #     #~ data[2]+'|'+data[3]+'|'+data[4]+'|'+data[5]
    #     self.doctor_id = int(doctor_info_lst[0])
    #     self.doctor_name = doctor_info_lst[2]
    #     self.doctor_status = doctor_info_lst[3]
    #     if 1 == self.doctor_id:
    #       doctor_info = '1|'+self.doctor_name
    #     else:
    #       doctor_info = '2|'+self.doctor_name
    #   # print(f'thread> self.doctor_id: `{self.doctor_id}`')
    #   # print(f'thread> self.doctor_name: `{self.doctor_name}`')
    #   # print(f'thread> self.doctor_status: `{self.doctor_status}`')
    #   self.conn_signal.emit(doctor_info)
    # elif (2 == self.client_mode):
    #   #~ 2 - подключение к серверу по фотографии face-id
    #   doctor_info = ''
    #   self.doctor_id = '0'
    #   self.doctor_name = ''
    #   self.doctor_status = ''
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   if not self.is_load_faceid:
    #     self.is_load_faceid = True
    #     #~ создаём новый распознаватель лиц
    #     self.recognizer = cv2.face.LBPHFaceRecognizer_create()
    #     #~ добавляем в него модель, которую мы обучили на прошлых этапах
    #     self.recognizer.read(self.faceid_fname)
    #     #~ указываем, что мы будем искать лица по примитивам Хаара
    #     self.faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + FXML_HAARCASCADE_FRONT)
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   #~ t - total
    #   id_tnum = 0
    #   id8_num = 0
    #   id9_num = 0
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   #~ получаем доступ к камере v-video
    #   #vcam = cv2.VideoCapture(0)
    #   #~~~~~~~
    #   video_fname = os.path.join(self.faceid_path, '2023_1012_115956_009.MOV')
    #   # video_fname = os.path.join(self.faceid_path, 'NataliaTsarikova360.mp4')
    #   # video_fname = os.path.join(self.faceid_path, 'x-person360.mp4')
    #   # print(f'video_fname: `{video_fname}`')
    #   vcam = cv2.VideoCapture(video_fname)
    #   if not vcam.isOpened():
    #     print("can`t open video-camera")
    #     self.conn_signal.emit(doctor_info)
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   #~ путь к папке с логотипами
    #   # logo_fname = os.path.join(self.logo_path, "logot.png")
    #   # print(f'logo_fname: `{logo_fname}`')
    #   #~ устанавливаю иконку у окна с видео-потоком
    #   # cv2.setWindowTitle('faceidwin', 'face-id')
    #   #~ пока не нажата любая клавиша или число кадров менее 100 — выполняем цикл
    #   while cv2.waitKey(1) < 0:
    #     #~ получаем очередной кадр с камеры
    #     hasFrame,frame = vcam.read()
    #     #~ если кадра нет
    #     if not hasFrame:
    #       #~ останавливаемся и выходим из цикла
    #       cv2.waitKey()
    #       break
    #     #~ высота и ширина кадра
    #     frameHeight = frame.shape[0]
    #     frameWidth = frame.shape[1]
    #     #~~~~~~~~~~~~~~~~~~~~~~~~
    #     #~ переводим цветной кадр в ч/б
    #     gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #     #~ улучшение контраста - необязательно делать - ухудшает для детектирования
    #     # gray_frame = cv2.equalizeHist(gray_frame)
    #     #~~~~~~~~~~~~~~~~~~~~~~~~
    #     #~ определяем лица на видео
    #     faces = self.faceCascade.detectMultiScale(gray_frame, scaleFactor=1.2, minNeighbors=5, minSize=(100, 100), flags=cv2.CASCADE_SCALE_IMAGE)
    #     #~ перебираем все найденные лица
    #     for(x,y,w,h) in faces:
    #       #~ получаем id пользователя (predicted id) и минимальное расстояние до лица при детектировании
    #       pred_id, face_mindist = self.recognizer.predict(gray_frame[y:y+h,x:x+w])
    #       #~ рисуем прямоугольник вокруг лица
    #       x1 = x-50
    #       y1 = y-50
    #       x2 = x+w+50
    #       y2 = y+h+50
    #       if 0 < x1 and 0 < y1 and x2 < frameWidth and y2 < frameHeight:
    #         id_tnum = id_tnum + 1
    #         if (8 == pred_id):
    #           id8_num = id8_num + 1
    #         elif (9 == pred_id):
    #           id9_num = id9_num + 1
    #         cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), int(round(frameHeight/150)), 8)
    #     #~ отображаю детектированное лицо    
    #     cv2.imshow('face-id', frame)
    #     # cv2.imshow('face-id', gray_frame)
    #     if id_tnum > 99:
    #       break
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   #~ when everything done, release the capture
    #   vcam.release()
    #   cv2.destroyAllWindows()
    #   #~~~~~~~~~~~~~~~~~~~~~~~~
    #   print(f'id_tnum: `{id_tnum}`')
    #   print(f'id8_num: `{id8_num}`')
    #   print(f'id9_num: `{id9_num}`')
    #   if id8_num > 98:
    #     doctor_info = self.ftwrk.check_id_credentials('8')
    #   elif id9_num > 98:
    #     doctor_info = self.ftwrk.check_id_credentials('9')
    #   if doctor_info:
    #     doctor_info_lst = doctor_info.split('|')
    #     self.doctor_id = int(doctor_info_lst[0])
    #     self.doctor_name = doctor_info_lst[2]
    #     self.doctor_status = doctor_info_lst[3]
    #     if 1 == self.doctor_id:
    #       doctor_info = '1|'+self.doctor_name
    #     else:
    #       doctor_info = '2|'+self.doctor_name
    #   self.conn_signal.emit(doctor_info)
    # elif (4 == self.client_mode):
    #   #~~~ создание объекта для работы с моделью 2100
    #   # print(f'thread> self.client_mode: `{self.client_mode}`')
    #   # print(f'thread> self.data_fpath: `{self.data_fpath}`')
    #   # print(f'thread> self.html_fpath: `{self.html_fpath}`')
    #   if not self.is_load_model2101:
    #     self.is_load_model2101 = True
    #     #~~~ создание объекта для работы с моделью 2101
    #     self.m2101w = Model2101Worker(self.data_fpath, self.html_fpath)
    #     #~~~predict
    #     report_marker = self.m2101w.make_report(self.doctor_id, self.doctor_name, self.doctor_status,
    #       self.patient_name, self.patient_health_cip,
    #       self.inxHumanRace, self.inxGender, self.inxAge,
    #       self.inxSmokingStatus, self.inxECOG, self.inxTumorLoad,
    #       self.inxCo_mutationKRAS, self.inxCo_mutationp53, self.inxCo_mutationSTK11,
    #       self.inxCo_mutationKEAP1, self.inxPeriodFromCLT, self.inxMolecularStatus,
    #       self.inxPD_L1Status, self.inxPatientPreference, 
    #       self.inxMedication, self.inxConfidence, self.inxAlternative, self.inxComment)
    #     # print(f'report_marker: `{report_marker}`')
    #     self.pred2101_signal.emit(report_marker)

    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.running = False
    self.client_mode = 0
    print(f'[INFO] ---> finish thread run: self.running: {self.running}')