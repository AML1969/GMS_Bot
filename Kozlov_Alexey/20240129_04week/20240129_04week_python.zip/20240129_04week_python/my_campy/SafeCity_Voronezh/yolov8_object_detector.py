#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
# --cam_inx -> camera index -> индекс камеры
#    0..7: Заказчик предоставил 8 камер,
#    если параметр не указан, то cam_inx=0
# --siren_interval_sec
#    0....: интервал между повторными сиренами
# --json_name -> json file name
#~~~~~~~~~~~~~~~~~~~~~~~~
# python yolov8_object_detector.py
# python yolov8_object_detector.py --cam_inx 2 --siren_interval_sec 60 --json_name машины_Perimeter1_20240202_144817.json


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ работа со временем
import time
#~ работа с датой
from datetime import datetime
#~ библиотека для работы с массивами данных
import numpy as np
import json
#~ детектирование с помощью YOLO
from ultralytics import YOLO

from utility_modules.settings_reader import SettingsReader
from utility_modules.json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ YOLOv8 Object Detector
class Yolov8ObjDetector:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self):
    print('~'*70)
    print('[INFO] YOLOv8 Object Detector ver.2024.02.02')
    print('~'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    self.res_patch = os.path.join(prog_path, 'data_out')
    if not os.path.exists(self.res_patch):
      os.makedirs(self.res_patch)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ парсер аргументов командной строки
    #~~~~~~~~~~~~~~~~~~~~~~~~
    parser = argparse.ArgumentParser(description='YOLOv8 Object Detector.')
    parser.add_argument('--cam_inx', type=int, default=0, help='Index of the camera to use')
    parser.add_argument('--siren_interval_sec', type=int, default=0, help='Interval between repeat sirens')
    parser.add_argument('--json_name', type=str, default='', help='JSON file name')
    args = parser.parse_args()
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_inx = args.cam_inx
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.siren_interval_sec = args.siren_interval_sec
    if self.siren_interval_sec < 1 or self.siren_interval_sec > 86400:
      self.siren_interval_sec = 1
    print(f'[INFO] interval between repeat sirens, sec: {self.siren_interval_sec}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    cam_count = ini_reader.get_cam_count()
    print('[INFO] camera:')
    print(f'[INFO]  count: {cam_count}')
    print(f'[INFO]  index: {self.cam_inx}')
    cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
    if not cam_inx_isvalid:
      print('[ERROR] the index of camera is incorrect')
      self.cam_inx = 0
      cam_inx_isvalid = ini_reader.check_cam_inx(self.cam_inx)
      if not cam_inx_isvalid:
        self.cam_inx = -1
        exit()
      print(f'[INFO]  patch camera index: {self.cam_inx}')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_name = ini_reader.get_camera_name(self.cam_inx)
    # cam_description = ini_reader.get_camera_description(self.cam_inx)
    # cam_location = ini_reader.get_camera_location(self.cam_inx)
    self.cam_url = ini_reader.get_camera_url(self.cam_inx)
    print(f'[INFO]  name: `{self.cam_name}`')
    # print(f'[INFO]  description: `{cam_description}`')
    # print(f'[INFO]  location: `{cam_location}`')
    print(f'[INFO]  url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]  original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь, по которому находятся сохраненные зоны
    #~~~~~~~~~~~~~~~~~~~~~~~
    self.zone_nodes = []
    if args.json_name:
      zones_path = ini_reader.get_zones_directory()
      json_obj = JSONWworker(zones_path, self.cam_name)
      self.zone_nodes = json_obj.read_json_polygon(args.json_name, self.frame_width, self.frame_height)
      # if len(self.zone_nodes) > 0:
      #   self.zone_nodes.append(self.zone_nodes[0])
      print(f'[INFO] zone_nodes: len: {len(self.zone_nodes)}, {self.zone_nodes}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # def is_centroid_in_polygon(x1, y1, x2, y2, polygon_coordinates):
  def is_centroid_in_polygon(self, x1, y1, x2, y2, polygon_coordinates):
    x_cen = (x1+x2)/2
    y_cen = (y1+y2)/2
    # print(f'[INFO] x1: {x1}, x2: {x2}, x_cen: {x_cen}, y1: {y1}, y2: {y2}, y_cen: {y_cen}')
    #~ координаты центроида объекта
    centroid_coordinates = [x_cen, y_cen]
    point = np.array(centroid_coordinates)
    polygon = np.array(polygon_coordinates)
    #~ используем функцию pointPolygonTest из OpenCV
    is_inside = cv2.pointPolygonTest(polygon, point, False)
    return is_inside > 0

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ yolov8
    #~ load a model
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    model_path = 'yolov8m.pt'
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # model_path = os.path.join('.', 'runs', 'detect', 'train', 'weights', 'last.pt')
    # model_path = 'c:/my_campy/yolov8-utils/runs/detect/train5/weights/best.pt'
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 2024.01.30 fire, garbage
    #~ Optimizer stripped from runs\detect\train3\weights\last.pt, 52.1MB
    #~ Optimizer stripped from runs\detect\train3\weights\best.pt, 52.1MB
    # model_path = 'c:/my_campy/SafeCity_Voronezh/dataset_utilities/runs/detect/train3/weights/best.pt'
    # model_path = 'c:/my_campy/SafeCity_Voronezh/dataset_utilities/runs/detect/train3/weights/last.pt'
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print(f'[INFO] model path: `{model_path}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    model = YOLO(model_path)
    threshold = 0.5
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ perimeter8_class_names.txt
    #~ 0|person|человек|0: person
    #~ 1|bicycle|велосипед|1: bicycle
    #~ 2|car|машина|2: car
    #~ 3|motorcycle|мотоцикл|3: motorcycle
    #~ 4|bus|автобус|5: bus
    #~ 5|truck|грузовик|7: truck
    #~ 6|dog|собака|16: dog
    #~ 7|bottle|бутылка|39: bottle
    #~ #
    #~ 8|fire|огонь|
    #~ 9|garbage|мусор|
    #~
    special_class_id = 2
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ время последнего события тревоги
    alarm_time = 0.0 # time.time()
    print(f'[INFO] alarm_time: {alarm_time}')
    #~ max разница во времени между двумя алармами, для того чтобы считать,
    #~ что события происходят `непрерывно` -> alarm max delta time
    alarm_delta_time = 1.0
    #~ cчетчик сигналов тревоги -> alarm counter 
    alarm_counter = 0
    #~ порог сигналов тревоги, после превышения которого считаем,
    #~ что событие тревоги однозначно произошло
    alarm_counter_threshold = 30 #30, 1
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ время последнего события сирены
    siren_time = 0.0 # time.time()
    siren_counter = 0
    siren_counter_threshold = 100
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ рисование полигона на кадре
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if len(self.zone_nodes) > 2:
        cv2.polylines(frame, [np.array(self.zone_nodes)], isClosed=True, color=(255, 0, 0), thickness=2)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ детектирование объектов в кадре
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ предсказание модели
      results = model(frame)[0]
      for result in results.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id = result
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ проверка по id-класса
        class_id_int = int(class_id)
        # print(f'[INFO] special_class_id: {special_class_id}, class_id: {class_id}, class_id_int: {class_id_int}, score: {score}')
        if not special_class_id == class_id_int:
          continue
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ проверка по порогу
        if score < threshold:
          continue
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # #~ patch by person foot
        # person_h = int((y2 - y1)/4)
        # y1 = y2 - person_h 
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # print(f'[INFO] zone_nodes: len: {len(self.zone_nodes)}, {self.zone_nodes}')
        # print(f'[INFO] x1: {x1}, y1: {y1}, x2: {x2}, y2: {y2}')
        if len(self.zone_nodes) > 2:
          is_zone = self.is_centroid_in_polygon(x1, y1, x2, y2, self.zone_nodes)
          if not is_zone:
            continue
        #~ рамка вокруг детектированного объекта
        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
        cv2.putText(frame, results.names[int(class_id)].upper(), (int(x1), int(y1 - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ детектирования одного объекта достаточно, считаем что это один и тот же объект
        #~ delta_time -> доли секунды
        delta_time = time.time() - alarm_time
        # print(f'[INFO] delta_time: {delta_time}, alarm delta time: {alarm_delta_time}')
        if delta_time < alarm_delta_time:
          alarm_counter += 1
        else:
          alarm_counter = 0
        alarm_time = time.time()
        break
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if alarm_counter > alarm_counter_threshold:
        delta_time = int(time.time() - siren_time)
        # print(f'[INFO] delta_time: {delta_time}, siren delta time: {self.siren_interval_sec}')
        if delta_time > self.siren_interval_sec:
          alarm_time = time.time()
          alarm_counter = 0
          siren_time = time.time()
          siren_counter = 1
          #~ формируем сигнал тревоги
          # print('[INFO] --- SIREN ---')
          siren_time_str = datetime.now().strftime('%Y%m%d_%H%M%S')+'.jpg'
          #~ cохраняем текущий видео-кадр как изображение jpg
          siren_fname = os.path.join(self.res_patch, siren_time_str)
          # print(f'[INFO] siren_fname: `{siren_fname}`')
          cv2.imwrite(siren_fname, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if siren_counter > 0:
        siren_counter += 1
        if siren_counter > siren_counter_threshold:
          siren_counter = 0
        else:
          cv2.rectangle(frame, (20, 20), (370, 80), (0, 0, 255), cv2.FILLED)
          cv2.putText(frame, "--- SIREN ---", (60, 60),
                      cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)


      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      cv2.imshow(self.cam_name, frame)
      #~ если нажата клавиша 'q', выходим из цикла
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  vcam_obj = Yolov8ObjDetector()
  vcam_obj.watch_video()
  print('='*70)
  print('[INFO] -> program completed!')




# #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~
#   #~
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   # #~ результирующий видео-файл
#   # current_time = datetime.datetime.now()
#   # video_file_name = current_time.strftime("%Y%m%d_%H%M%S") + ".mp4"
#   # video_file_name2 = os.path.join(prog_path, video_file_name)
#   # #~ определяем кодек и FPS для сохранения видео
#   # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#   # vout = cv2.VideoWriter(video_file_name2, fourcc, out_fps, (frame_width, frame_height))
#   # print(f'[INFO] result video-file: `{video_file_name2}`')
#   # print(f'[INFO] result frame size: width: {frame_width}, height: {frame_height}')
#   # print(f'[INFO] result frame per second: {round(out_fps,1)}')
  
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   # # #~ pixels
#   # # MARGIN = 10
#   # #~ pixels
#   # ROW_SIZE = 10
#   # FONT_SIZE = 1
#   # FONT_THICKNESS = 1
#   # #~ red
#   # # TEXT_COLOR = (255, 0, 0)
#   # TEXT_COLOR = (0, 0, 255)

#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ чтение видео-кадров камеры в цикле
#   # while (vcam.isOpened()):
#   while True:
#     ret, frame = vcam.read()    
#     #~~~~~~~~~~~~~~~~~~~~~~~~
#     # if not ret:
#     #   vcam.release()
#     #   vcam = cv2.VideoCapture(cam_url)
#     #   if not vcam.isOpened(): 
#     #     break
#     #   continue
#     #~~~~~~~~~~~~~~~~~~~~~~~~
#     #~ break the loop
#     #~ если просматриваем записанный видещ-файл
#     if not ret:
#       break
#     #~~~~~~~~~~~~~~~~~~~~~~~~
#     if use_compression:
#       frame = cv2.resize(frame, (compressed_width, compressed_height))
#     #~~~~~~~~~~~~~~~~~~~~~~~~

#     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     #~ проверяем детектирование на устойчивость
#     print(f'[INFO] flag1: {flag1}')
#     if flag1:
#       #~ увеличение счетчика стабильного детектирования
#       counter1 += 1
#       print(f'[INFO] counter1: {counter1}, threshold1: {threshold1}')
#       if counter1 >= threshold1:
#         # print(f'[INFO] Stable detection: Person detected in the danger zone!')
#         #~ здесь можно добавить код для сигнализации о стабильном нахождении человека в опасной зоне
#         # print(f'[INFO] Stable detection: FIRE!')
#         # print(f'[INFO] Stable detection: GARBAGE!')
#         alarm_flag = True
#         # counter1 = 0
#         # counter0 = 0
#     else:
#       #~ сброс счетчика, если нет события alarm
#       if alarm_flag:
#         counter0 += 1
#         if counter0 >= threshold0:
#           alarm_flag = False
#           counter1 = 0
#           counter0 = 0
#     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     #~ рисование полигона на кадре
#     #~~~~~~~~~~~~~~~~~~~~~~~~
#     cv2.polylines(frame, [np.array(roi_zone)], isClosed=True, color=(255, 0, 0), thickness=2)
#     #~~~~~~~~~~~~~~~~~~~~~~~~
#     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     # print(f'[INFO] alarm_flag: `{alarm_flag}`')
#     if alarm_flag:
#       # text_location = (100, 100)
#       # cv2.putText(frame, '--- FIRE ---', text_location, cv2.FONT_HERSHEY_PLAIN,
#       #             FONT_SIZE, TEXT_COLOR, FONT_THICKNESS)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(img, (120, 20), (470, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(img, "PEOPLE DETECTED!!!", (130, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(frame, (120, 20), (470, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(frame, "PEOPLE DETECTED!!!", (130, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(frame, (120, 20), (580, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(frame, "--- FIRE DETECTED!!!---", (130, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(frame, (720, 20), (1260, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(frame, "--- GARBAGE DETECTED!!!---", (730, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(frame, (720, 20), (1305, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(frame, "--- PERSON UNDER ICICLES!!!---", (730, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       # cv2.rectangle(frame, (720, 20), (1305, 80), (0, 0, 255), cv2.FILLED)
#       # cv2.putText(frame, "--- PERSON UNDER ICICLES!!!---", (730, 60),
#       #             cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)
#       #~~~~~~~~~~~~~~~~~~~~~~~~
#       cv2.rectangle(frame, (720, 20), (1370, 80), (0, 0, 255), cv2.FILLED)
#       cv2.putText(frame, "--- NOT PEDESTRIAN CROSSING!!!---", (730, 60),
#                   cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255), 2)

#     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     # #~ сохраняем кадр в видеофайл
#     # vout.write(frame)
#     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     #~ отображаем кадр
#     cv2.imshow('yolov8-detector', frame)
#     #~ если нажата клавиша 'q', выходим из цикла
#     # if cv2.waitKey(25) & 0xFF == ord('q'):
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ освобождаем ресурсы
#   vcam.release()
#   # vout.release()
#   cv2.destroyAllWindows()

# #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# if __name__ == "__main__":
#   print('~'*70)
#   print('[INFO]  Video Checker ver.2024.01.30')
#   print('~'*70)
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ Воронеж  
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   out_fps = 25.0
#   use_compression = True #~ True False
#   compressed_width = 1804 #~ 1804, 1280
#   compressed_height = 1014 #~ 1014, 720
#   #~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ Perimeter17
#   #~ Нейросеть_68/1 к 2_ периметр 17
#   # cam_url = 'rtsp://w3.tv.kvant-telecom.ru/pyaterochka.test-132ba24f9a?dvr=true&token=2.9omxv2sXAx0ABfmU4bRWyoZBRA9FP2-s8JiufI9e3WRjgWAQ'
#   #~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ Perimeter7
#   #~ Нейросеть_МКД Спортивная 26/3 кам.7
#   # cam_url = 'rtsp://w2.tv.kvant-telecom.ru/nejroset_mkd.sportivnaya.263.kam.7-0117f59297?dvr=true&token=2.hblfS1SFAx0ABgZT5ieesstBFAIyIIVX2QvV57kZUuXMt8Oe'
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   #~ загружаю видео-файлы
#   #~~~~~~~~~~~~~~~~~~~~~~~~
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter7_20240130_103955_dog.mp4'
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111114_falling_icicles.mp4'
#   #~
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_youtube/fire1.mp4'
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_youtube/fire2.mp4'
#   #~
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter7_20240126_123003_garbage.mp4'
#   #~
#   # cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111114_falling_icicles.mp4'
#   #~
#   cam_url = 'c:/my_campy/SafeCity_Voronezh/data/video_archive/Perimeter17_20240126_111245_not_pedestrian_crossing.mp4'

#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   main(cam_url, use_compression, compressed_width, compressed_height, out_fps)
#   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   print('='*70)
#   print('[INFO] -> program completed!')
  