#~ USAGE
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
# cd d:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~   --cam_id -> id -> уникальный номер камеры
#~     0,  1,2,4,7,9,12,14,17: Заказчик предоставил 8 камер,
#~     если параметр не указан, то cam_id=1,
#~     0 индекс зарезервирован для камеры VideoPlayer -> отработка событий, типа 'пожар' и т.д.
#~   --zone_fname -> файл с зонами для указанной камеры в cam_id
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ клавиша 'q' - выход из режима просмотра видео и зон
#~~~~~~~~~~~~~~~~~~~~~~~~
# python zone_viewer.py --cam_id 4 --zone_fname crowd_Perimeter4_20240306_094112.json


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string
import time

from settings_reader import SettingsReader
from json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Zone Viewer
class ZoneViewer:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_id: int, zone_fname: str):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив зон
    self.zone_lst = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_id = args.cam_id
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    id_lst = ini_reader.get_cam_lst()
    print(f'[INFO] camera id list: len: {len(id_lst)}: {id_lst}')
    self.cam_inx = ini_reader.get_cam_inx(self.cam_id, id_lst)
    print(f'[INFO] camera index: {self.cam_inx}')
    if -1 == self.cam_inx:
      print(f'[ERROR] camera id is incorrect: {self.cam_id}')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] Camera:')
    self.cam_name = ini_reader.get_camera_name(self.cam_id)
    self.cam_description = ini_reader.get_camera_description(self.cam_id)
    self.cam_location = ini_reader.get_camera_location(self.cam_id)
    self.cam_url = ini_reader.get_camera_url(self.cam_id)
    print(f'[INFO]   id: {self.cam_id}')
    print(f'[INFO]   name: `{self.cam_name}`')
    print(f'[INFO]   description: `{self.cam_description}`')
    print(f'[INFO]   location: `{self.cam_location}`')
    print(f'[INFO]   url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    vcam = cv2.VideoCapture(self.cam_url)
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]   original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь для сохранения зон
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.zone_dir = ini_reader.get_zones_directory()
    json_obj = JSONWworker(self.zone_dir, self.cam_name)
    self.zone_lst = json_obj.read_json_absolute_polygon(zone_fname, self.frame_width, self.frame_height)
    # print(f'[INFO] zone list: len: {len(self.zone_lst)}: `{self.zone_lst}`')
    print(f'[INFO] zone list: len: {len(self.zone_lst)}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ окно для отображения кадров 
    cv2.namedWindow(self.cam_name)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем зоны-полигоны
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if len(self.zone_lst) > 0:
        for j in range(len(self.zone_lst)):
          if len(self.zone_lst[j]) > 1:
            for i in range(len(self.zone_lst[j])):
              cv2.circle(frame, self.zone_lst[j][i], 5, (0, 0, 255), -1)
              cv2.line(frame, self.zone_lst[j][i-1], self.zone_lst[j][i], (0, 0, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      cv2.imshow(self.cam_name, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем события нажатия на клавиши
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ Конструкция 0xFF используется для создания маски (маскирования) и преобразования значения в 8-битное число.
      #~ В данном случае, она используется для того, чтобы убедиться, что мы оставляем только младший байт (8 бит)
      #~ значения, полученного от cv2.waitKey(1).
      #~ Функция cv2.waitKey(1) возвращает код клавиши, которая была нажата пользователем.
      #~ Однако этот код может быть представлен как 32-битное число. Чтобы извлечь только младший байт (8 бит),
      #~ мы применяем маску 0xFF, которая обнуляет все биты, кроме младших 8.
      #~ Таким образом, выражение cv2.waitKey(1) & 0xFF позволяет нам получить только младший байт значения,
      #~  что удобно для сравнения с кодами клавиш, представленными в ASCII или других кодировках.
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      press_key_value = cv2.waitKey(1) & 0xFF
      if ord('q') == press_key_value:
        #~ если нажата клавиша 'q', выходим из цикла
        print('[INFO] press key `q` -> exit')
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_execution_time(execution_time):
  if execution_time < 1:
    return f"{execution_time:.3f} sec"
  
  hours = int(execution_time // 3600)
  minutes = int((execution_time % 3600) // 60)
  seconds = int(execution_time % 60)

  if execution_time < 60:
    return f"{seconds}.{int((execution_time % 1) * 1000):03d} sec"
  elif execution_time < 3600:
    return f"{minutes} min {seconds:02d} sec"
  else:
    return f"{hours} h {minutes:02d} min {seconds:02d} sec"

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  start_time = time.time()
  print('~'*70)
  print('[INFO] Zone Viewer ver.2024.03.03')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ определяем параметры вызова камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  parser = argparse.ArgumentParser(description='Zone Viewer.')
  parser.add_argument('--cam_id', type=int, default=1, help='ID -> unique camera number')
  parser.add_argument('--zone_fname', type=str, default='', help='Path to the zone json file')
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj = ZoneViewer(args.cam_id, args.zone_fname)
  #~ клавиша 'q' - выход из режима просмотра видео и зон
  vcam_obj.watch_video()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ вычисляем время работы программы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  execution_time = time.time() - start_time
  execution_time_str = format_execution_time(execution_time)
  print('='*70)
  print(f'[INFO] program execution time: {execution_time_str}')
  print('='*70)