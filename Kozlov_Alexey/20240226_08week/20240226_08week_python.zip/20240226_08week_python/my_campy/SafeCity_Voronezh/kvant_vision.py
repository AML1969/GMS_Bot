#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ pip install flet
#~ https://flet.dev/docs/
#~ https://flet.dev/docs/tutorials/python-todo/
#~ https://flet.dev/docs/tutorials/trello-clone
#~ https://flet.dev/docs/guides/python/user-controls
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ USAGE
# cd c:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
# python kvant_vision.py

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ https://kvant-telecom.ru
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
import flet as ft
import sqlite3
import os
# import flet as ft
import time, threading
import cv2


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Countdown(ft.UserControl):
  def __init__(self, seconds):
    super().__init__()
    self.seconds = seconds

  def did_mount(self):
    self.running = True
    self.th = threading.Thread(target=self.update_timer, args=(), daemon=True)
    self.th.start()

  def will_unmount(self):
    self.running = False

  def update_timer(self):
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_url = "rtsp://w3.tv.kvant-telecom.ru/chursina.6.lovim.vora-a41ab39a2a?dvr=true&token=2.9omxv2sXAx0ABfmU4bRWyqbRoCvKJ50hlMIAlSbQjP-EIid9"
    vcam = cv2.VideoCapture(self.cam_url)
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ret, frame = vcam.read()    
    self.frame_width = frame.shape[1]
    self.frame_height = frame.shape[0]
    print(f'[INFO]  original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    self.frame_width2 = int(self.frame_width/2)
    self.frame_height2 = int(self.frame_height/2)
    print(f'[INFO] frame2 size: width: {self.frame_width2}, height: {self.frame_height2}, ratio: {round(self.frame_width2/self.frame_height2,5)}')


    #~~~~~~~~~~~~~~~~~~~~~~~~
    while self.seconds and self.running:
      mins, secs = divmod(self.seconds, 60)
      # self.countdown.value = "{:02d}:{:02d}".format(mins, secs)
      self.update()
      time.sleep(1)
      self.seconds -= 1
      #~~~~~~~~~~~~~~~~~~~~~~~~
      ret, frame = vcam.read()    
      if not ret:
        vcam.release()
        vcam = cv2.VideoCapture(self.cam_url)
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      frame = cv2.resize(frame, (self.frame_width2, self.frame_height2))
      print(f'[INFO] frame2 size: width: {frame.shape[1]}, height: {frame.shape[0]}')
      res_img_write = cv2.imwrite('test.jpg', frame)
      self.countdown.src = 'test.jpg'


    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def build(self):
    # self.countdown = ft.Text()
    self.countdown = ft.Image(src='test.jpg')
    # self.countdown = ft.Image()
    return self.countdown

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main(page: ft.Page):
  page.title = 'KVANT vision ver.2024.02.28'
  # page.add(Countdown(120), Countdown(60))
  page.add(Countdown(120))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ft.app(target=main)