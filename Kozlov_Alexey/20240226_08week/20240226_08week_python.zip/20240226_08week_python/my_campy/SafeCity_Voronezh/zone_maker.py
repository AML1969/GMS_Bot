#~ USAGE
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
# cd d:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~   --cam_id -> id -> уникальный номер камеры
#~     0,  1,2,4,7,9,12,14,17: Заказчик предоставил 8 камер,
#~     если параметр не указан, то cam_id=1,
#~     0 индекс зарезервирован для камеры VideoPlayer -> отработка событий, типа 'пожар' и т.д.
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ клавиша 'q' - выход из режима просмотра видео и добавления зон
#~               сохранение полигонов в файл json
#~ клавиша 'a' - добавление текущего полигона
#~ клавиша 'd' - удаление текущего полигона
#~~~~~~~~~~~~~~~~~~~~~~~~
# python zone_maker.py --cam_id 4

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string
import time

from settings_reader import SettingsReader
from json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Zone Maker
class ZoneMaker:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_id: int):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    self.zones_path = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ узлы полигона
    self.point_lst = []
    self.dragging = False
    self.selected_point_index = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив зон
    self.zone_lst = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_id = args.cam_id
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    id_lst = ini_reader.get_cam_lst()
    print(f'[INFO] camera id list: len: {len(id_lst)}: {id_lst}')
    self.cam_inx = ini_reader.get_cam_inx(self.cam_id, id_lst)
    print(f'[INFO] camera index: {self.cam_inx}')
    if -1 == self.cam_inx:
      print(f'[ERROR] camera id is incorrect: {self.cam_id}')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] Camera:')
    self.cam_name = ini_reader.get_camera_name(self.cam_id)
    self.cam_description = ini_reader.get_camera_description(self.cam_id)
    self.cam_location = ini_reader.get_camera_location(self.cam_id)
    self.cam_url = ini_reader.get_camera_url(self.cam_id)
    print(f'[INFO]   id: {self.cam_id}')
    print(f'[INFO]   name: `{self.cam_name}`')
    print(f'[INFO]   description: `{self.cam_description}`')
    print(f'[INFO]   location: `{self.cam_location}`')
    print(f'[INFO]   url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 2024.03.06 todo hard-code
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]   original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь для сохранения зон
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.zones_path = ini_reader.get_zones_directory()
    print(f'[INFO] zones path: `{self.zones_path}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def mouse_callback(self, event, x, y, flags, param):
    # print('[INFO] mouse_callback...')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ дистанция-радиус в пикселях - реакция на нажатие мышью рядом с узлом 
    dist_pix = 15
    #~~~~~~~~~~~~~~~~~~~~~~~~
    if event == cv2.EVENT_LBUTTONDOWN:
      #~ добавление узла или инициализация режима перемещения узла
      for i, point in enumerate(self.point_lst):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          self.dragging = True
          self.selected_point_index = i
          break
      if not self.dragging:
        self.point_lst.append((x, y))
    elif event == cv2.EVENT_LBUTTONUP:
      #~ завершение режима перемещения узла
      self.dragging = False
      self.selected_point_index = -1
    elif event == cv2.EVENT_MOUSEMOVE:
      #~ перемещения узла
      if self.dragging and 0 <= self.selected_point_index < len(self.point_lst):
        self.point_lst[self.selected_point_index] = (x, y)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
      #~ удаление узла двойным кликом
      for i, point in enumerate(self.point_lst):
        distance = np.sqrt((point[0] - x)**2 + (point[1] - y)**2)
        if distance < dist_pix:
          del self.point_lst[i]
          break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'[INFO] self.point_lst: len: {len(self.point_lst)}')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 2024.03.06 todo hard-code
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ инициализация Callback по кликам мыши 
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print('[INFO] mouse callback is init ---1')
    cv2.namedWindow(self.cam_name)
    cv2.setMouseCallback(self.cam_name, self.mouse_callback)
    # print('[INFO] mouse callback is init ---2')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #~ 2024.03.06 todo hard-code
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # vcam = cv2.VideoCapture(self.cam_url)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем завершенные зоны-полигоны
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if len(self.zone_lst) > 0:
        for j in range(len(self.zone_lst)):
          if len(self.zone_lst[j]) > 1:
            for i in range(len(self.zone_lst[j])):
              cv2.circle(frame, self.zone_lst[j][i], 5, (0, 0, 255), -1)
              cv2.line(frame, self.zone_lst[j][i-1], self.zone_lst[j][i], (0, 0, 255), 2)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем текущую зону-полигон: ребра и узлы
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if 1 == len(self.point_lst):
        cv2.circle(frame, self.point_lst[0], 5, (0, 0, 255), -1)
      elif len(self.point_lst) > 1:
        for i in range(len(self.point_lst)):
          cv2.line(frame, self.point_lst[i-1], self.point_lst[i], (255, 0, 0), 2)
        for i in range(len(self.point_lst)):
          cv2.circle(frame, self.point_lst[i], 5, (0, 0, 255), -1)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      cv2.imshow(self.cam_name, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем события нажатия на клавиши
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ Конструкция 0xFF используется для создания маски (маскирования) и преобразования значения в 8-битное число.
      #~ В данном случае, она используется для того, чтобы убедиться, что мы оставляем только младший байт (8 бит)
      #~ значения, полученного от cv2.waitKey(1).
      #~ Функция cv2.waitKey(1) возвращает код клавиши, которая была нажата пользователем.
      #~ Однако этот код может быть представлен как 32-битное число. Чтобы извлечь только младший байт (8 бит),
      #~ мы применяем маску 0xFF, которая обнуляет все биты, кроме младших 8.
      #~ Таким образом, выражение cv2.waitKey(1) & 0xFF позволяет нам получить только младший байт значения,
      #~  что удобно для сравнения с кодами клавиш, представленными в ASCII или других кодировках.
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # press_key_value = cv2.waitKey(1) & 0xFF
      press_key_value = cv2.waitKey(25) & 0xFF
      if ord('q') == press_key_value:
        #~ если нажата клавиша 'q', выходим из цикла
        print('[INFO] press key `q` -> exit')
        break
      elif ord('d') == press_key_value:
        #~ если нажата клавиша 'd', то удаляем текущий полигон
        print('[INFO] press key `d` -> delete points-zone')
        self.point_lst = []
        self.dragging = False
        self.selected_point_index = -1
      elif ord('a') == press_key_value:
        #~ если нажата клавиша 'a', то добавляем текущий полигон
        print('[INFO] press key `a` -> add points-zone')
        # print(f'[INFO] 1>len(self.zone_lst): {len(self.zone_lst)}')
        if len(self.point_lst) > 2:
          self.zone_lst.append(self.point_lst)
        # print(f'[INFO] 2>len(self.zone_lst): {len(self.zone_lst)}')
        self.point_lst = []
        self.dragging = False
        self.selected_point_index = -1
        # print(f'[INFO] 3>len(self.zone_lst): {len(self.zone_lst)}')
 
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def save_zone(self):
    if -1 == self.cam_inx:
      print('[WARNING] camera is not define')
      return
    if len(self.point_lst) > 2:
      self.zone_lst.append(self.point_lst)
    if len(self.zone_lst) < 1:
      print('[WARNING] empty zone-points list')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    fname1 = input("Введите название зоны (пустое значение - не сохранять): ")
    if not fname1:
      print('[WARNING] saving the zone has been canceled')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ разрешенные символы для имени файла
    valid_chars = string.ascii_letters + string.digits + "._-" + "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    #~ приводим все буквы к нижнему регистру
    fname1 = fname1.lower()
    fname2 = ''.join(c if c in valid_chars else '' for c in fname1)
    #~ проверка на наличие недопустимых символов
    if os.path.sep in fname2:
      #~ удаляем слэши
      fname2 = fname2.replace(os.path.sep, '')
    # print(f'[INFO] fname2: `{fname2}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    json_obj = JSONWworker(self.zones_path, self.cam_name)
    json_obj.save_json_polygon(fname2, self.frame_width, self.frame_height, self.zone_lst)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_execution_time(execution_time):
  if execution_time < 1:
    return f"{execution_time:.3f} sec"
  
  hours = int(execution_time // 3600)
  minutes = int((execution_time % 3600) // 60)
  seconds = int(execution_time % 60)

  if execution_time < 60:
    return f"{seconds}.{int((execution_time % 1) * 1000):03d} sec"
  elif execution_time < 3600:
    return f"{minutes} min {seconds:02d} sec"
  else:
    return f"{hours} h {minutes:02d} min {seconds:02d} sec"

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  start_time = time.time()
  print('~'*70)
  print('[INFO] Zone Maker ver.2024.03.03')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ определяем параметры вызова камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  parser = argparse.ArgumentParser(description='Zone Maker.')
  parser.add_argument('--cam_id', type=int, default=1, help='ID -> unique camera number')
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj = ZoneMaker(args.cam_id)
  #~ клавиша 'q' - выход из режима просмотра видео и добавления зон
  #~               сохранение полигонов в файл json
  #~ клавиша 'a' - добавление текущего полигона
  #~ клавиша 'd' - удаление текущего полигона
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj.watch_video()
  vcam_obj.save_zone()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ вычисляем время работы программы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  execution_time = time.time() - start_time
  execution_time_str = format_execution_time(execution_time)
  print('='*70)
  print(f'[INFO] program execution time: {execution_time_str}')
  print('='*70) 