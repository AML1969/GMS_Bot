#~~~~~~~~~~~~~~~~~~~~~~~~
#~ c:/
#~ d:/
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import configparser
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class SettingsReader:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, data_path: str):
    config_filename = os.path.join(data_path, 'settings.ini')
    self.config = configparser.ConfigParser()
    self.config.read(config_filename)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_lst(self):
    id_lst_str = self.config.get('CAMERAS', 'id_list')
    # print(f'[INFO] >id_lst_str: `{id_lst_str}`')
    id_lst = id_lst_str.split(",")
    id_int_lst = [int(x) for x in id_lst]
    return id_int_lst

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_inx(self, cam_id: int, id_lst):
    if cam_id in id_lst:
      return id_lst.index(cam_id)
    else:
      return -1

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_name(self, cam_id: int) -> str:
    retVal = 'none'
    id_lst = self.get_cam_lst()
    cam_inx = self.get_cam_inx(cam_id, id_lst)
    if not -1 == cam_inx:
      retVal = self.config.get(f'CAMERA{cam_inx}', 'name')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_description(self, cam_id: int) -> str:
    retVal = 'none'
    id_lst = self.get_cam_lst()
    cam_inx = self.get_cam_inx(cam_id, id_lst)
    if not -1 == cam_inx:
      retVal = self.config.get(f'CAMERA{cam_inx}', 'description')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_location(self, cam_id: int) -> str:
    retVal = 'none'
    id_lst = self.get_cam_lst()
    cam_inx = self.get_cam_inx(cam_id, id_lst)
    if not -1 == cam_inx:
      retVal = self.config.get(f'CAMERA{cam_inx}', 'location')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_camera_url(self, cam_id: int) -> str:
    retVal = 'none'
    id_lst = self.get_cam_lst()
    cam_inx = self.get_cam_inx(cam_id, id_lst)
    if not -1 == cam_inx:
      retVal = self.config.get(f'CAMERA{cam_inx}', 'url')
    return retVal

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_database_directory(self) -> str:
    return self.config.get('DATA_BASE', 'directory')

  def get_database_registration(self) -> str:
    return self.config.get('DATA_BASE', 'registration')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ Zones (ROI - Region Of Interest)
  def get_zones_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'zones')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_alarm_directory(self) -> str:
    return self.config.get('DATA_DIRECTORIES', 'alarm')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_detection_threshold(self) -> float:
    retVal = self.config.getfloat('YOLODetector', 'detection_threshold')
    return retVal