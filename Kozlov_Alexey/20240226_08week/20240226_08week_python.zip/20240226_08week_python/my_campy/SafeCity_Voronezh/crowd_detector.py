#~ USAGE
# cd c:\my_campy
# cd d:\my_campy
# .\camenv8\Scripts\activate
# cd c:\my_campy\SafeCity_Voronezh
# cd d:\my_campy\SafeCity_Voronezh
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ параметры запуска программы
#~   --cam_id -> id -> уникальный номер камеры
#~     0,  1,2,4,7,9,12,14,17: Заказчик предоставил 8 камер,
#~     если параметр не указан, то cam_id=1,
#~     0 индекс зарезервирован для камеры VideoPlayer -> отработка событий, типа 'пожар' и т.д.
#~   --zone_fname -> файл с зонами для указанной камеры в cam_id
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ клавиша 'q' - выход из режима просмотра видео и зон
#~~~~~~~~~~~~~~~~~~~~~~~~
# python crowd_detector.py --cam_id 4 --zone_fname dog_corner_Perimeter4_20240302_181818.json
# python crowd_detector.py --cam_id 4 --zone_fname crowd_Perimeter4_20240306_094112.json
# python crowd_detector.py --cam_id 4 --zone_fname crossroad_Perimeter4_20240306_144228.json

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ import the necessary packages
#~ библиотека для вызова системных функций
import os
#~ передача аргументов через командную строку
import argparse
#~ библиотека для работы с графикой opencv
import cv2
#~ определение размеров экрана, для корректного отображения
import pyautogui
#~ библиотека для работы с массивами данных
import numpy as np
import string
import time

from ultralytics import YOLO
from ultralytics.solutions import object_counter
import cv2

from settings_reader import SettingsReader
from json_worker import JSONWworker

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ Crowd Detector - детектор толпы
class CrowdDetector:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, cam_id: int, zone_fname: str):
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь к папке из которой запустили программу
    #~~~~~~~~~~~~~~~~~~~~~~~~
    prog_path = os.getcwd()
    print(f'[INFO] program path: `{prog_path}`')
    self.cam_inx = -1
    self.cam_name = ''
    self.cam_url = ''
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ массив зон
    self.zone_lst = []
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.cam_id = args.cam_id
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ настройки из файла settings.ini
    #~~~~~~~~~~~~~~~~~~~~~~~~
    ini_reader = SettingsReader(prog_path)
    id_lst = ini_reader.get_cam_lst()
    print(f'[INFO] camera id list: len: {len(id_lst)}: {id_lst}')
    self.cam_inx = ini_reader.get_cam_inx(self.cam_id, id_lst)
    print(f'[INFO] camera index: {self.cam_inx}')
    if -1 == self.cam_inx:
      print(f'[ERROR] camera id is incorrect: {self.cam_id}')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    print('[INFO] Camera:')
    self.cam_name = ini_reader.get_camera_name(self.cam_id)
    self.cam_description = ini_reader.get_camera_description(self.cam_id)
    self.cam_location = ini_reader.get_camera_location(self.cam_id)
    self.cam_url = ini_reader.get_camera_url(self.cam_id)
    print(f'[INFO]   id: {self.cam_id}')
    print(f'[INFO]   name: `{self.cam_name}`')
    print(f'[INFO]   description: `{self.cam_description}`')
    print(f'[INFO]   location: `{self.cam_location}`')
    print(f'[INFO]   url: `{self.cam_url}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры кадра
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.frame_width = -1
    self.frame_height = -1
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 2024.03.06 todo hard-code
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_perimeter/Perimeter4_20240305_1000_crowd.mp4')
    vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if vcam.isOpened():
      #~ читаю первые 30 кадров (обычно это 1сек, чтобы получить размеры кадра с большей вероятностью)
      for i in range(30):
        ret, frame = vcam.read()
        if ret:
          self.frame_width = frame.shape[1]
          self.frame_height = frame.shape[0]
          print(f'[INFO]   original frame size: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
          break
    vcam.release()
    if -1 == self.frame_width:
      self.cam_inx = -1
      print(f'[ERROR] can`t read video-frame')
      exit()
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ определяем размеры экрана
    #~~~~~~~~~~~~~~~~~~~~~~~~
    screen_width, screen_height = pyautogui.size()
    print(f'[INFO] screen: width: {screen_width}, height: {screen_height}, ratio: {round(screen_width/screen_height,5)}')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ изменяем размер окна для отображения видео, если это необходимо, чтобы полказать полностью кадр
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 1080-65=1015 (patch by taskbar in windows) => 1015/1080=0.93981
    width_zip = screen_width*0.93981
    height_zip = screen_height*0.93981
    print(f'[INFO] screen without taskbar: width: {round(width_zip,5)}, height: {round(height_zip,5)}, ratio: {round(width_zip/height_zip,5)}')
    if self.frame_width > int(width_zip) or self.frame_height > int(height_zip):
      frame_zip = self.frame_width/width_zip
      hframe_zip = self.frame_height/height_zip
      if hframe_zip > frame_zip:
        frame_zip = hframe_zip
      width_zip = self.frame_width/frame_zip
      height_zip = self.frame_height/frame_zip
      self.frame_width = int(round(width_zip))
      self.frame_height = int(round(height_zip))
      print(f'[INFO] frame resize: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    else:
      self.frame_width = -1
      print('[INFO] frame is not resize')
    print('-'*70)
    print(f'[INFO] final frame working sizes: width: {self.frame_width}, height: {self.frame_height}, ratio: {round(self.frame_width/self.frame_height,5)}')
    print('-'*70)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ путь для сохранения зон
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.zone_dir = ini_reader.get_zones_directory()
    json_obj = JSONWworker(self.zone_dir, self.cam_name)
    self.zone_lst = json_obj.read_json_absolute_polygon(zone_fname, self.frame_width, self.frame_height)
    print(f'[INFO] zone list: len: {len(self.zone_lst)}')
    print(f'[INFO] zone list: len: {len(self.zone_lst)}: `{self.zone_lst}`')
    #~ преобразование координат
    # self.zone_lst0 = [(point[0],point[1]) for point in self.zone_lst[0]]
    # self.zone_lst1 = [(point[0],point[1]) for point in self.zone_lst[1]]
    # print(f'[INFO] zone list: len: {len(self.zone_lst0)}: `{self.zone_lst0}`')
    # print(f'[INFO] zone list: len: {len(self.zone_lst1)}: `{self.zone_lst1}`')

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ трансформируем зоны для работы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # #~ cоздаем изображение с белым фоном
    # image = np.zeros((1015, 1804, 3), dtype=np.uint8)
    # image.fill(255)
    # #~ массив полигонов из файла json
    # polygons = [[[902, 156], [1157, 485], [1660, 427], [1689, 447], [1757, 257], [1590, 189]],
    #             [[688, 174], [977, 1004], [251, 1002], [281, 225]]]
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ преобразуем массив полигонов к np.array
    zone_lst = json_obj.read_json_absolute_polygon(zone_fname, self.frame_width, self.frame_height)
    self.npzone_lst = [np.array(polygon, np.int32) for polygon in zone_lst]
    print(f'[INFO] zone list: len: {len(zone_lst)}: `{zone_lst}`')
    # print(f'[INFO] np zone list: len: {len(self.npzone_lst)}: `{self.npzone_lst}`')
    self.person_lst = []
    if len(self.npzone_lst) > 0:
      for i in range(len(self.npzone_lst)):
        self.person_lst.append(0)
    # print(f'[INFO] self.person_lst: len: {len(self.person_lst)}: `{self.person_lst}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def watch_video(self):
    if -1 == self.cam_inx:
      print('[ERROR] camera is not define')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ открываем видео-камеру
    #~ сheck if camera opened successfully
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ 2024.03.06 todo hard-code
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture(self.cam_url)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_perimeter/Perimeter4_20240305_1000_crowd.mp4')
    vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if not vcam.isOpened():
      print('[ERROR] can`t open video-camera')
      return
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ окно для отображения кадров 
    cv2.namedWindow(self.cam_name)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ модель YOLO для детектирования людей, то есть толпы
    model = YOLO("yolov8m.pt")
    # yolo_threshold = 0.5
    yolo_threshold = 0.2
    #~ 0 - person
    yolo_class_id = 0
    #~ координаты центроида объекта
    centroid_coord = [0.0, 0.0]
    #~ person threshold
    person_threshold = 3
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ cчетчик сигналов тревоги -> alarm count
    alarm_count1 = 0
    frame_count1 = 0
    # alarm_count2 = 0
    # frame_count2 = 0
    mega_alarm = False
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # results = model.track
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # # model = YOLO("yolov8n.pt")
    # zone_lst0 = [(point[0],point[1]) for point in self.zone_lst[0]]
    # zone_lst1 = [(point[0],point[1]) for point in self.zone_lst[1]]
    # #~ Init Object Counter
    # counter0 = object_counter.ObjectCounter()
    # counter0.set_args(view_img=True,
    #                  reg_pts=zone_lst0,
    #                  classes_names=model.names,
    #                  draw_tracks=True)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ чтение видео-кадров камеры в бесконечном цикле,
    #~ до тех пор пока пользователь не нажмет на клавиатуре клавишу `q`
    #~~~~~~~~~~~~~~~~~~~~~~~~
    while True:
      ret, frame = vcam.read()    
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not ret:
        vcam.release()
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #~ 2024.03.06 todo hard-code
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # vcam = cv2.VideoCapture(self.cam_url)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_perimeter/Perimeter4_20240305_1000_crowd.mp4')
        vcam = cv2.VideoCapture('c:/my_campy/SafeCity_Voronezh/data_in/video_youtube/crossroad_1280_720.mp4')
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if not vcam.isOpened():
          print('[ERROR] can`t open video-camera')
          break
        continue
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ изменяем размеры кадра для отображения на экране монитора
      if not -1 == self.frame_width:
        frame = cv2.resize(frame, (self.frame_width, self.frame_height))


      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # tracks0 = model.track(frame, persist=True, show=False)
      # frame = counter0.start_counting(frame, tracks0)
      # # video_writer.write(frame)
      # cv2.imshow(self.cam_name, frame)
      # press_key_value = cv2.waitKey(1) & 0xFF
      # if ord('q') == press_key_value:
      #   #~ если нажата клавиша 'q', выходим из цикла
      #   print('[INFO] press key `q` -> exit')
      #   break
      # continue
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ подсчитываем количество людей в каждой зоне
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ обнуляем списки
      self.person_lst = [0 for _ in range(len(self.person_lst))]
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ предсказание yolo модели
      #~~~~~~~~~~~~~~~~~~~~~~~~
      yolo_res = model(frame, verbose=False)[0]
      for res1 in yolo_res.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id_f = res1
        class_id = int(class_id_f)
        if not yolo_class_id == class_id:
          continue
        if score < yolo_threshold:
          continue
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # score_str = str(round(score, 2))
        # obj_label = f'{class_id}: person: {score_str}'
        obj_label = f'{round(score, 1)}'
        x_min = int(x1)
        y_min = int(y1)
        x_max = int(x2)
        y_max = int(y2)
        x_cen = (x_min + x_max) // 2
        y_cen = (y_min + y_max) // 2
        cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 0, 0), 2)
        cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (255, 255, 255), 1)
        cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (0, 0, 0), 2)
        cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (255, 255, 255), 1)
        cv2.circle(frame, (x_cen, y_cen), 15, (0, 0, 255), -1)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        # if len(self.npzone_lst) > 0:
        #~ пробегаемся по полигонам
        for i in range(len(self.npzone_lst)):
          # x_cen = (x1+x2)/2
          # y_cen = (y1+y2)/2
          #~ x_cen
          centroid_coord[0] = (x1+x2)/2
          #~ y_cen
          centroid_coord[1] = (y1+y2)/2
          #~ используем функцию pointPolygonTest из OpenCV
          is_inside = cv2.pointPolygonTest(self.npzone_lst[i], centroid_coord, False)
          if is_inside > 0:
            self.person_lst[i] += 1
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ анализируем события alarm есть или нет
      #~~~~~~~~~~~~~~~~~~~~~~~~
      for i in range(len(self.npzone_lst)):
        if 0 == i:
          if self.person_lst[i] > 10:
            alarm_count1 += 1
        # elif 1 == i:
        #   if self.person_lst[i] > 2:
        #     alarm_count2 += 1
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ подсчитываем число кадров после первого аларма
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if alarm_count1 > 0:
        frame_count1 += 1
      # if alarm_count2 > 0:
      #   frame_count2 += 1
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрисовываем зоны-полигоны
      #~ и отображаем количество людей в каждой зоне
      #~~~~~~~~~~~~~~~~~~~~~~~~
      for i in range(len(self.npzone_lst)):
        # event_color = (0, 100, 0)
        # event_color = (255, 255, 255)
        event_color = (0, 0, 0)
        if self.person_lst[i] >= person_threshold:
          event_color = (0, 0, 255)
        elif self.person_lst[i] > 0:
          # event_color = (0, 255, 255)
          event_color = (255, 0, 0)
        #~~~~~~~~~~~~~~~~~~~~~~~~
        #~ отрисовываем зоны-полигоны
        cv2.polylines(frame, [self.npzone_lst[i]], isClosed=True, color=event_color, thickness=5)
        cv2.polylines(frame, [self.npzone_lst[i]], isClosed=True, color=(255, 255, 255), thickness=2)
        # zone_str = f'zone{i+1}:  person: {self.person_lst[i]}'
        zone_str = f'person: {self.person_lst[i]}'
        #~ определяем центр полигона
        zone_cen = np.mean(self.npzone_lst[i], axis=0).astype(int)
        # zone_cen2 = (zone_cen[0] - 100, zone_cen[1] - 100)
        zone_cen2 = (zone_cen[0]-100, zone_cen[1]-50)
        #~ подписываем центр полигона
        # cv2.putText(frame, zone_str, (zone_cen[0] - 50, zone_cen[1] - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, event_color, 2)
        cv2.putText(frame, zone_str, zone_cen2, cv2.FONT_HERSHEY_TRIPLEX, 1, event_color, 2)
        cv2.putText(frame, zone_str, zone_cen2, cv2.FONT_HERSHEY_TRIPLEX, 1, (255, 255, 255), 1)

        # cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (0, 0, 0), 2)
        # cv2.putText(frame, obj_label, (x_min+3, y_min+20), cv2.FONT_HERSHEY_TRIPLEX, 0.7, (255, 255, 255), 1)

      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем отображаем счетчик тревог
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if not mega_alarm:
        # cv2.rectangle(frame, (2, 1), (235, 160), (255, 255, 255), -1)
        cv2.rectangle(frame, (2, 1), (235, 80), (255, 255, 255), -1)
        x_offset = 10
        y_offset = 32
        #~ alarm1  
        message_str = f'alarm1: {alarm_count1}'
        cv2.putText(frame, message_str, (x_offset, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        message_str = f'frame1: {frame_count1}'
        cv2.putText(frame, message_str, (x_offset, y_offset+35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        # #~ alarm2  
        # message_str = f'alarm2: {alarm_count2}'
        # cv2.putText(frame, message_str, (x_offset, y_offset+80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        # message_str = f'frame2: {frame_count2}'
        # cv2.putText(frame, message_str, (x_offset, y_offset+115), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
      else:
        #~ формируем главное событие аларма
        # x_offset = 2
        # y_offset = 1
        x_offset = 2 + self.frame_width // 2 +450
        y_offset = 1 + self.frame_height //2 
        cv2.rectangle(frame, (x_offset, y_offset), (x_offset+505, y_offset+60), (255, 255, 255), -1)
        message_str = ' --- CROWD DETECT !!! ---'
        cv2.putText(frame, message_str, (x_offset, y_offset+40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ анализируем главный аларм
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if frame_count1 > 40:
        if alarm_count1 > 30:
          mega_alarm = True
      # if frame_count2 > 40:
      #   if alarm_count2 > 30:
      #     mega_alarm = True
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отображаем кадр
      #~~~~~~~~~~~~~~~~~~~~~~~~
      cv2.imshow(self.cam_name, frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ отрабатываем события нажатия на клавиши
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      #~ Конструкция 0xFF используется для создания маски (маскирования) и преобразования значения в 8-битное число.
      #~ В данном случае, она используется для того, чтобы убедиться, что мы оставляем только младший байт (8 бит)
      #~ значения, полученного от cv2.waitKey(1).
      #~ Функция cv2.waitKey(1) возвращает код клавиши, которая была нажата пользователем.
      #~ Однако этот код может быть представлен как 32-битное число. Чтобы извлечь только младший байт (8 бит),
      #~ мы применяем маску 0xFF, которая обнуляет все биты, кроме младших 8.
      #~ Таким образом, выражение cv2.waitKey(1) & 0xFF позволяет нам получить только младший байт значения,
      #~  что удобно для сравнения с кодами клавиш, представленными в ASCII или других кодировках.
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # press_key_value = cv2.waitKey(1) & 0xFF
      # press_key_value = cv2.waitKey(25) & 0xFF
      press_key_value = cv2.waitKey(1) & 0xFF
      if ord('q') == press_key_value:
        #~ если нажата клавиша 'q', выходим из цикла
        print('[INFO] press key `q` -> exit')
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~ освобождаем ресурсы
    #~~~~~~~~~~~~~~~~~~~~~~~~
    vcam.release()
    cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_execution_time(execution_time):
  if execution_time < 1:
    return f"{execution_time:.3f} sec"
  
  hours = int(execution_time // 3600)
  minutes = int((execution_time % 3600) // 60)
  seconds = int(execution_time % 60)

  if execution_time < 60:
    return f"{seconds}.{int((execution_time % 1) * 1000):03d} sec"
  elif execution_time < 3600:
    return f"{minutes} min {seconds:02d} sec"
  else:
    return f"{hours} h {minutes:02d} min {seconds:02d} sec"

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  start_time = time.time()
  print('~'*70)
  print('[INFO] Crowd Detector ver.2024.03.05')
  print('~'*70)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ определяем параметры вызова камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  parser = argparse.ArgumentParser(description='Crowd Detector.')
  parser.add_argument('--cam_id', type=int, default=1, help='ID -> unique camera number')
  parser.add_argument('--zone_fname', type=str, default='', help='Path to the zone json file')
  args = parser.parse_args()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  vcam_obj = CrowdDetector(args.cam_id, args.zone_fname)
  #~ клавиша 'q' - выход из режима просмотра видео и зон
  vcam_obj.watch_video()
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ вычисляем время работы программы
  #~~~~~~~~~~~~~~~~~~~~~~~~
  execution_time = time.time() - start_time
  execution_time_str = format_execution_time(execution_time)
  print('='*70)
  print(f'[INFO] program execution time: {execution_time_str}')
  print('='*70)