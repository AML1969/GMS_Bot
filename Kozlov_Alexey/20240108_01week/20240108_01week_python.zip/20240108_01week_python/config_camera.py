import configparser
import os

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class ConfigCamera:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, prog_path):
    # print(f' >ConfigCamera: prog_path: `{prog_path}`')
    config_filename = os.path.join(prog_path, 'settings.ini')
    # print(f' >ConfigCamera: config_filename: `{config_filename}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    self.config = configparser.ConfigParser()
    self.config.read(config_filename)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ кортеж названий камер
    self.cam_names = ('Perimeter 1', 'Perimeter 4', 'Perimeter 14', 'Perimeter 17')
    self.cam_code_names = ('camera1', 'camera4', 'camera14', 'camera17')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_names(self):
    return self.cam_names

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_frame_compression(self):
    #~ оригинальные размеры кадра: frame4 shape: (1296, 2304, 3)
    #~ уменьшаем в два раза: width=2304/2=1152, height=1296/2=648
    #~ уменьшаем в три раза: width=2304/3=768, height=1296/3=432
    #~ уменьшаем в четыре раза: width=2304/4=576, height=1296/4=324
    use_compression = self.config.getboolean('FrameSettings', 'use_compression')
    compressed_width = self.config.getint('FrameSettings', 'compressed_width')
    compressed_height = self.config.getint('FrameSettings', 'compressed_height')
    return use_compression,compressed_width,compressed_height

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_cam_url(self, cam_inx: int) -> str:
    # cam_names = ('Perimeter 1', 'Perimeter 4', 'Perimeter 14', 'Perimeter 17')
    retVal = ''
    # print(f' >ConfigCamera: self.cam_code_names: len: {len(self.cam_code_names)}, {self.cam_code_names}')
    # print(f' >ConfigCamera: self.cam_code_names[0]: {self.cam_code_names[0]}')
    if -1 < cam_inx and cam_inx < len(self.cam_code_names):
      retVal = self.config['CAMERAS'][self.cam_code_names[cam_inx]]
      # print(f' >ConfigCamera: cam_inx: `{cam_inx}`')
      # print(f' >ConfigCamera: retVal: `{retVal}`')
    #~~~~~~~~~~~~~~~~~~~~~~~~
    return retVal
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def get_detection_threshold(self) -> float:
    retVal = self.config.getfloat('YOLOv5Detector', 'detection_threshold')
    return retVal
