#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_dcampy
# .\dcenv\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_dcampy\SafeCity-Voronezh-3
# python live_stop_frame.py
# python live_stop_frame.py --cam_index 1
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ сигнализация звуком добавлена в программу, если происходит съемка самого себя,
#~ и для для повышения однозначности
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ подключаемые библиотеки
#~~~~~~~~~~~~~~~~~~~~~~~~
import cv2
#~ unique identifier
import uuid
import os
import shutil
import time
#~ передача аргументов через командную строку
import argparse

#~ импорт библиотеки google-cloud-texttospeech
import gtts 
#~ основной интерфейс для перевода текста в аудио
from gtts import gTTS 
#~ для проигрывания звукового файла в Python можно использовать библиотеку pygame
import pygame

from config_camera import ConfigCamera

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ настройки
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ имя директории с сохраненными стоп-кадрами
DIR_IMG = 'stop_frame_images'
#~ массив названий объектов, которые в видим в кадре
# labels = ['awake', 'drowsy']
labels = ['snowbank']
#~ число стоп-кадров для каждого объекта из списка labels
number_imgs = 25

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ выполнение программы по сохранению стоп-кадров с объектами из списка labels
#~~~~~~~~~~~~~~~~~~~~~~~~
print('~'*50)
print('Live Stop Frame ver.2024.01.08')
#~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ создаем папку для стоп-кадров
#~ путь к папке из которой запустили программу
prog_path = os.getcwd()
#~ путь к папке с сохраняемыми изображениями (стоп-кадрами)
stop_frame_path = os.path.join(prog_path, DIR_IMG)
#~ удаляем директорию для стоп-кадров со всем содержимым, еcли она есть
if os.path.exists(stop_frame_path):
  shutil.rmtree(stop_frame_path)
#~ создаем директорию для стоп-кадров еcли ее нет
if not os.path.exists(stop_frame_path):
  os.makedirs(stop_frame_path)
print('~'*50)
print(f'prog_path: `{prog_path}`')
print(f'stop_frame_path: `{stop_frame_path}`')
#~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ добавляем парсер аргументов
parser = argparse.ArgumentParser(description='Video camera settings.')
parser.add_argument('--cam_index', type=int, default=0,
                    help='Index of the camera to use')
args = parser.parse_args()
print(f'camera index: `{args.cam_index}`')
#~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ настройки камеры: пути, сжатие и т.д.
cam_conf = ConfigCamera(prog_path)
cam_names = cam_conf.get_cam_names()
use_compression,compressed_width,compressed_height = cam_conf.get_frame_compression()
print(f'cam_names: len: {len(cam_names)}, {cam_names}')
print(f'use_compression: `{use_compression}`')
print(f'compressed_width: `{compressed_width}`')
print(f'compressed_height: `{compressed_height}`')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ словари для озвучки текста
#~ Словарь со всеми доступными языками.
#~ К сожалению, для русского языка доступен только один голос:
#~~~~~~~~~~~~~~~~~~~~~~~~
#print('~'*50)
#print(f'gtts.lang.tts_langs(): `{gtts.lang.tts_langs()}`')
#'en': 'English',
#'ru': 'Russian',

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ открываем видео-камеру
#~ cap - capture (захватывать)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_url = cam_conf.get_cam_url(args.cam_index)
if not cam_url:
  print(f'error: camera-url path to the camera is not defined or the index is incorrect')
  exit(0)
#~
cap = cv2.VideoCapture(cam_url)
#~ сheck if camera opened successfully
print('~'*50)
if cap.isOpened() == True: 
  print(f'success: camera-{args.cam_index} is open')
else:
  print(f'error: camera-{args.cam_index} is not open')
  exit(0)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ иниализация объекта Pygame для воспроизведения mp3
#~~~~~~~~~~~~~~~~~~~~~~~~
pygame.init()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ цикл по labels - формируем стоп-кадры
#~~~~~~~~~~~~~~~~~~~~~~~~
len_labels = len(labels)
# print(f'len_labels: `{len_labels}`')
for i in range(len_labels):
  label = labels[i]
  nlabel_path = os.path.join(stop_frame_path, label)
  print(f'  {i} -> {len_labels}: `{label}` -> `{nlabel_path}`')
  image_path = os.path.join(nlabel_path, 'images')
  #~ директория для работы в программе labelimg
  image_label_path = os.path.join(nlabel_path, 'labels')
  if not os.path.exists(image_path):
    os.makedirs(image_path)
  if not os.path.exists(image_label_path):
    os.makedirs(image_label_path)
  # print(f'  image_path: `{image_path}`')
  # print(f'  image_label_path: `{image_label_path}`')
  text_str = 'Collecting images for {}'.format(label)
  print('  '+text_str)
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ озвучиваем TextToSpeech -> преобразовываем текст в аудио
  #tts = gTTS(text_str, lang='ru') 
  tts = gTTS(text_str, lang='en') 
  #~ cохраняем в формате мр3
  speech_file = 'audio'+str(i)+'.mp3'
  speech_path = os.path.join(nlabel_path, speech_file)
  # print(f'speech_file: `{speech_file}`')
  # print(f'speech_path: `{speech_path}`')
  tts.save(speech_path)   
  #~~~
  #~ создание объекта звукового файла
  sound = pygame.mixer.Sound(speech_path)
  #~ воспроизведение звукового файла
  sound.play()
  #~ ждем, пока звуковой файл не закончит воспроизведение
  while pygame.mixer.get_busy():
    pygame.time.wait(100)
  #~~~~~~~~~~~~~~~~~~~~~~~~  
  time.sleep(5)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ сохраняем заданное количество кадров по текущему объекту
  #~~~~~~~~~~~~~~~~~~~~~~~~  
  #~ loop through image range
  for img_num in range(number_imgs):
    print('    Collecting images for {}, image number {}'.format(label, img_num))
    #~ webcam feed (трансляция с веб-камеры)
    ret, frame = cap.read()
    if ret:
      #~ в зависимости от значения use_compression изменяем размер кадра
      #~ или оставляем его без изменений
      if use_compression:
        frame = cv2.resize(frame, (compressed_width, compressed_height))
      #~ naming out image path
      imgname = os.path.join(image_path, label+'.'+str(uuid.uuid1())+'.jpg')
      print(f'      imgname: `{imgname}`')
      #~ writes out image to file 
      cv2.imwrite(imgname, frame)
      #~ render to the screen
      cv2.imshow('Image Collection', frame)
    #~ 2 second delay between captures
    time.sleep(2)
    #~
    if cv2.waitKey(10) & 0xFF == ord('q'):
      break

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ закрываем видео-камеру и освобождаем ресурсы с ней связанные
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ when everything done, release the video capture object
cap.release()
#~ closes all the frames
cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ цикл по labels - формируем стоп-кадры
#~~~~~~~~~~~~~~~~~~~~~~~~
print('='*50)
#Программа успешно завершена
text_str = 'The program has been successfully completed'
tts = gTTS(text_str, lang='en')
#~ f - finish 
speech_file = 'audio-f.mp3'
speech_path = os.path.join(stop_frame_path, speech_file)
tts.save(speech_path)
sound = pygame.mixer.Sound(speech_path)
sound.play()
while pygame.mixer.get_busy():
  pygame.time.wait(100)
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ освобождение ресурсов воспроизведения звукового файла
pygame.mixer.quit()
#~~~~~~~~~~~~~~~~~~~~~~~~
print('-> '+text_str+'!')