import os
import shutil
import cv2
from datetime import datetime

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ имя директории с результами работы - детектирование объектов
DIR_DET_REPORT = 'detect_reports'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class DetectionReporter:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, prog_path, cam_names):
    #~ путь к папке с отчетами
    self.detreport_path = os.path.join(prog_path, DIR_DET_REPORT)
    self.cam_names = cam_names
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f'->DetectionReporter: detreport_path `{self.detreport_path}`')
    # print(f'->DetectionReporter: cam_names: len: `{len(cam_names)}`, `{self.cam_names}`')
    self.cam_dirs = []
    self.report_names = []
    for i in range(len(self.cam_names)):
      # print(f'{i}->{len(self.cam_names)}')
      idir_path = os.path.join(self.detreport_path, self.cam_names[i])
      self.cam_dirs.append(idir_path)
      # print(f'  cam_dirs: len: `{len(self.cam_dirs)}`, `{self.cam_dirs}`')
      str_line = f'person_{self.cam_names[i]}.txt'
      report_name = os.path.join(idir_path, str_line)
      # print(f'  str_line: `{str_line}`')
      # print(f'  report_name: `{report_name}`')
      self.report_names.append(report_name)
      if not os.path.exists(idir_path):
        os.makedirs(idir_path)
        with open(report_name, 'w', encoding='UTF-8') as file_report:
          file_report.write(f'Person: {self.cam_names[i]}\n')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_person_detection(self, cam_inx, frame):
    if -1 < cam_inx and cam_inx < len(self.cam_names):
      #~~~~~~~~~~~~~~~~~~~~~~~~
      report_name = self.report_names[cam_inx]
      current_time = datetime.now().strftime('%Y.%m.%d %H:%M:%S')
      #~ используем 'a' для добавления в конец файла
      with open(report_name, 'a', encoding='UTF-8') as file_report:
        file_report.write(f'{current_time} - Person detected in {self.cam_names[cam_inx]}\n')
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ создаем current_time2 из current_time
      current_time2 = current_time.replace('.', '').replace(':', '').replace(' ', '')
      frame_name = os.path.join(self.cam_dirs[cam_inx], f'person_{self.cam_names[cam_inx]}_{current_time2}.jpg')
      # print(f'frame_name: `{frame_name}`')
      #~ сохраняем текущий видео-кадр как изображение jpg
      cv2.imwrite(frame_name, frame)
    else:
       print(f'->DetectionReporter: Error: Camera index {cam_inx} is out of range')