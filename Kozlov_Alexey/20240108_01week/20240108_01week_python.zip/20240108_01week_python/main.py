#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_dcampy
# .\dcenv\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_dcampy\SafeCity-Voronezh-3
# python main.py
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ библиотека для вызова системных функций
import os
#~ библиотека для работы с массивами данных
import numpy as np
#~ библиотека для работы с графикой opencv
import cv2

from config_camera import ConfigCamera
from live_camera import LiveCamera
from yolov5_detect import YOLOv5Detector

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
  print('SafeCity-Voronezh-3  ver.2024.01.08')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ путь к папке из которой запустили программу
  #~~~~~~~~~~~~~~~~~~~~~~~~
  prog_path = os.getcwd()
  # print(f'  prog_path: `{prog_path}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ настройки из config файла
  #~~~~~~~~~~~~~~~~~~~~~~~~
  cam_conf = ConfigCamera(prog_path)
  cam_names = cam_conf.get_cam_names()
  use_compression,compressed_width,compressed_height = cam_conf.get_frame_compression()
  det_threshold = cam_conf.get_detection_threshold()
  print(f' =>cam_names: len: {len(cam_names)}, {cam_names}')
  print(f' =>use_compression: `{use_compression}`')
  print(f' =>compressed_width: `{compressed_width}`')
  print(f' =>compressed_height: `{compressed_height}`')
  print(f' =>detection_threshold: `{det_threshold}`')
  #~ проверяем, что пути ко всем четырем камерам указаны
  for i in range(len(cam_names)):
    cam_url = cam_conf.get_cam_url(i)  
    if not cam_url:
      print(f'=>error: camera-url path to the camera-{i} is not defined or the index is incorrect')
      exit(0)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ создание объекта детектора YOLOv5
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ использование стандартной модели
  # yv5_det = YOLOv5Detector()
  yv5_det = YOLOv5Detector(prog_path, cam_names, detection_threshold = det_threshold, model_type='yolov5s')
  #~ использование пользовательской модели
  # yv5_det = YOLOv5Detector(custom_model=True, custom_model_path='d:/my_dcampy/yolov5/runs/train/snowbank-results3/weights/best.pt')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ cоздание черного изображения заданных размеров,
  #~ для отображения на экране, когда кадр потерян
  #~~~~~~~~~~~~~~~~~~~~~~~~
  blank_image = np.zeros((432, 768, 3), np.uint8)
  #~ заливка черным цветом
  blank_image[:] = (0, 0, 0)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ открываем все четыре камеры
  #~~~~~~~~~~~~~~~~~~~~~~~~
  # cam0 = LiveCamera(cam_inx, cam_conf.get_cam_url(cam_inx), cam_names[cam_inx], use_compression, compressed_width, compressed_height)
  # cam0.start()
  cap0 = cv2.VideoCapture(cam_conf.get_cam_url(0))
  if cap0.isOpened(): 
    print(f'=>success: camera-0 is open')
  else:
    print(f'=>error: camera-0 is not open')
    exit(0)


  if not cap0.isOpened():
    print('error: camera-0 is not open')
    exit(0)
  cap1 = cv2.VideoCapture(cam_conf.get_cam_url(1))
  if not cap1.isOpened(): 
    print('error: camera-1 is not open')
    exit(0)
  cap2 = cv2.VideoCapture(cam_conf.get_cam_url(2))
  if not cap2.isOpened(): 
    print('error: camera-2 is not open')
    exit(0)
  cap3 = cv2.VideoCapture(cam_conf.get_cam_url(3))
  if not cap3.isOpened(): 
    print('error: camera-3 is not open')
    exit(0)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  while True:
    #~ считывание кадров с камер
    ret0, frame0 = cap0.read()
    ret1, frame1 = cap1.read()
    ret2, frame2 = cap2.read()
    ret3, frame3 = cap3.read()

    #~~~~~~~~~~~~~~~~~~~~~~
    #~ Perimeter 1
    if ret0:
      yv5_det.detect_objects(frame0, 0)
    else:
      print(' -> reopen cap0')
      frame0 = blank_image.copy()
      cap0.release()
      cap0 = cv2.VideoCapture(cam_conf.get_cam_url(0))

    #~~~~~~~~~~~~~~~~~~~~~~
    #~ Perimeter 4
    if ret1:
      yv5_det.detect_objects(frame1, 1)
    else:
      print(' -> reopen cap1')
      frame1 = blank_image.copy()
      cap1.release()
      cap1 = cv2.VideoCapture(cam_conf.get_cam_url(1))

    #~~~~~~~~~~~~~~~~~~~~~~
    #~ Perimeter 14
    if ret2:
      yv5_det.detect_objects(frame2, 2)
    else:
      print(' -> reopen cap2')
      frame2 = blank_image.copy()
      cap2.release()
      cap2 = cv2.VideoCapture(cam_conf.get_cam_url(2))

    #~~~~~~~~~~~~~~~~~~~~~~
    #~ Perimeter 17
    if ret3:
      yv5_det.detect_objects(frame3, 3)
    else:
      print(' -> reopen cap3')
      frame3 = blank_image.copy()
      cap3.release()
      cap3 = cv2.VideoCapture(cam_conf.get_cam_url(3))

    #~~~~~~~~~~~~~~~~~~~~~~
    #~ сжатие кадров
    if use_compression:
      frame0 = cv2.resize(frame0, (compressed_width, compressed_height))
      frame1 = cv2.resize(frame1, (compressed_width, compressed_height))
      frame2 = cv2.resize(frame2, (compressed_width, compressed_height))
      frame3 = cv2.resize(frame3, (compressed_width, compressed_height))

      #~ детектирование объектов на каждом кадре
      # detected_frame1 = detector.detect(frame1)
      # detected_frame2 = detector.detect(frame2)
      # detected_frame3 = detector.detect(frame3)
      # detected_frame4 = detector.detect(frame4)

    #~ объединение изображений по вертикали
    top_combined = cv2.hconcat([frame0, frame1])
    bottom_combined = cv2.hconcat([frame2, frame3])
    combined_frames = cv2.vconcat([top_combined, bottom_combined])

    #~ отображение объединенного изображения
    cv2.imshow('Combined Cameras', combined_frames)
    #~~~~~~~~~~~~~~~~~~~~~~
    if cv2.waitKey(30) & 0xFF == ord('q'):
      break

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #~ закрываем видео-камеры и освобождаем все ресурсы с ними связанные
  #~~~~~~~~~~~~~~~~~~~~~~~~
  #~ when everything done, release the video capture object
  cap0.release()
  cap1.release()
  cap2.release()
  cap3.release()
  #~ closes all the frames
  cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  main()
  #~~~~~~~~~~~~~~~~~~~~~~~~
  print('='*50)
  print('-> program completed!')