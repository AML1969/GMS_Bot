import cv2
import threading

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class LiveCamera:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def __init__(self, camera_index, camera_path, camera_name, use_compression=False, compressed_width=None, compressed_height=None):
    self.cam_inx = camera_index
    self.camera_path = camera_path
    self.camera_name = camera_name
    self.use_compression = use_compression
    self.compressed_width = compressed_width
    self.compressed_height = compressed_height
    self.capture = None
    self.stopped = False
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # print(f' >LiveCamera: self.cam_inx: `{self.cam_inx}`')
    # print(f' >LiveCamera: self.camera_path: `{self.camera_path}`')
    # print(f' >LiveCamera: self.camera_name: `{self.camera_name}`')
    # print(f' >LiveCamera: self.use_compression: `{self.use_compression}`')
    # print(f' >LiveCamera: self.compressed_width: `{self.compressed_width}`')
    # print(f' >LiveCamera: self.compressed_height: `{self.compressed_height}`')
    # print(f' >LiveCamera: self.stopped: `{self.stopped}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def start(self):
    #~ cap - capture (захватывать)
    self.cap = cv2.VideoCapture(self.camera_path)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ сheck if camera opened successfully
    if self.cap.isOpened() == True: 
      print(f' >LiveCamera: success: camera-{self.cam_inx} is open')
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ 2023.01.13 это не работате
      # if self.use_compression:
      #   self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.compressed_width)
      #   self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.compressed_height)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      threading.Thread(target=self.live_video, args=()).start()
      # return self
      print(f' >LiveCamera: start...`')
    else:
      print(f' >LiveCamera: error: camera-{self.cam_inx} is not open')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def stop(self):
    self.stopped = True
    # if self.cap is not None:
    #   self.cap.release()
    print(f' >LiveCamera: self.stopped: `{self.stopped}`')

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def live_video(self):
    #~ read until video is completed
    while self.cap.isOpened():
      #~ capture frame-by-frame
      #~ cap.read() returns a bool (True/False), if the frame is read correctly, it will be True
      ret, frame = self.cap.read()
      #~~~~~~~~~~~~~~~~~~~~~~~~
      if ret:
        #~ в зависимости от значения use_compression изменяем размер кадра
        #~ или оставляем его без изменений
        if self.use_compression:
          frame = cv2.resize(frame, (self.compressed_width, self.compressed_height))
        #~~~~~~~~~~~~~~~~~~~~~~
        #~ display the resulting frame
        cv2.imshow(self.camera_name,frame)
      #~~~~~~~~~~~~~~~~~~~~~~~~
      #~ press Q on keyboard to  exit
      if cv2.waitKey(25) & 0xFF == ord('q'):
        break
      if self.stopped:
        break
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ when everything done, release the video capture object
    self.cap.release()
    #~ closes all the frames
    cv2.destroyAllWindows()

  # #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # def read_frame(self):
  #   if self.capture is not None:
  #     ret, frame = self.capture.read()
  #     if ret:
  #       return frame
  #   return None
