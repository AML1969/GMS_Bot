#~ USAGE
#~ запускаем cmd от Администратора
#~ активируем виртуальную среду
# cd d:\my_dcampy
# .\dcenv\Scripts\activate
#~ запускаем на выполнение программу
# cd d:\my_dcampy\SafeCity-Voronezh-3
# python check_detection.py
# python check_detection.py --cam_index 2
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import torch
from matplotlib import pyplot as plt
import numpy as np
import cv2
import os
#~ передача аргументов через командную строку
import argparse

from config_camera import ConfigCamera

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ выполнение программы - тестируем детектирование объектов в кадре
#~~~~~~~~~~~~~~~~~~~~~~~~
print('~'*50)
print('Check Detection ver.2024.01.08')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ путь к папке из которой запустили программу
prog_path = os.getcwd()
print('~'*50)
print(f'prog_path: `{prog_path}`')
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ добавляем парсер аргументов
parser = argparse.ArgumentParser(description='Video camera settings.')
parser.add_argument('--cam_index', type=int, default=0,
                    help='Index of the camera to use')
args = parser.parse_args()
print(f'camera index: `{args.cam_index}`')
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ настройки камеры: пути, сжатие и т.д.
cam_conf = ConfigCamera(prog_path)
cam_names = cam_conf.get_cam_names()
use_compression,compressed_width,compressed_height = cam_conf.get_frame_compression()
print(f'cam_names: len: {len(cam_names)}, {cam_names}')
print(f'use_compression: `{use_compression}`')
print(f'compressed_width: `{compressed_width}`')
print(f'compressed_height: `{compressed_height}`')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ открываем видео-камеру
#~ cap - capture (захватывать)
#~~~~~~~~~~~~~~~~~~~~~~~~
cam_url = cam_conf.get_cam_url(args.cam_index)
if not cam_url:
  print(f'error: camera-url path to the camera is not defined or the index is incorrect')
  exit(0)
#~
cap = cv2.VideoCapture(cam_url)
#~ сheck if camera opened successfully
print('~'*50)
if cap.isOpened(): 
  print(f'success: camera-{args.cam_index} is open')
else:
  print(f'error: camera-{args.cam_index} is not open')
  exit(0)
cam_win_name = cam_names[args.cam_index]

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ pytorch.org/hub
#~ https://pytorch.org/hub/ultralytics_yolov5/
#~ load model
#~~~~~~~~~~~~~~~~~~~~~~~~
# model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
#~~~~~~~~~~~~~~~~~~~~~~~~
model = torch.hub.load('ultralytics/yolov5', 'custom', path='d:/my_dcampy/yolov5/runs/train/snowbank-results3/weights/best.pt', force_reload=True)
#~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ чтение видео-кадров камеры в цикле и детектирование объектов
#~~~~~~~~~~~~~~~~~~~~~~~~
while cap.isOpened():
  ret, frame = cap.read()
  if ret:
    #~ в зависимости от значения use_compression изменяем размер кадра
    #~ или оставляем его без изменений
    if use_compression:
      frame = cv2.resize(frame, (compressed_width, compressed_height))
    #~~~~~~~~~~~~~~~~~~~~~~~~
    # cv2.imshow(cam_win_name, frame)
    #~~~~~~~~~~~~~~~~~~~~~~~~
    #~ make detections 
    results = model(frame)
    results.print()
    cv2.imshow(cam_win_name, np.squeeze(results.render()))

  #~~~~~~~~~~~~~~~~~~~~~~~~
  if cv2.waitKey(10) & 0xFF == ord('q'):
    break

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~ закрываем видео-камеру и освобождаем ресурсы с ней связанные
#~~~~~~~~~~~~~~~~~~~~~~~~
#~ when everything done, release the video capture object
cap.release()
#~ closes all the frames
cv2.destroyAllWindows()

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
print('='*50)
print('-> program completed!')